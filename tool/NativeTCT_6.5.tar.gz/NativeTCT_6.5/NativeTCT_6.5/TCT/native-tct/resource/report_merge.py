#
# Copyright (c) 2021 Samsung Electronics Co., Ltd.
#
# Licensed under the Apache License, Version 2.0 (the License);
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#############################################################################
import os, shutil, sys
import re
from lxml import etree as et

################################################################################
# @function      file_copy
# @author        SRID(ankit.sri1)
# @reviewer      SRID(manu.tiwari)
# @description   Copying module specific files
# @parameter     path, items, dest_dir, dest_location, first_directory
# @return        NA
################################################################################
def file_copy(path, items, dest_dir, dest_location, first_directory):
	for item in items:
		location = os.path.join(path, item)
		if os.path.isdir(location) and item != first_directory and item != dest_dir:
			files = os.listdir(location)
			module_files = []
			modules = []
			for file in files:
				match = re.search("\.(?:auto|manual).xml$", file)
				if match:
					module_files.append(file)
			for module_file in module_files:
				words = re.split('[-.]', module_file)
				#if splitting is not possible
				if len(words) == 3:
					print("Can't find module file with a hyphen or a dot")
					print("Merge Script Finished")
					sys.exit()
				else:
					module = words[1]
					
					#extract all word with this module  -- comment
					copying_files = []
					#if module is already present in modules file - continue
					if modules.count(module) == 0:
						modules.append(module)
						for file in files:
							match = re.search(module, file)
							if match:
								copying_files.append(file)
						for file in copying_files:
							shutil.copy(os.path.join(location,file),dest_location)

################################################################################
# @function      xml_file_append
# @author        SRID(ankit.sri1)
# @reviewer      SRID(manu.tiwari)
# @description   Merging XML file tags
# @parameter     path, items, dest_dir, dest_location, first_directory
# @return        NA
################################################################################			
def xml_file_append(path, items, dest_dir, dest_location, first_directory):
	for filename in os.listdir(dest_location):
		if filename == "summary.xml":
			dest_fullname = os.path.join(dest_location, filename)
			dest_tree = et.parse(dest_fullname)
			break
	dest_root = dest_tree.getroot()
	#for all the other directory we will find summary.xml file and copy it into dest directory		
	for item in items:
		location = os.path.join(path, item)
		if os.path.isdir(location) and item != first_directory and item != dest_dir:
			source_dir = location
			for filename in os.listdir(source_dir):
				if filename == "summary.xml":
					source_fullname = os.path.join(source_dir, filename)
					source_tree = et.parse(source_fullname)
					source_tags = source_tree.findall('//suite')
					for tag in source_tags:
						# append the tag
						dest_root.append(tag)
						# overwrite the xml file
						et.ElementTree(dest_root).write(dest_fullname , pretty_print=True, encoding='utf-8', xml_declaration=True)

#################### Start Script  #####################
					
print("Merging Script Running...")

#Current directory path
path = os.getcwd()

#User given final result directory path
if len(sys.argv) > 1:
	cwd=sys.argv[1]
	resultpath = os.path.dirname(cwd)
else:
	#Default result directory path
	resultpath = os.getcwd()

dest = "Merged_Report"
dest_dir = dest
new_location = os.path.join(resultpath, dest)

#for deleting previous content if any
if os.path.isdir(new_location):
	shutil.rmtree(new_location, ignore_errors=True)

#Listing only directories in current path
items = list(filter(os.path.isdir, os.listdir(path)))

#if no directory is present
if len(items) == 0:
	print("No Directory Found")
	print("Merge Script Finished")
#if only one directory is present
elif len(items) == 1:
	print("Can't merge, only one directory is present!")
	print("Merge Script Finished")
else:
	location = ''
	#if any directory present with first manual module in it
	for item in items:
		manual_module_location = os.path.join(path,item)
		files = os.listdir(manual_module_location)
		for file in files:	
			match = re.search("\.manual.xml$", file)
			if match:
				location = manual_module_location
				first_directory = item
				break
	if location == '':
		#copying any one directory content to a new directory
		for item in items:
			location = os.path.join(path, item)
			if os.path.isdir(location):
				first_directory = item
				break
	dest = shutil.copytree(location, new_location)
	file_copy(path, items, dest_dir, new_location, first_directory)
	xml_file_append(path, items, dest_dir, new_location, first_directory)
	print("Merging Finished!!")
	print("Merged report is created at:"+new_location)