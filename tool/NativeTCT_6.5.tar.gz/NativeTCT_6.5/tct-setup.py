# -*- coding:utf-8 -*-
import os
import sys
import shutil
import stat
import re
import tarfile
import zipfile
import platform

SCRIPT_VERSION = "1.1"
WEB_TCT_PATTERN = "^web-tct_\d.\d"
NATIVE_TCT_PATTERN = "^nativetct_\d.\d"
CSHARP_TCT_PATTERN = "^csharp-tct_\d.\d"

TOOLS_PATTERN = "^tct-tools"

TCT_INSTALL_SCRIPT = "tct-config-host.py"
TOOLS_INSTALL_SCRIPT = "tct-config-tools.py"

NATIVE_TCT_TYPE = 0
WEB_TCT_TYPE = 1
TOOLS_TYPE = 2
NORMAL_TYPE = 3
CSHARP_TCT_TYPE = 4

def make_ver_file(tctV, tizenV):
    ver_path = "/opt/tct/" + tizenV + "/VERSION"
    #ver_file = open('/opt/tct/tizen_web_3.0/VERSION', 'wa')
    ver_file = open(ver_path, 'w')
    ver_file.write(str(tctV))
    ver_file.close()

def get_tizenV(afile):
    tizenV = ""
    ver = afile.split('_')[1]
    if afile.find("web") > -1:
        tizenV = "tizen_web_" + ver
    elif afile.find("Native") > -1:
        tizenV = "tizen_native_" + ver
    elif afile.find("csharp") > -1:
        tizenV = "tizen_csharp_" + ver

    return tizenV

def install_release_file(afile, file_type, upgrade):

    try:
        tizenV = None
        for r,d,f in os.walk(afile):
            if (platform.system() != "Windows"):
                os.system("chmod -R 777 "+ r)

        inst_cmd = "python " + TCT_INSTALL_SCRIPT
        if upgrade:
            inst_cmd += " --upgrade"

        if file_type is WEB_TCT_TYPE or file_type is CSHARP_TCT_TYPE:
            tizenV = get_tizenV(afile)
            os.chdir(afile +"/tools")
            os.system(inst_cmd + " --tizen-version " + tizenV)
            os.chdir("../../")
            make_ver_file(str(afile), tizenV)

        if file_type is NATIVE_TCT_TYPE:
            tizenV = get_tizenV(afile)
            os.chdir(afile + "/TCT/native-tct/tools")
            os.system(inst_cmd + " --tizen-version " + tizenV)
            os.chdir("../../../../")
            make_ver_file(str(afile), tizenV)

        if file_type is TOOLS_TYPE:
            os.chdir(afile)
            os.system("python "+ TOOLS_INSTALL_SCRIPT)
            os.chdir("../")
    except Exception as ex:
        print (str(ex))


def unpack_release_file(afile):
    if tarfile.is_tarfile(afile):
        tar = tarfile.open(afile)
        for tarinfo in tar:
            msg = tarinfo.name + " is " + str(tarinfo.size) + " bytes in size and is "
            if tarinfo.isreg():
                msg += "a regular file."
            elif tarinfo.isdir():
                msg += "a directory."
            else:
                msg += "something else."
            print (msg)
        tar.extractall()
        tar.close()

    if zipfile.is_zipfile(afile):
        zipf = zipfile.ZipFile(afile)
        zipf.extractall()
        zipf.close()

def find_release_file(afile):
    web_tct_pa = re.compile(WEB_TCT_PATTERN, re.I)
    web_tct_match = web_tct_pa.match(afile)

    native_tct_pa = re.compile(NATIVE_TCT_PATTERN, re.I)
    native_tct_match = native_tct_pa.match(afile)

    csharp_tct_pa = re.compile(CSHARP_TCT_PATTERN, re.I)
    csharp_tct_match = csharp_tct_pa.match(afile)

    if web_tct_match:
        return WEB_TCT_TYPE

    if native_tct_match:
        return NATIVE_TCT_TYPE

    if csharp_tct_match:
        return CSHARP_TCT_TYPE

    tools_pa = re.compile(TOOLS_PATTERN, re.I)
    tools_match = tools_pa.match(afile)
    if tools_match :
        return TOOLS_TYPE

    return NORMAL_TYPE

def is_archvie_file(afile):
    file_extension = get_file_extension(afile)
    if file_extension == ".gz" or file_extension == ".zip":
        return True
    else :
        return False

def get_file_extension(afile):
    return os.path.splitext(afile)[1]

def remove_readonly(func, path, excinfo):
    if (platform.system() != "Windows"):
        os.chmod(path, stat.S_IWRITE)
    func(path)

def remove_dir_tree(remove_dir):
    try:
        shutil.rmtree(remove_dir, ignore_errors=False, onerror=remove_readonly)
    except Exception as e:  ## if failed, report it back to the user ##
        print("[Delete Error] %s - %s." % (e.filename,e.strerror))

def install_tct(upgrade=False):
    current_path = os.getcwd()
    filelist = os.listdir(current_path)
    for file in filelist :
        file_type = find_release_file(file)
        if file_type is not NORMAL_TYPE :
            if is_archvie_file(file) is True:
                unpack_release_file(file)

    filelist = os.listdir(current_path)
    for file in filelist:
        file_type = find_release_file(file)
        if file_type is not NORMAL_TYPE :
            if is_archvie_file(file) is False:
                install_release_file(file, file_type, upgrade)

if len(sys.argv) > 1:
    if(sys.argv[1]) == 'clean':
        print("clean option is given")
        remove_dir_tree("/opt/tct")
        remove_dir_tree("/opt/tools")
        remove_dir_tree("/opt/testkit")
    elif(sys.argv[1]) == 'upgrade':
        print("upgrade option is given")
        install_tct(True)
    else:
        print("error:invalid option is given")
else:
    install_tct(False)
