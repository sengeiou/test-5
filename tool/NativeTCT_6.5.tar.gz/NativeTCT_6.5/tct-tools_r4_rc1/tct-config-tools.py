# -*- coding:utf-8 -*-
import os
import platform
import shutil
import stat
import subprocess
from optparse import OptionParser

SDB_SERNO = "sdb"


class CpFile:
    sep = os.sep
    TARGET_BASE_PATH = os.path.join(os.sep + "opt", "tools")
    TARGET_BASE_LITE = os.path.join(os.sep + "opt", "testkit")

    CURRENT_TARGET_BASE_PATH = ""
    CURRENT_TARGET_LITE_PATH = ""
    CURRENT_SOURCE_LITE_PATH = ""

    #shell
    SOURCE_SHELL_PATH = sep + "shell"
    TARGET_SHELL_PATH = sep + "shell"
    #manager
    SOURCE_MANAGER_PATH = sep + "manager"
    TARGET_MANAGER_PATH = sep + "manager"
    #script
    SOURCE_SCRIPT_PATH = ""
    TARGET_SCRIPT_PATH = sep + "tools" + sep + "scripts"
    #testkit1.0
    SOURCE_TESTKIT_PATH1 = sep + "testkitlite_native"
    TARGET_TESTKIT_PATH1 = sep + "lite_native"
    #testkit2.0
    SOURCE_TESTKIT_PATH2 = sep + "testkitlite_web_csharp"
    TARGET_TESTKIT_PATH2 = sep + "lite_web_csharp"
    #plugin
    SOURCE_PLUGIN_PATH = sep + "plugin"
    TARGET_PLUGIN_PATH = sep + "plugin"

    def getCurrentOSBit(self):
        return platform.architecture()

    def setCurrentPath(self):
        self.CURRENT_SOURCE_BASE_PATH = os.getcwd() + self.sep
        self.CURRENT_TARGET_BASE_PATH = self.TARGET_BASE_PATH
        self.CURRENT_TARGET_LITE_PATH = self.TARGET_BASE_LITE
        print("current source base path =" + self.CURRENT_SOURCE_BASE_PATH)
        print("current target base path =" + self.CURRENT_TARGET_BASE_PATH)

    def cpSdb(self):
        osInfo = self.getCurrentOSBit()
        if (platform.system() == "Windows"):
            if (str(osInfo[0]).find("64") != -1):
                self.cpFile(
                    self.CURRENT_SOURCE_BASE_PATH + self.SOURCE_SCRIPT_PATH + \
                            self.sep + "sdb" + self.sep + "sdb-64.exe",
                    self.CURRENT_TARGET_BASE_PATH + self.sep + "sdb.exe")
            if (str(osInfo[0]).find("32") != -1):
                self.cpFile(self.CURRENT_SOURCE_BASE_PATH + \
                        self.SOURCE_SCRIPT_PATH + self.sep + "sdb" + self.sep \
                        + "sdb-32.exe", self.CURRENT_TARGET_BASE_PATH + \
                        self.sep + "sdb.exe")
        else:
            '''
            # get status and output of the command
            status, output = commands.getstatusoutput('lsof | \
                    grep /usr/bin/sdb')
            # merge continuing spaces to one
            collapsedOutput = ' '.join(output.split())
            # split words
            result = collapsedOutput.split(' ')
            # get the process id of the sdb
            if status is not 256 :
                # find the word sdb
                for x in range(0, result.__len__()):
                    if (result[x] == "sdb"):
                        break
                # get the process id of the sdb
                os.system('kill -9 ' + result[x+1])
            '''
            try:

                if(self.checkInstalledSdb()):
                    print("sdb install is not required")
                    return

                print("sdb install")

                if (str(osInfo[0]).find("64") != -1):
                    self.cpFile(
                        self.CURRENT_SOURCE_BASE_PATH + \
                                self.SOURCE_SCRIPT_PATH + self.sep + "sdb" + \
                                self.sep + "sdb-64",
                        self.CURRENT_TARGET_BASE_PATH + self.sep + "sdb")
                    self.cpFile(
                        self.CURRENT_SOURCE_BASE_PATH + \
                                self.SOURCE_SCRIPT_PATH + self.sep + "sdb" + \
                                self.sep + "sdb-64",
                        "/usr/bin/" + "sdb")
                if (str(osInfo[0]).find("32") != -1):
                    self.cpFile(
                        self.CURRENT_SOURCE_BASE_PATH + \
                                self.SOURCE_SCRIPT_PATH + self.sep + "sdb" + \
                                self.sep + "sdb-32",
                        self.CURRENT_TARGET_BASE_PATH + self.sep + "sdb")
                    self.cpFile(
                        self.CURRENT_SOURCE_BASE_PATH + \
                                self.SOURCE_SCRIPT_PATH + self.sep + "sdb" + \
                                self.sep + "sdb-32",
                        "/usr/bin/" + "sdb")
                os.system("chmod -R 777 /usr/bin/sdb")
            except:
                pass

    def get_cmd_result(self, command):
        p = subprocess.Popen(command,
                         stdout=subprocess.PIPE,
                         stderr=subprocess.STDOUT)
        return p.stdout.readline()

    def checkInstalledSdb(self):
        cmd = ["sdb", "version"]
        installedVer = ""
        try:
            output = str(self.get_cmd_result(cmd).split('\n')[0])
            if output.find('Smart Development Bridge') > -1:
                installedVer = output.split(' ')[4]
            else:
                raise
        except:
            print("sdb is not installed")
            return False

        osInfo = self.getCurrentOSBit()
        if (str(osInfo[0]).find("32") != -1):
            cmd = ["sdb/sdb-32", "version"]
        else:
            cmd = ["sdb/sdb-64", "version"]
        toolVer = ""
        try:
            output = str(self.get_cmd_result(cmd).split('\n')[0])
            if output.find('Smart Development Bridge') > -1:
                toolVer = output.split(' ')[4]
            else:
                raise
        except:
            print("tool's sdb is not valid")
            return True

        print("installed sdb version : %s / tool's sdb version : %s" % (installedVer, toolVer))
        installedSplit = installedVer.split('.')
        toolSplit = toolVer.split('.')
        hit = 0
        for i in range(0, 3):
            if(int(installedSplit[i]) > int(toolSplit[i])):
                print("Higher version sdb is already installed : " + installedVer)
                return True
            if(int(installedSplit[i]) == int(toolSplit[i])):
                hit += 1
                continue
            if(int(installedSplit[i]) < int(toolSplit[i])):
                break
        if(hit==3):
            print("Same version of sdb is already installed : " + installedVer)
            return True

        return False

    def cpOtherFiles(self):
        tct_mgr = "tct-mgr"
        tct_shell = "tct-shell"
        testkit_lite1 = "testkit-lite_native"
        testkit_lite2 = "testkit-lite_web_csharp"
        tct_config = "TCT_CONFIG"

        if (platform.system() == "Windows"):
            tct_mgr = "tct-mgr.bat"

        self.cpFile(self.CURRENT_SOURCE_BASE_PATH + self.SOURCE_SCRIPT_PATH + \
                self.sep + tct_mgr, self.CURRENT_TARGET_BASE_PATH + \
                self.sep + tct_mgr)
        self.cpFile(self.CURRENT_SOURCE_BASE_PATH + self.SOURCE_SCRIPT_PATH + \
                self.sep + tct_shell, self.CURRENT_TARGET_BASE_PATH + \
                self.sep + tct_shell)
        self.cpFile(self.CURRENT_SOURCE_BASE_PATH + self.SOURCE_SCRIPT_PATH + \
                self.sep + testkit_lite1, self.CURRENT_TARGET_BASE_PATH + \
                self.sep + testkit_lite1)
        self.cpFile(self.CURRENT_SOURCE_BASE_PATH + self.SOURCE_SCRIPT_PATH + \
                self.sep + testkit_lite2, self.CURRENT_TARGET_BASE_PATH + \
                self.sep + testkit_lite2)
        self.cpFile(self.CURRENT_SOURCE_BASE_PATH + self.SOURCE_SCRIPT_PATH + \
                self.sep + tct_config, self.CURRENT_TARGET_BASE_PATH + \
                self.sep + tct_config)

    def cpOtherFilesToBinDir(self):
        tct_mgr = "tct-mgr"
        tct_shell = "tct-shell"
        testkit_lite1 = "testkit-lite_native"
        testkit_lite2 = "testkit-lite_web_csharp"

        if (platform.system() != "Windows"):
            self.cpFile(self.CURRENT_SOURCE_BASE_PATH + \
                    self.SOURCE_SCRIPT_PATH + self.sep + \
                    tct_mgr, "/usr/bin/" + tct_mgr)
            self.cpFile(self.CURRENT_SOURCE_BASE_PATH + \
                    self.SOURCE_SCRIPT_PATH + self.sep + \
                    tct_shell, "/usr/bin/" + tct_shell)
            self.cpFile(self.CURRENT_SOURCE_BASE_PATH + \
                    self.SOURCE_SCRIPT_PATH + self.sep + testkit_lite1,\
                    "/usr/bin/" + testkit_lite1)
            self.cpFile(self.CURRENT_SOURCE_BASE_PATH + \
                    self.SOURCE_SCRIPT_PATH + self.sep + testkit_lite2,\
                    "/usr/bin/" + testkit_lite2)

            try:
                os.system("chmod -R 777 /usr/bin/" + tct_mgr)
                os.system("chmod -R 777 /usr/bin/" + tct_shell)
                os.system("chmod -R 777 /usr/bin/" + testkit_lite1)
                os.system("chmod -R 777 /usr/bin/" + testkit_lite2)
                os.system("chmod -R 777 /usr/bin/sdb")
            except:
                pass

    def cpTestKitLite(self):
        self.cpDir(self.CURRENT_SOURCE_BASE_PATH + self.SOURCE_TESTKIT_PATH1, \
                   self.CURRENT_TARGET_LITE_PATH + self.TARGET_TESTKIT_PATH1, \
                           "lite_native")
        for r, d, f in os.walk(self.CURRENT_TARGET_LITE_PATH + \
                self.TARGET_TESTKIT_PATH1):
            if (platform.system() != "Windows"):
                os.chmod(r, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)

        self.cpDir(self.CURRENT_SOURCE_BASE_PATH + self.SOURCE_TESTKIT_PATH2,
                   self.CURRENT_TARGET_LITE_PATH + self.TARGET_TESTKIT_PATH2, \
                           "lite_web_csharp")
        for r, d, f in os.walk(self.CURRENT_TARGET_LITE_PATH + \
                self.TARGET_TESTKIT_PATH2):
            if (platform.system() != "Windows"):
                os.chmod(r, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)

    def cpManager(self):
        self.cpDir(self.CURRENT_SOURCE_BASE_PATH + self.SOURCE_MANAGER_PATH,
                   self.CURRENT_TARGET_BASE_PATH + self.TARGET_MANAGER_PATH, \
                           "manager")
        for r, d, f in os.walk(self.CURRENT_TARGET_BASE_PATH + \
                self.TARGET_MANAGER_PATH):
            if (platform.system() != "Windows"):
                os.chmod(r, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)

    def cpShell(self):
        self.cpDir(self.CURRENT_SOURCE_BASE_PATH + self.SOURCE_SHELL_PATH,
                   self.CURRENT_TARGET_BASE_PATH + self.TARGET_SHELL_PATH, \
                           "shell")
        for r, d, f in os.walk(self.CURRENT_TARGET_BASE_PATH + \
                self.TARGET_SHELL_PATH):
            if (platform.system() != "Windows"):
                os.chmod(r, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)

    def cpPlugin(self):
        self.cpDir(self.CURRENT_SOURCE_BASE_PATH + self.SOURCE_PLUGIN_PATH,
                   self.CURRENT_TARGET_BASE_PATH + self.TARGET_PLUGIN_PATH, \
                           "plugin")
        for r, d, f in os.walk(self.CURRENT_TARGET_BASE_PATH + \
                self.TARGET_PLUGIN_PATH):
            if (platform.system() != "Windows"):
                os.chmod(r, stat.S_IRWXU | stat.S_IRWXG | stat.S_IRWXO)

    def cpFile(self, src, target):
        if (not os.path.isfile(src)):
            print(src + " is not a file")
            return
        path = os.path.dirname(target)
        if (not os.path.isdir(path)):
            os.makedirs(path)
        shutil.copyfile(src, target)

    def del_rw(self, action, name, exc):
        if (platform.system() != "Windows"):
            os.chmod(name, stat.S_IWRITE)
        os.remove(name)

    def cpDir(self, src, target, name):
        if (os.path.isdir(src) and not os.path.exists(target)):
            print("copy " + name + "  dir start")
            shutil.copytree(src, target)
            print("copy " + name + "  dir finish")
        else:
            if (not os.path.isdir(src)):
                print("source " + name + " path is not a dir")
            if (os.path.exists(target)):
                print ("target " + name + " path is exists")
                try:
                    shutil.rmtree(target, onerror=self.del_rw)
                except Exception, data:
                    print Exception, ":", data

                print ("target " + name + " dir destroyed")
                try:
                    shutil.copytree(src, target)
                except Exception, data:
                    print Exception, ":", data
                print("copy " + name + "  dir finish")

    def clear(self):
        self.setCurrentPath()
        try:
            shutil.rmtree(self.CURRENT_TARGET_BASE_PATH, onerror=self.del_rw)
        except Exception, data:
            print Exception, ":", data

    def cp(self):
        self.setCurrentPath()
        self.cpShell()
        self.cpManager()
        self.cpOtherFiles()
        self.cpTestKitLite()
        self.cpPlugin()
        self.cpOtherFilesToBinDir()
        self.cpSdb()

parser = OptionParser()
parser.add_option("-i", "--install", dest="install", action="store_true", \
        default=False, help="copy folders and file into os")
parser.add_option("-p", "--purge", dest="clear", action="store_true", \
        default=False, help="clear all files")

(options, args) = parser.parse_args()
if (options.install):
    test = CpFile()
    test.cp()
elif(options.clear):
    test = CpFile()
    test.clear()
else:
    test = CpFile()
    test.cp()
