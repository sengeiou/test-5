#!/usr/bin/python

import threading
import subprocess
import time

from .logmanager import LOGGER
from .commodule.killall import killall
from multiprocessing import Process


#class UsbMonitor(threading.Thread):
class UsbMonitor(Process):
    usb_cmd = 'tail -f /var/log/syslog | stdbuf -o0 grep usb'
    isStop = False
    LOGGER.setLevel('DEBUG')

    def __init__(self, devmgr):
        #threading.Thread.__init__(self)
        Process.__init__(self)
        self.daemon = True
        self.name = "UsbMonitor"
        self.devmgr = devmgr
        self.proc = subprocess.Popen(self.usb_cmd, shell=True, \
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        self.recovery_locks = {}
        self.curr_time = None

    def set_currsec(self):
        lt = time.localtime(time.time())
        self.curr_time = lt.tm_sec + (lt.tm_min * 60) + (lt.tm_hour * 3600)

    def run(self):
        LOGGER.debug("Starting UsbMonitor.......")
        self.set_currsec()
        while True:
            outs = self.proc.stdout.readline()
            if outs:
                outs = outs.strip().decode("utf-8")
                for outLog in outs.split('\n'):
                    log_sp = outLog.split(' ')[2]
                    time_sp = log_sp.split(':')
                    tm_hour = int(time_sp[0])
                    tm_min = int(time_sp[1])
                    tm_sec = int(time_sp[2])
                    time_sp = (tm_hour * 3600) + (tm_min * 60) + tm_sec

                    if self.curr_time > time_sp:
                        continue

                    if self.isDisConnectUsb(outLog) or self.isConnectUsb(outLog):
                        self.reLoadDeviceList()

    def reLoadDeviceList(self):
        time.sleep(3)
        ret = self.devmgr.loadDeviceList()
        if not ret:
            LOGGER.error('0 device is connected')
        else:
            for devId in self.recovery_locks.keys():
                if self.devmgr.isDeviceAvailable(devId):
                    self.device_recovered(devId)

    def isDisConnectUsb(self, sysLog):
        if sysLog and sysLog.find('USB disconnect') > -1:
            LOGGER.error(sysLog)
            return True
        else:
            return False

    def isConnectUsb(self, sysLog):
        if sysLog.find('New USB device found') > -1:
            LOGGER.debug(sysLog)
            return True
        else:
            return False

    def setup_recovery(self, devId, lock):
        self.recovery_locks[devId] = lock

    def device_recovered(self, devId):
        try:
            self.recovery_locks[devId].put(1, block=False)
        except Exception as ex:
            LOGGER.debug(str(ex))

    def kill_usbmonitor(self):
        killall(self.proc.pid)
