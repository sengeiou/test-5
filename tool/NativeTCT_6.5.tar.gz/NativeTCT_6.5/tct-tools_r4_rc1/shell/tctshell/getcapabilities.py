import os
import json
import configparser
from xml.dom import minidom
import xml.etree.ElementTree as ET

from .sdbmanager import SdbManager
from .logmanager import LOGGER
from .constants import Constants


class GetCap():

    def __init__(self, tizenVer, deviceId):
        self.tizenVer = tizenVer
        self.deviceId = deviceId
        self.dict = {}
        self.cwd = os.getcwd()

    def parseModelConfigXml(self):
        model_config = os.path.join(Constants.LOCAL_SHELL_TEMP_PATH % self.deviceId,
                                    'model-config.xml')
        if os.path.exists(model_config) is False:
            LOGGER.error(
                "model-config.xml file doesn't exist in the device at path : %s " % model_config)
            return False

        tree = ET.parse(model_config)

        root = tree.getroot()
        for tag in root.findall('platform'):
            for key in tag.findall('key'):
                feature_name = 'http://' + key.get('name')
                feature_type = key.get('type')
                feature_val = key.text
                new_dict = {}
                if feature_name == 'http://tizen.org/feature/profile':
                    new_dict['val'] = feature_val.upper()
                else:
                    new_dict['val'] = feature_val
                new_dict['type'] = feature_type
                self.dict[feature_name] = new_dict

        return True

    def loadDictIntoJson(self):
        json_obj = json.dumps(self.dict, indent=4)
        db_file = os.path.join(Constants.LOCAL_SHELL_TEMP_PATH % self.deviceId, 'db.json')
        if os.path.exists(db_file):
            os.remove(db_file)
        with open(db_file, 'w') as f:
            f.write(json_obj)

    def parseInfoIni(self):
        info_ini = os.path.join(Constants.LOCAL_SHELL_TEMP_PATH % self.deviceId, 'info.ini')
        if os.path.exists(info_ini) is False:
            LOGGER.error("info.ini file doesn't exist in the device at path : %s " % info_ini)
            return False

        config = configparser.ConfigParser()
        config.read(info_ini)
        try:
            for key in config['Build']:
                val = config['Build'][key].strip(';')
                key = key.lower()
                new_dict = {}
                new_dict['type'] = 'string'
                new_dict['val'] = val
                self.dict['http://tizen.org/system/build.' + key] = new_dict
            self.dict['http://tizen.org/system/build.model'] = {
                'type': 'string', 'val': config['Version']['Model'].strip(';')
            }
            self.dict['http://tizen.org/system/build.string'] = {
                'type': 'string', 'val': config['Version']['Build'].strip(';')
            }
            self.dict['http://tizen.org/system/build.release'] = {
                'type': 'string', 'val': config['Version']['Release'].strip(';')
            }
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

    def makeBuildInfo(self):
        build_info_file = os.path.join(Constants.LOCAL_SHELL_TEMP_PATH % self.deviceId,
                                       'buildinfo.xml')
        if os.path.exists(build_info_file):
            os.remove(build_info_file)

        db_file = os.path.join(Constants.LOCAL_SHELL_TEMP_PATH % self.deviceId, 'db.json')
        if os.path.exists(db_file) is False:
            LOGGER.error("db.json file doesn't exist in the device at path : %s " % db_file)
            return False

        capability_dict = {}

        with open(db_file, 'r') as f:
            capability_dict = json.load(f)

        try:
            model = capability_dict['http://tizen.org/system/model_name']['val']
            manufacturer = capability_dict['http://tizen.org/system/manufacturer']['val']
            buildversion = capability_dict['http://tizen.org/system/build.string']['val']
        except Exception as ex:
            LOGGER.error(str(ex))
            return False

        buildinfo_dict = {
            model: "model", manufacturer: "manufacturer", buildversion: "buildVersion"
        }
        buildinfos = ET.Element("buildinfos")
        buildinfos.set('xmlns:xsi', "http://www.w3.org/2001/XMLSchema-instance")
        buildinfos.set('xsi:noNamespaceSchemaLocation', "buildinfo.xsd")
        for key, val in buildinfo_dict.items():
            buildinfo = ET.SubElement(buildinfos, "buildinfo", name=val, support="true",
                                      type="String")
            value = ET.SubElement(buildinfo, "value").text = key
        xmlstr = minidom.parseString(ET.tostring(buildinfos)).toprettyxml(indent="    ",
                                                                          encoding="UTF-8")
        with open(build_info_file, 'w') as f:
            f.write(xmlstr.decode('utf-8'))

        if os.path.exists(build_info_file) is False:
            return False

        return True

    def makeCapabilities(self):
        capability_file = os.path.join(Constants.LOCAL_SHELL_TEMP_PATH % self.deviceId,
                                       'device_capability.xml')
        if os.path.exists(capability_file):
            os.remove(capability_file)

        db_file = os.path.join(Constants.LOCAL_SHELL_TEMP_PATH % self.deviceId, 'db.json')
        if os.path.exists(db_file) is False:
            LOGGER.error("db.json file doesn't exist in the device at path : %s " % db_file)
            return False

        capability_dict = {}

        with open(db_file, 'r') as f:
            capability_dict = json.load(f)

        # keys = ["http://tizen.org/feature/account", \
                # "http://tizen.org/feature/battery", \
                # "http://tizen.org/feature/bookmark", \
                # "http://tizen.org/feature/calendar", \
                # "http://tizen.org/feature/camera", \
                # "http://tizen.org/feature/camera.back", \
                # "http://tizen.org/feature/camera.back.flash", \
                # "http://tizen.org/feature/camera.front", \
                # "http://tizen.org/feature/camera.front.flash", \
                # "http://tizen.org/feature/contact", \
                # "http://tizen.org/feature/database.encryption", \
                # "http://tizen.org/feature/datasync", \
                # "http://tizen.org/feature/datacontrol", \
                # "http://tizen.org/feature/download", \
                # "http://tizen.org/feature/fmradio", \
                # "http://tizen.org/feature/graphics.acceleration", \
                # "http://tizen.org/feature/input.keyboard", \
                # "http://tizen.org/feature/input.keyboard.layout", \
                # "http://tizen.org/feature/location", \
                # "http://tizen.org/feature/location.gps", \
                # "http://tizen.org/feature/location.wps", \
                # "http://tizen.org/feature/location.batch", \
                # "http://tizen.org/feature/email", \
                # "http://tizen.org/feature/microphone", \
                # "http://tizen.org/feature/multi_point_touch.pinch_zoom", \
                # "http://tizen.org/feature/multi_point_touch.point_count", \
                # "http://tizen.org/feature/network.bluetooth", \
                # "http://tizen.org/feature/network.bluetooth.health", \
                # "http://tizen.org/feature/network.nfc", \
                # "http://tizen.org/feature/network.nfc.card_emulation", \
                # "http://tizen.org/feature/network.nfc.card_emulation.hce", \
                # "http://tizen.org/feature/network.nfc.reserved_push", \
                # "http://tizen.org/feature/network.push", \
                # "http://tizen.org/feature/network.secure_element", \
                # "http://tizen.org/feature/network.telephony", \
                # "http://tizen.org/feature/network.telephony.mms", \
                # "http://tizen.org/feature/network.telephony.service.edge", \
                # "http://tizen.org/feature/network.telephony.service.gprs", \
                # "http://tizen.org/feature/network.telephony.service.gsm", \
                # "http://tizen.org/feature/network.telephony.service.hsdpa", \
                # "http://tizen.org/feature/network.telephony.service.hspa", \
                # "http://tizen.org/feature/network.telephony.service.hsupa", \
                # "http://tizen.org/feature/network.telephony.service.lte", \
                # "http://tizen.org/feature/network.telephony.service.umts", \
                # "http://tizen.org/feature/network.telephony.sms.cbs", \
                # "http://tizen.org/feature/network.wifi", \
                # "http://tizen.org/feature/network.wifi.direct", \
                # "http://tizen.org/feature/notification", \
                # "http://tizen.org/feature/opengles", \
                # "http://tizen.org/feature/opengles.texture_format", \
                # "http://tizen.org/feature/opengles.texture_format.3dc", \
                # "http://tizen.org/feature/opengles.texture_format.atc", \
                # "http://tizen.org/feature/opengles.texture_format.etc", \
                # "http://tizen.org/feature/opengles.texture_format.ptc", \
                # "http://tizen.org/feature/opengles.texture_format.pvrtc", \
                # "http://tizen.org/feature/opengles.texture_format.utc", \
                # "http://tizen.org/feature/opengles.version.1_1", \
                # "http://tizen.org/feature/opengles.version.2_0", \
                # "http://tizen.org/feature/platform.core.api.version", \
                # "http://tizen.org/feature/platform.core.cpu.arch", \
                # "http://tizen.org/feature/platform.core.cpu.arch.armv6", \
                # "http://tizen.org/feature/platform.core.cpu.arch.armv7", \
                # "http://tizen.org/feature/platform.core.cpu.arch.x86", \
                # "http://tizen.org/feature/platform.core.fpu.arch", \
                # "http://tizen.org/feature/platform.core.fpu.arch.sse2", \
                # "http://tizen.org/feature/platform.core.fpu.arch.sse3", \
                # "http://tizen.org/feature/platform.core.fpu.arch.ssse3", \
                # "http://tizen.org/feature/platform.core.fpu.arch.vfpv2", \
                # "http://tizen.org/feature/platform.core.fpu.arch.vfpv3", \
                # "http://tizen.org/feature/platform.native.api.version", \
                # "http://tizen.org/feature/platform.native.osp_compatible", \
                # "http://tizen.org/feature/platform.version", \
                # "http://tizen.org/feature/platform.web.api.version", \
                # "http://tizen.org/feature/profile", \
                # "http://tizen.org/feature/screen", \
                # "http://tizen.org/feature/screen.auto_rotation", \
                # "http://tizen.org/feature/screen.bpp", \
                # "http://tizen.org/feature/screen.coordinate_system.size.large", \
                # "http://tizen.org/feature/screen.coordinate_system.size.normal", \
                # "http://tizen.org/feature/screen.dpi", \
                # "http://tizen.org/feature/screen.height", \
                # "http://tizen.org/feature/screen.output.hdmi", \
                # "http://tizen.org/feature/screen.output.rca", \
                # "http://tizen.org/feature/screen.size.normal", \
                # "http://tizen.org/feature/screen.size.normal.1080.1920", \
                # "http://tizen.org/feature/screen.size.normal.240.400", \
                # "http://tizen.org/feature/screen.size.normal.320.320", \
                # "http://tizen.org/feature/screen.size.normal.360.360", \
                # "http://tizen.org/feature/screen.size.normal.320.480", \
                # "http://tizen.org/feature/screen.size.normal.480.800", \
                # "http://tizen.org/feature/screen.size.normal.540.960", \
                # "http://tizen.org/feature/screen.size.normal.600.1024", \
                # "http://tizen.org/feature/screen.size.normal.720.1280", \
                # "http://tizen.org/feature/screen.width", \
                # "http://tizen.org/feature/sensor.accelerometer", \
                # "http://tizen.org/feature/sensor.accelerometer.wakeup", \
                # "http://tizen.org/feature/sensor.barometer", \
                # "http://tizen.org/feature/sensor.barometer.wakeup", \
                # "http://tizen.org/feature/sensor.gyroscope", \
                # "http://tizen.org/feature/sensor.gyroscope.wakeup", \
                # "http://tizen.org/feature/sensor.heart_rate_monitor", \
                # "http://tizen.org/feature/sensor.magnetometer", \
                # "http://tizen.org/feature/sensor.magnetometer.wakeup", \
                # "http://tizen.org/feature/sensor.pedometer", \
                # "http://tizen.org/feature/sensor.photometer", \
                # "http://tizen.org/feature/sensor.photometer.wakeup", \
                # "http://tizen.org/feature/sensor.proximity", \
                # "http://tizen.org/feature/sensor.proximity.wakeup", \
                # "http://tizen.org/feature/sensor.tiltmeter", \
                # "http://tizen.org/feature/sensor.tiltmeter.wakeup", \
                # "http://tizen.org/feature/sensor.ultraviolet", \
                # "http://tizen.org/feature/sensor.wrist_up", \
                # "http://tizen.org/feature/shell.appwidget", \
                # "http://tizen.org/feature/sip.voip", \
                # "http://tizen.org/feature/speech.recognition", \
                # "http://tizen.org/feature/speech.synthesis", \
                # "http://tizen.org/feature/systemsetting", \
                # "http://tizen.org/feature/systemsetting.home_screen", \
                # "http://tizen.org/feature/systemsetting.incoming_call", \
                # "http://tizen.org/feature/systemsetting.lock_screen", \
                # "http://tizen.org/feature/systemsetting.notification_email", \
                # "http://tizen.org/feature/usb.accessory", \
                # "http://tizen.org/feature/usb.host", \
                # "http://tizen.org/feature/vision.face_recognition", \
                # "http://tizen.org/feature/vision.image_recognition", \
                # "http://tizen.org/feature/vision.qrcode_generation", \
                # "http://tizen.org/feature/vision.qrcode_recognition", \
                # "http://tizen.org/feature/websetting", \
                # "http://tizen.org/system/duid", \
                # "http://tizen.org/system/platform.name", \
                # "http://tizen.org/feature/archive", \
                # "http://tizen.org/feature/badge", \
                # "http://tizen.org/feature/exif", \
                # "http://tizen.org/feature/mediakey", \
                # "http://tizen.org/feature/led", \
                # "http://tizen.org/feature/multimedia.transcoder", \
                # "http://tizen.org/capability/network.bluetooth.always_on", \
                # "http://tizen.org/feature/network.bluetooth.audio.call", \
                # "http://tizen.org/feature/network.bluetooth.audio.media", \
                # "http://tizen.org/feature/network.bluetooth.hid", \
                # "http://tizen.org/feature/network.bluetooth.le", \
                # "http://tizen.org/feature/network.bluetooth.opp", \
                # "http://tizen.org/feature/platform.core.cpu.frequency", \
                # "http://tizen.org/feature/platform.version.name", \
                # "http://tizen.org/feature/screen.size.all", \
                # "http://tizen.org/feature/screen.size.large", \
                # "http://tizen.org/feature/screen.size.normal.360.480", \
                # "http://tizen.org/feature/sensor.activity_recognition", \
                # "http://tizen.org/feature/sensor.gesture_recognition", \
                # "http://tizen.org/feature/sensor.gravity", \
                # "http://tizen.org/feature/sensor.humidity", \
                # "http://tizen.org/feature/sensor.linear_acceleration", \
                # "http://tizen.org/feature/sensor.rotation_vector", \
                # "http://tizen.org/feature/sensor.temperature", \
                # "http://tizen.org/system/build.date", \
                # "http://tizen.org/system/build.string", \
                # "http://tizen.org/system/build.time", \
                # "http://tizen.org/system/manufacturer", \
                # "http://tizen.org/system/tizenid", \
                # "http://tizen.org/system/model_name", \
                # "http://tizen.org/system/platform.communication_processor", \
                # "http://tizen.org/system/platform.processor", \
                # "http://tizen.org/feature/web.service", \
                # "http://tizen.org/feature/humanactivitymonitor", \
                # "http://tizen.org/feature/media.video_recording", \
                # "http://tizen.org/feature/media.image_capture", \
                # "http://tizen.org/feature/media.audio_recording", \
                # "http://tizen.org/feature/screen.shape", \
                # "http://tizen.org/feature/input.rotating_bezel", \
                # "http://tizen.org/feature/screen.shape.circle", \
                # "http://tizen.org/feature/screen.shape.rectangle", \
                # "http://tizen.org/feature/network.internet", \
                # "http://tizen.org/feature/network.nfc.card_emulation.hce", \
                # "http://tizen.org/feature/network.nfc.tag", \
                # "http://tizen.org/feature/network.nfc.p2p", \
                # "http://tizen.org/feature/tv.audio", \
                # "http://tizen.org/feature/tv.tuner", \
                # "http://tizen.org/feature/tv.display", \
                # "http://tizen.org/feature/tv.inputdevice", \
                # "http://tizen.org/feature/tv.pip", \
                # "http://tizen.org/feature/network.net_proxy", \
                # "http://tizen.org/feature/sensor.sleep_monitor", \
                # "http://tizen.org/feature/sensor.gyroscope_rotation_vector", \
                # "http://tizen.org/system/key.volume", \
                # "http://tizen.org/system/key.menu", \
                # "http://tizen.org/system/key.back", \
                # "http://tizen.org/feature/vulkan.version.1_0", \
                # "http://tizen.org/feature/iot.ocf", \
                # "http://tizen.org/feature/tv.information"]

        capabilities = ET.Element('capabilities')
        capabilities.set('xmlns:xsi', \
                         "http://www.w3.org/2001/XMLSchema-instance")
        capabilities.set('xsi:noNamespaceSchemaLocation', \
                         "capability.xsd")
        # for key in keys:
            # if key in capability_dict.keys():
        for key in capability_dict.keys():
                capability = ET.SubElement(capabilities, \
                                           "capability", name=key)
                key_type = capability_dict[key]['type']
                val = capability_dict[key]['val']
                if key_type == 'bool':
                    capability.set('type', 'boolean')
                    capability.set('support', val)
                elif key_type == 'string':
                    capability.set('type', 'String')
                    capability.set('support', 'true')
                    value = ET.SubElement(capability, 'value')
                    value.text = val
                elif key_type == 'int':
                    capability.set('type', 'Integer')
                    capability.set('support', 'true')
                    value = ET.SubElement(capability, 'value')
                    value.text = val
        xmlstr = minidom.parseString(ET.tostring(capabilities)) \
            .toprettyxml(indent="    ", encoding="UTF-8")

        with open(capability_file, 'w') as f:
            f.write(xmlstr.decode('utf-8'))

        if os.path.exists(capability_file) is False:
            return False

        return True

    def GetOpenglesTextureFormat(self):
        key = "http://tizen.org/feature/opengles.texture_format"
        texture_format = ""
        texture_format_delimiter = "/"
        utc_key = key + ".utc"
        if utc_key in self.dict.keys():
            if self.dict[utc_key]['val'] == 'true':
                texture_format += "utc"
        ptc_key = key + ".ptc"
        if ptc_key in self.dict.keys():
            if self.dict[ptc_key]['val'] == 'true':
                if texture_format != "":
                    texture_format += texture_format_delimiter
                texture_format += "ptc"
        etc_key = key + ".etc"
        if etc_key in self.dict.keys():
            if self.dict[etc_key]['val'] == 'true':
                if texture_format != "":
                    texture_format += texture_format_delimiter
                texture_format += "etc"
        threedc_key = key + ".3dc"
        if threedc_key in self.dict.keys():
            if self.dict[threedc_key]['val'] == 'true':
                if texture_format != "":
                    texture_format += texture_format_delimiter
                texture_format += "3dc"
        atc_key = key + ".ptc"
        if atc_key in self.dict.keys():
            if self.dict[atc_key]['val'] == 'true':
                if texture_format != "":
                    texture_format += texture_format_delimiter
                texture_format += "atc"
        pvrtc_key = key + ".pvrtc"
        if pvrtc_key in self.dict.keys():
            if self.dict[pvrtc_key]['val'] == 'true':
                if texture_format != "":
                    texture_format += texture_format_delimiter
                texture_format += "pvrtc"
        if texture_format == "":
            return
        else:
            self.dict[key] = {'type': 'string', 'val': texture_format}

    def GetPlatformCoreFpuArch(self):
        key = "http://tizen.org/feature/platform.core.fpu.arch"
        core_fpu_arch = ""
        core_fpu_arch_delimiter = " | "
        sse2_key = key + ".sse2"
        if sse2_key in self.dict.keys():
            if self.dict[sse2_key]['val'] == 'true':
                core_fpu_arch += "sse2"
        sse3_key = key + ".sse3"
        if sse3_key in self.dict.keys():
            if self.dict[sse3_key]['val'] == 'true':
                if core_fpu_arch != "":
                    core_fpu_arch += core_fpu_arch_delimiter
                core_fpu_arch += "sse3"
        ssse3_key = key + ".ssse3"
        if ssse3_key in self.dict.keys():
            if self.dict[ssse3_key]['val'] == 'true':
                if core_fpu_arch != "":
                    core_fpu_arch += core_fpu_arch_delimiter
                core_fpu_arch += "ssse3"
        vfpv2_key = key + ".vfpv2"
        if vfpv2_key in self.dict.keys():
            if self.dict[vfpv2_key]['val'] == 'true':
                if core_fpu_arch != "":
                    core_fpu_arch += core_fpu_arch_delimiter
                core_fpu_arch += "vfpv2"
        vfpv3_key = key + ".vfpv3"
        if vfpv3_key in self.dict.keys():
            if self.dict[vfpv3_key]['val'] == 'true':
                if core_fpu_arch != "":
                    core_fpu_arch += core_fpu_arch_delimiter
                core_fpu_arch += "vfpv3"
        vfpv4_key = key + ".vfpv4"
        if vfpv4_key in self.dict.keys():
            if self.dict[vfpv4_key]['val'] == 'true':
                if core_fpu_arch != "":
                    core_fpu_arch += core_fpu_arch_delimiter
                core_fpu_arch += "vfpv4"
        if core_fpu_arch == "":
            return
        else:
            self.dict[key] = {'type': 'string', 'val': core_fpu_arch}

    def GetIsBluetoothAlwaysOn(self):
        key = "http://tizen.org/capability/network.bluetooth.always_on"
        profile_key = "http://tizen.org/feature/profile"
        if profile_key in self.dict.keys():
            profile = self.dict["http://tizen.org/feature/profile"]['val']
            val = 'false'
            if profile == 'MOBILE':
                val = 'false'
            elif profile == 'WEARABLE':
                val = 'false'
            elif profile == 'TV':
                val = 'true'
            self.dict[key] = {'type': 'bool', 'val': val}

    def GetPlatformVersionName(self):
        key = "http://tizen.org/feature/platform.version.name"
        platform_key = "http://tizen.org/system/platform.name"
        if platform_key in self.dict.keys():
            plat_name = self.dict[platform_key]['val']
            self.dict[key] = {'type': 'string', 'val': plat_name}

    def GetNativeAPIVersion(self):
        key = "http://tizen.org/feature/platform.core.api.version"
        native_api_key = "http://tizen.org/feature/platform.native.api.version"
        if native_api_key in self.dict.keys():
            api_ver = self.dict[native_api_key]['val']
            self.dict[key] = {'type': 'string', 'val': api_ver}

    def GetCPUFreq(self):
        model_name_key = "http://tizen.org/system/model_name"
        if model_name_key in self.dict.keys():
            cpu_info_key = "http://tizen.org/feature/platform.core.cpu.frequency"
            if self.dict[model_name_key]['val'] == 'Emulator':
                cpu_info_file = os.path.join(Constants.LOCAL_SHELL_TEMP_PATH % \
                                             self.deviceId, 'cpuinfo')
                if Constants.checkFileExists(cpu_info_file) is False:
                    LOGGER.error('cpuinfo_max_freq file is missing')
                else:
                    cpufreq = ""
                    with open(cpu_info_file, 'r') as f:
                        for line in f.readlines():
                            if line.startswith('cpu MHz'):
                                cpufreq = int(line.split(':')[1].strip().split('.')[0])
                    self.dict[cpu_info_key] = {'type': 'int', 'val': (str(cpufreq))}
            else:
                cpu_info_file = os.path.join(Constants.LOCAL_SHELL_TEMP_PATH % \
                                             self.deviceId, 'cpuinfo_max_freq')
                if Constants.checkFileExists(cpu_info_file) is False:
                    LOGGER.error('cpuinfo_max_freq file is missing')
                else:
                    cpufreq = ""
                    with open(cpu_info_file, 'r') as f:
                        for line in f.readlines():
                            # cpufreq = (int(line))/1000
                            cpufreq = int(int(line) / 1000)
                    self.dict[cpu_info_key] = {'type': 'int', 'val': (str(cpufreq))}

    def run(self):
        self.parseModelConfigXml()
        self.parseInfoIni()
        self.GetOpenglesTextureFormat()
        self.GetPlatformCoreFpuArch()
        self.GetIsBluetoothAlwaysOn()
        self.GetPlatformVersionName()
        self.GetNativeAPIVersion()
        self.GetCPUFreq()
        # GetTizenId
        self.loadDictIntoJson()

        if self.makeBuildInfo() is False:
            if Constants.checkFileExists(os.path.join(Constants.SOURCE_XML_PATH % \
                                                      self.tizenVer, 'buildinfo.xml')) is False:
                LOGGER.error("buildinfo.xml file not found on given Source path")
                return False
            else:
                LOGGER.info('Copying buildinfo.xml from Source to Destination')
                os.system('cp {} {}'.format(os.path.join(Constants.SOURCE_XML_PATH % \
                                                         self.tizenVer, 'buildinfo.xml'),
                                            Constants.LOCAL_SHELL_TEMP_PATH % self.deviceId))
        if self.makeCapabilities() is False:
            if Constants.checkFileExists(os.path.join(Constants.SOURCE_XML_PATH % \
                                                      self.tizenVer, 'capability.xml')) is False:
                LOGGER.error("capability.xml file not found on given Source path")
                return False
            else:
                LOGGER.info('Copying capability.xml from Source to Destination')
                os.system('cp {} {}'.format(os.path.join(Constants.SOURCE_XML_PATH % \
                                                         self.tizenVer, 'capability.xml'),
                                            Constants.LOCAL_SHELL_TEMP_PATH % self.deviceId))
        ret = SdbManager.sdbPush(self.deviceId, Constants.LOCAL_CAPABILITY_PATH % \
                                 self.deviceId, Constants.getDEVICE_CAPABILITY_PATH(self.tizenVer))
        if ret is False:
            LOGGER.error("Pushing capability.xml into device failed")
        ret = SdbManager.sdbPush(self.deviceId, Constants.LOCAL_BUILD_INFO_PATH % \
                                 self.deviceId, Constants.getDEVICE_BUILD_INFO_PATH(self.tizenVer))
        if ret is False:
            LOGGER.error("Pushing buildinfo.xml into device failed")
        return True
