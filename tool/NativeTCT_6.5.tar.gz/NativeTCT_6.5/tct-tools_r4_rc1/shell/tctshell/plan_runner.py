#!/usr/bin/python
#
# Copyright (C) 2012 Intel Corporation
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
# 02110-1301, USA.
#
# Authors:
#              Tang, Shaofeng <shaofeng.tang@intel.com>

from constants import Constants
from xml.etree import ElementTree
from logmanager import LOGGER
import xml.etree.ElementTree as etree
import os
import os.path
import sys
import glob
import re


class SuitePackage:
    def __init__(self, profile, file_name, launcher, category, auto_count, \
            manual_count):
        self.file = file_name
        self.profile = profile
        m = re.split(Constants.REGEX_FOR_SPLIT_PKG_NAME, file_name)
        self.name = m[0]
        self.auto_count = auto_count
        self.manual_count = manual_count
        self.total_count = auto_count + manual_count
        self.launcher = launcher
        self.category = category

    def to_xml(self):
        suite = ElementTree.Element('suite')
        suite.set('name', self.name)
        if self.launcher:
            suite.set('launcher', self.launcher)

        if self.category:
            suite.set('category', self.category)

        auto = ElementTree.Element('auto_tcn')
        auto.text = str(self.auto_count)
        suite.append(auto)
        manual = ElementTree.Element('manual_tcn')
        manual.text = str(self.manual_count)
        suite.append(manual)
        total = ElementTree.Element('total_tcn')
        total.text = str(self.total_count)
        suite.append(total)
        rpm_name = ElementTree.Element('pkg_name')
        rpm_name.text = self.profile + '/' + self.file
        suite.append(rpm_name)

        return suite


class PlanRunner:

    def __init__(self):
        self.suites = {}
        self.suite_paths = []
        self.plan_name = Constants.DEFAULT_PLAN_NAME
        self.profile = Constants.DEFAULT_PROFILE_NAME
        self.execute_type = Constants.DEFAULT_EXECUTE_TYPE

    def load_local_repo(self, path, tizenV, match, unmatch, plan_name, \
            profile, execute_type):
        try:
            self.plan_name = plan_name
            self.profile = profile
            self.execute_type = execute_type
            raw_paths = []
            repos = ['common', profile]
            for tp in repos:
                repo = '/'.join([path, tp])
                if not os.path.isdir(repo):
                    continue

                os.chdir(repo)
                for files in glob.glob("*" + match + "*"):
                    print "Matched File name: %s" % str(os.path.abspath(files))
                    if (unmatch is not None) and (re.search(unmatch, \
                            str(files))):
                        print "File %s is skipped with unmatch regex %s" \
                                % (str(files), unmatch)
                    else:
                        raw_paths.append(os.path.join(repo, str(files)))

            if len(raw_paths) < 1:
                sys.exit("Match regex: [%s] No matching suite package found." \
                        % match)

            self.suite_paths = self._chooseProfile(raw_paths)
            for files in self.suite_paths:
                profile = os.path.basename(os.path.dirname(files))
                auto, manual, launcher, category = \
                        self.get_count_launcher_category(\
                        os.path.basename(files), files)
                suite = SuitePackage(profile, os.path.basename(files), \
                        launcher, category, auto, manual)
                self.suites[suite.name] = suite
                Constants.clean_unzip_file()
        except Exception, e:
            print "[ Error happen when reading the local repository," + \
                    " error: %s ]\n" % e

    def _chooseProfile(self, path_suites):
        suite_profiles = {}
        filtered_suites = []
        suite_repo = os.path.dirname(os.path.dirname(path_suites[0]))
        for suite_path in path_suites:
            suite_zipname = os.path.basename(suite_path)
            sprofile = os.path.basename(os.path.dirname(suite_path))
            if not suite_zipname in suite_profiles:
                suite_profiles[suite_zipname] = []

            suite_profiles[suite_zipname].append(sprofile)

        for suiteName, suiteProfile in suite_profiles.items():
            suite_name = "-".join(suiteName[:-4].split("-")[:-1])
            if len(suiteProfile) == 1:
                suite_profiles[suiteName] = suiteProfile[0]
                continue

            print "\nMultiple profiles for [%s] \
                    :\n----------------------------------------------" \
                    % suite_name

            for profile_i in suiteProfile:
                print " - %s" % profile_i

            suite_profile = None
            while not suite_profile in suiteProfile:
                suite_profile = raw_input("\nChoose profile: ")

            suite_profiles[suiteName] = suite_profile

        check_profile = None
        multiProfiles = False
        for suiteName, suiteProfile in suite_profiles.items():
            if suiteProfile != 'common':
                if check_profile is not None and check_profile != suiteProfile:
                    multiProfiles = True

                if check_profile is None:
                    check_profile = suiteProfile

            filtered_suites.append(\
                    os.path.join(suite_repo, suiteProfile, suiteName))

        if multiProfiles:
            LOGGER.warning("WARNING: \
                    Multiple suites run with different profiles")

        return filtered_suites

    def get_count_launcher_category(self, filesname, filepath):
        Constants.unzip_package(filepath)
        m = re.split(Constants.REGEX_FOR_SPLIT_PKG_NAME, filesname)
        name = m[0]
        test_file = os.path.expanduser("~") + "/" + \
                Constants.DEFAULT_PLAN_FILE + "/opt/" + name + "/tests.xml"
        if not os.path.exists(test_file):
            print("Can't find the test file : [%s]" % test_file)
            return 0, 0, Constants.WRT_LAUNCHER_CMD, None

        return self.__read_test_xml(test_file)

    def __read_test_xml(self, test_file):
        autocnt = manualcnt = 0
        test_xml_temp = etree.parse(test_file)

        for test_xml_temp_suite in test_xml_temp.getiterator('suite'):
            suite_launcher = test_xml_temp_suite.get('launcher')
            suite_category = test_xml_temp_suite.get('category')
            autocnt = manualcnt = 0
            for tset in test_xml_temp_suite.getiterator('set'):
                set_autocnt, set_manualcnt = self.__get_set_casecnt(tset)
                autocnt += set_autocnt
                manualcnt += set_manualcnt

        return autocnt, manualcnt, suite_launcher, suite_category

    def __get_set_casecnt(self, tset):
        set_autocnt = set_manualcnt = 0
        for tcase in tset.getiterator('testcase'):
            exetype = tcase.get('execution_type')
            if exetype == "auto":
                set_autocnt += 1
            elif exetype == "manual":
                set_manualcnt += 1

        return set_autocnt, set_manualcnt

    def to_xml(self, xml_name):
        print "generating plan to %s" % xml_name
        root = ElementTree.Element('ns3:testplan')
        root.set('name', self.plan_name)
        root.set('profile', self.profile)
        root.set('xmlns', '')
        root.set('xmlns:ns3', 'http://www.example.org/plan/')
        element = ElementTree.Element('execute_type')
        element.text = self.execute_type
        root.append(element)
        for suite_name in self.suites:
            suite = self.suites[suite_name]
            root.append(suite.to_xml())

        Constants.indent(root)
        tree = ElementTree.ElementTree()
        tree._setroot(root)
        tree.write(xml_name, encoding="utf-8")
