#!/usr/bin/python
import os
import re
from .constants import Constants
from .shellwrapper import IntentionType
from xml.etree import ElementTree
import xml.etree.ElementTree as etree
from .result_summary import ResultSummary
from .logmanager import LOGGER
from .shellplanner import *

g_wrapper = None
def _verifyPlan(planfile, tizenVersion):
    xml_tree = ElementTree.parse(planfile)
    xml_root = xml_tree.getroot()
    executeType = xml_root.find('execute_type')
    suites = xml_root.findall('suite')
    if executeType is None:
        LOGGER.warning("[WARNING] Plan xml:" + \
                " No execute type specified in plan xml")
    elif not executeType.text in ['All', 'Auto', 'Manual']:
        LOGGER.warning("[WARNING] Plan xml: Execute type in plan xml: %s. \
                Execute type should be either All,  Auto or Manual" \
                % executeType.text)
    if len(suites) < 1:
        LOGGER.warning("No suites specified in plan xml")
    return True


def _verifySuite(suite, tizenVersion):
    try:
        suite_name = suite.get('name')
        launcher = suite.get('launcher')
        auto_tcn = suite.find('auto_tcn')
        manual_tcn = suite.find('manual_tcn')
        total_tcn = suite.find('total_tcn')
        if suite_name is None:
            LOGGER.warning("[ERROR] Plan xml: Suite name is not specified")
            return False

        if suite.find('pkg_name') is None:
            LOGGER.warning("[ERROR] Plan xml:" + \
                    " Package name is not specified for suite: %s" % suite_name)
            return False

        suite_pkg_name = suite.find('pkg_name').text
        suite_zipname = os.path.basename(suite_pkg_name)
        suite_path = os.path.join(Constants.SUITES_REPOSITORY % tizenVersion, \
            suite_pkg_name)
        if not os.path.isfile(suite_path):
            LOGGER.warning("suite_path does not exist. [%s]" % suite_path)
            return False
        auto_num, manual_num, suite_launcher, suite_category, tc_exist, s_name\
         = _get_suiteInfo(suite_zipname, suite_path, None)

        if suite_name != s_name:
            LOGGER.warning("[ERROR] Plan xml: Suite name [%s] does not match with \
                    suite package name" % suite_name)
            return False

        if launcher != suite_launcher:
            LOGGER.warning("[WARNING] Plan xml: \
                Suite [%s] running on a different launcher" % suite_name)

        if auto_tcn is None:
            LOGGER.warning("[ERROR] Plan xml: \
                Suite [%s] Auto testcase count not specified" % suite_name)
            return False
        elif auto_tcn.text != str(auto_num):
            LOGGER.warning("[WARNING] Plan xml: \
                Suite [%s] Wrong auto testcase count" % suite_name)

        if manual_tcn is None:
            LOGGER.warning("[ERROR] Plan xml: \
                Suite [%s] Manual testcase count not specified" % suite_name)
            return False
        elif manual_tcn.text != str(manual_num):
            LOGGER.warning("[WARNING] Plan xml: \
                Suite [%s] Wrong manual testcase count" % suite_name)

        if total_tcn is None:
            LOGGER.warning("[ERROR] Plan xml: \
                Suite [%s] Total testcase count not specified" % suite_name)
            return False
        elif total_tcn.text != str(manual_num + auto_num):
            LOGGER.warning("[WARNING] Plan xml: \
                Suite [%s] Wrong total testcase count" % suite_name)

        Constants.clean_unzip_file()
    except Exception as ex:
        LOGGER.warning(str(ex))
    return True


def _get_suiteInfo(filesname, filepath, tc_name):
    Constants.unzip_package(filepath)
    m = re.split(Constants.REGEX_FOR_SPLIT_PKG_NAME, filesname)
    name = m[0]
    test_file = os.path.expanduser("~") + "/" + Constants.DEFAULT_PLAN_FILE + \
            "/opt/" + name + "/tests.xml"
    LOGGER.debug("Getting information from suite package: %s" % test_file)
    if not os.path.exists(test_file):
        LOGGER.warning("Can't find the test file...")
        return 0, 0, Constants.WRT_LAUNCHER_CMD, None
    return _read_xml_suiteInfo(test_file, tc_name)


def _read_xml_suiteInfo(test_file, tc_name):
    try:
        autocnt = manualcnt = 0
        test_xml_temp = etree.parse(test_file)
        tc_exist = False
        for test_xml_temp_suite in test_xml_temp.getiterator('suite'):
            suite_name = test_xml_temp_suite.get('name')
            suite_launcher = test_xml_temp_suite.get('launcher')
            suite_category = test_xml_temp_suite.get('category')
            autocnt = manualcnt = 0
            for tset in test_xml_temp_suite.getiterator('set'):
                set_autocnt, set_manualcnt, tcCheck = \
                        _read_xml_tcInfo(tset, tc_name)
                autocnt += set_autocnt
                manualcnt += set_manualcnt
                if tcCheck:
                    tc_exist = True

        return autocnt, manualcnt, suite_launcher, suite_category, tc_exist, \
            suite_name

    except Exception as msg:
        LOGGER.warning("error read xml %s package : %s" % \
                (str(test_file), str(msg)))
        return 0, 0, None, None, None, None


def _read_xml_tcInfo(tset, tc_name):
    set_autocnt = set_manualcnt = 0
    tcCheck = False
    for tcase in tset.getiterator('testcase'):
        tcId = tcase.get('id')
        exetype = tcase.get('execution_type')
        if exetype == "auto":
            set_autocnt += 1
        elif exetype == "manual":
            set_manualcnt += 1
        if tc_name == tcId:
            tcCheck = True

    return set_autocnt, set_manualcnt, tcCheck


# return : TctShellSuite []
def _parsTestPlan(file_path, plan_name, deviceId, executeType, tizenVersion, \
        resultFolder, stubPort, skip_package, skip_tc, devmgr, \
        pre_test=None, post_test=None):
    suites = []
    profile = ""
    if not _verifyPlan(file_path, tizenVersion):
        LOGGER.warning("Please check the plan xml file: %s" % file_path)
        return None

    LOGGER.debug("parsing Test Plan : " + plan_name)
    xml_tree = ElementTree.parse(file_path)
    xml_root = xml_tree.getroot()
    if xml_root.get('profile') is not None:
        profile = xml_root.get('profile')
        Constants.GlobalProfile = xml_root.get('profile')

    if not executeType:
        executeType = ExecuteType.createExecuteType(\
                xml_root.find('execute_type').text)

    for xml_suite in xml_root.findall('suite'):
        if not _verifySuite(xml_suite, tizenVersion):
            continue

        packName = xml_suite.get("name")
        package_name = xml_suite.find("pkg_name").text
        LOGGER.info("package_name is " + str(package_name))
        if Constants.GlobalProfile == "":
            package_list = package_name.split('/')
            Constants.GlobalProfile = package_list[0]
            LOGGER.info("GlobalProfile is " + str(Constants.GlobalProfile))

        if skip_package and str(skip_package).find(packName) > -1:
            LOGGER.info("[skip package : %s]" % packName)
        else:
            suite = TctShellSuite(packName, None, \
                xml_suite.find("auto_tcn").text, \
                xml_suite.find("manual_tcn").text, \
                xml_suite.find("pkg_name").text, \
                xml_suite.get("launcher"), xml_suite.get("category"), \
                tizenVersion, skip_tc, devmgr, \
                pre_test=pre_test, \
                post_test=post_test)
            suites.append(suite)

    sortPkg = g_wrapper.isSortPackage()
    if (sortPkg == True):
        def sortSuite(suites):
            return suites.suiteName
        suites.sort(key=sortSuite)
    plan = TctShellPlan(plan_name, devmgr, deviceId, profile, executeType, \
            suites, tizenVersion, resultFolder, stubPort)

    if Constants.isDistMode():
        if not plan.setup_distribute(sortPkg):
            raise

    return [plan]


def _parsTestProfile(path_suites, deviceId, executeType, tizenV, profile, \
        resultFolder, stubPort, skip_package, skip_tc, devmgr, \
        distribute_count, pre_test=None, post_test=None):
    suites = []
    LOGGER.debug("Preparing Test Suite ")
    suite_profile = os.path.basename(os.path.dirname(path_suites[0]))
    Constants.GlobalProfile = suite_profile

    for counter, suite_path in enumerate(path_suites):
        counter = counter + 1
        suite_profile = os.path.basename(os.path.dirname(suite_path))
        suite_zipname = os.path.basename(suite_path)
        suite_name = _geneSuiteName(suite_zipname, tizenV)
        auto_num, manual_num, suite_launcher, suite_category, tc_exist, s_name\
                = _get_suiteInfo(suite_zipname, suite_path, None)

        suite_tizenVer = tizenV
        suite_pkg_name = os.path.join(suite_profile, \
                os.path.basename(suite_path))

        dist_res = None
        if distribute_count:
            dist_res = _check_dist_number(counter, distribute_count)

        if skip_package and str(skip_package).find(suite_name) > -1:
            LOGGER.info("[skip package : %s]" % suite_name)
        elif auto_num == 0 and manual_num == 0:
            pass
        else:
            suite = TctShellSuite(suite_name, None, auto_num, manual_num, \
                suite_pkg_name, suite_launcher, suite_category, \
                suite_tizenVer, skip_tc, devmgr, \
                pre_test=pre_test, \
                post_test=post_test)

            if not distribute_count:
                suites.append(suite)
            elif dist_res:
                suites.append(suite)

        Constants.clean_unzip_file()
    sortPkg = g_wrapper.isSortPackage()
    if (sortPkg == True):
        def sortSuite(suites):
            return suites.suiteName
        suites.sort(key=sortSuite)
    temp_plan_name = profile
    plan = TctShellPlan(temp_plan_name, devmgr, deviceId, profile, executeType, \
            suites, tizenV, resultFolder, stubPort)

    if Constants.isDistMode():
        if not plan.setup_distribute(sortPkg):
            raise

    return [plan]


def _parsTestSuite(path_suites, deviceId, executeType, tizenVersion, tc_name, \
        resultFolder, stubPort, devmgr, skip_package, skip_tc=None, \
        pre_test=None, post_test=None):
    #type(suites) -> list
    suites = []
    LOGGER.debug("Preparing Test Suite ")
    suite_profile = os.path.basename(os.path.dirname(path_suites[0]))
    for suite_path in path_suites:
        suite_profile = os.path.basename(os.path.dirname(suite_path))
        suite_zipname = os.path.basename(suite_path)
        suite_name = _geneSuiteName(suite_zipname, tizenVersion)
        auto_num, manual_num, suite_launcher, suite_category, tc_exist, s_name\
                = _get_suiteInfo(suite_zipname, suite_path, tc_name)
        if tc_name is not None and not tc_exist:
            LOGGER.warning("Testcase Id : [%s] does not exist in suite : [%s]" \
                    % (tc_name, suite_name))
            return None

        suite_tizenVer = tizenVersion
        suite_pkg_name = os.path.join(suite_profile, \
		os.path.basename(suite_path))
        if (skip_package and str(skip_package).find(suite_name) > -1):
            LOGGER.info("[skip package : %s]" % suite_name)
        else:
            suite = TctShellSuite(suite_name, tc_name, auto_num, manual_num, \
		    suite_pkg_name, suite_launcher, suite_category, \
		    suite_tizenVer, skip_tc, devmgr, \
		    pre_test=pre_test, \
		    post_test=post_test)
            suites.append(suite)
        Constants.clean_unzip_file()

    temp_plan_name = "temp_plan_name"
    if (Constants.GlobalProfile is None) or (Constants.GlobalProfile == ""):
         Constants.GlobalProfile = suite_profile
    sortPkg = g_wrapper.isSortPackage()
    if (sortPkg == True):
        def sortSuite(suites):
            return suites.suiteName
        suites.sort(key=sortSuite)
    plan = TctShellPlan(temp_plan_name, devmgr, deviceId, Constants.GlobalProfile, executeType, \
            suites, tizenVersion, resultFolder, stubPort)

    if Constants.isDistMode():
        if not plan.setup_distribute(sortPkg):
            raise

    return [plan]


def _parsTestCase(path_suites, deviceId, executeType, tizenVersion, \
        testcase_id, resultFolder, stubPort, skip_package, devmgr):
    LOGGER.debug("parsing Test Case : " + str(testcase_id))

    return _parsTestSuite(path_suites, deviceId, executeType, tizenVersion, \
            testcase_id, resultFolder, stubPort, devmgr, skip_package)


def _parsAutoPlan(planFile, plan_name, executeType, tizenVer, \
        resultFolderPath, stubPort, skip_package, skip_tc, \
        devmgr, pre_test=None, post_test=None):
    if not _verifyPlan(planFile, tizenVer):
        LOGGER.warning("Please check the plan xml file: %s" % planFile)
        return None

    LOGGER.debug("parsing Test Plan : " + planFile)
    suites = []
    profile = ""
    planList = []
    deviceLen = devmgr.getDeviceSize()
    if deviceLen < 1:
        LOGGER.error("No connected device")
        return None

    LOGGER.info("Plan [%s] will be distributed to %d devices" \
            % (plan_name, deviceLen))
    devices = devmgr.getSdbDeviceList()
    xml_tree = ElementTree.parse(planFile)
    xml_root = xml_tree.getroot()
    if xml_root.get('profile') is not None:
        profile = xml_root.get('profile')
        Constants.GlobalProfile = profile

    if not executeType:
        executeType = ExecuteType.createExecuteType(\
                xml_root.find('execute_type').text)

    for dev in range(deviceLen):
        planTempName = plan_name + str(dev)
        devId = devices[dev].getDeviceId()
        planList.append(TctShellPlan(planTempName, devId, profile, \
                executeType, [], tizenVer, resultFolderPath, stubPort, \
                plan_name))

    for xml_suite in xml_root.findall('suite'):
        if not _verifySuite(xml_suite, tizenVer):
            continue
        autoCount = int(xml_suite.find("auto_tcn").text)
        category = xml_suite.get("category")
        if category and category.find('Runtime') > -1:
            etime = autoCount * (Constants.SUITE_TEST_EXPECTED_TIME + 2)
        else:
            etime = (autoCount * 2) + Constants.SUITE_TEST_EXPECTED_TIME

        suite_name = xml_suite.get("name")
        if skip_package and str(skip_package).find(suite_name) > -1:
            LOGGER.error("[skip package : %s]" % suite_name)
        else:
            suite = TctShellSuite(suite_name, None, \
                xml_suite.find("auto_tcn").text, xml_suite.find("manual_tcn").text,\
                xml_suite.find("pkg_name").text, xml_suite.get("launcher"), \
                xml_suite.get("category"), tizenVer, skip_tc, \
                devmgr, pre_test=pre_test, post_test=post_test)

            suite.setExpectedTime(etime)
            if suite.suite_pkg_name is None:
                LOGGER.warning("suite: [%s] has missing information" \
                       % suite.suiteName)
                return None
            suites.append(suite)
    sortPkg = g_wrapper.isSortPackage()
    if (sortPkg == True):
        def sortSuite(suites):
            return suites.suiteName
        suites.sort(key=sortSuite)
    else:
        suites.sort(key=lambda x: x.expectedTime, reverse=True)
    for suite in suites:
        minPlan = min(planList, key=lambda x: x.expectedTime)
        minPlan.addExpectedTime(suite.getExpectedTime())
        minPlan.addSuite(suite)

    for plan in planList:
        LOGGER.debug("%s has ECT: %d" % (plan.getPlanName(), \
                plan.expectedTime))

    return planList


def _parsResultForRerun(wrapper, skip_package, skip_tc, devmgr, \
        distribute_count, pre_test=None, post_test=None):
    result = wrapper.get_result_for_rerun()
    rerun_plan_creator = ResultSummary()
    rerun_data = rerun_plan_creator.prepareRerun(result)
    if len(rerun_data) < 1:
        LOGGER.debug("No unpassed results to rerun")
        return None

    plans = []
    for plan_path, rerun_info in rerun_data.items():
        planFolder = plan_path
        intention_info = rerun_info[0]
        suites_path = rerun_info[1]
        plan_name = intention_info[0]
        executeType = ExecuteType.createExecuteType(intention_info[1])
        profile = intention_info[2]
        Constants.GlobalProfile = profile
        tizenVer = intention_info[3]
        deviceId = intention_info[4]

        if len(suites_path) < 1:
            LOGGER.debug("No unpassed results to rerun in plan: [%s]" \
                    % plan_name)
            continue

        if devmgr.getDevice(deviceId) is None:
            LOGGER.warning("WARNING: \
                    Device used for the test is not connected: \
                    device id: %s" % deviceId)
            LOGGER.warning("WARNING: Rerunning the test in a different device")
            if Constants.isDistMode():
                deviceId = None
            else:
                deviceId = wrapper.get_deviceId()

        suites = []
        resultFolderPath = wrapper.get_resultFolderPath()
        if not resultFolderPath:
            resultFolderPath = planFolder

        for counter, suite_path in enumerate(suites_path):
            counter = counter + 1
            suite_pkg_name = os.path.join(os.path.basename(\
                    os.path.dirname(suite_path)), os.path.basename(suite_path))
            suite_zipname = os.path.basename(suite_pkg_name)
            suite_name = _geneSuiteName(suite_zipname, tizenVer)
            auto_num, manual_num, suite_launcher, suite_category, \
                    tc_exist, s_name = _get_suiteInfo(suite_zipname, \
                    suite_path, None)

            dist_res = None
            if distribute_count:
                dist_res = _check_dist_number(counter, distribute_count)

            if skip_package and str(skip_package).find(suite_name) > -1:
                LOGGER.error("[skip package : %s]" % suite_name)
            else:
                suite = TctShellSuite(suite_name, None, auto_num, manual_num, \
                        suite_pkg_name, suite_launcher, suite_category, \
                        tizenVer, skip_tc, devmgr, \
                        pre_test=pre_test, \
                        post_test=post_test)

                if not distribute_count:
                    suites.append(suite)
                elif dist_res:
                    suites.append(suite)
        sortPkg = g_wrapper.isSortPackage()
        if (sortPkg == True):
            def sortSuite(suites):
                return suites.suiteName
            suites.sort(key=sortSuite)
        plan = TctShellPlan(plan_name, devmgr, deviceId, profile, executeType, suites,\
                tizenVer, resultFolderPath, wrapper.get_default_stubPort())
        plan.setRerunning(True)
        plans.append(plan)

    if Constants.isDistMode():
        for plan in plans:
            if not plan.setup_distribute(sortPkg):
                raise

    return plans


def _geneSuiteName(suite_zipname, _tizenV):
    suite_name = ""
    match_ext = ""

    if _tizenV:
        match_ext = "-{}.zip".format(_tizenV.split('_')[-1])
        find_idx = suite_zipname.find(match_ext)
        if find_idx > -1:
            suite_name = suite_zipname[0:find_idx]
        else:
            LOGGER.warning("Not found suite name")

    return suite_name


MATCH_CT = 0
def _check_dist_number(suite_num, dist_ct):
    global MATCH_CT
    total = int(dist_ct.split('-')[0])
    curr = int(dist_ct.split('-')[1])

    if curr > total:
        LOGGER.error("distribute command error")
        raise

    if MATCH_CT == 0:
        MATCH_CT = MATCH_CT + curr
    if suite_num == MATCH_CT:
        MATCH_CT = MATCH_CT + total
        return True
    else:
        return False


class IntentionGenerator:
    # return : bool
    @staticmethod
    def genIntentionData(wrapper, devmgr):
        skip_package = wrapper.get_skip_package()
        skip_tc = wrapper.get_skip_tc()
        pre_test = wrapper.get_pre_test()
        post_test = wrapper.get_post_test()
        distribute_count = wrapper.get_distribute_count()
        global  g_wrapper
        g_wrapper = wrapper
        sortPkg = wrapper.isSortPackage()
        if (sortPkg == True):
            Constants.set_sort_enable(sortPkg);
        if wrapper.get_running_mode() == Constants.RUNNING_MODE_RERUN:
            return _parsResultForRerun(wrapper, skip_package, \
                    skip_tc, devmgr, distribute_count)

        intention_type = wrapper.getIntentionType()
        deviceId = None
        if not (intention_type == IntentionType.AutoPlan or \
                Constants.isDistMode()):
            deviceId = wrapper.get_deviceId()
        else:
            deviceId = None

        tcId = wrapper.get_testcase_id()
        executeType = wrapper.get_execute_type()
        suites = wrapper.get_suites()
        tizenVer = wrapper.get_tizenV()
        resultFolderPath = wrapper.get_resultFolderPath()
        stubPort = wrapper.get_default_stubPort()

        if (sortPkg == True):
            suites.sort()
        if intention_type == -1:
            return None

        if (intention_type == IntentionType.TestPlan or \
            intention_type == IntentionType.TestProfile or \
            intention_type == IntentionType.TestSuite) and \
            not Constants.isDistMode():
            if not devmgr.isDeviceAvailable(deviceId):
                LOGGER.error("Device [%s] is not connected" % deviceId)
                LOGGER.error("Required devices not connected properly")
                return None

        if intention_type == IntentionType.TestPlan:
            name = wrapper.get_plan_name()
            planFile = wrapper.get_planfile()
            plans = _parsTestPlan(planFile, name, deviceId, executeType, \
                    tizenVer, resultFolderPath, stubPort, skip_package, \
                    skip_tc, devmgr,pre_test=pre_test,  \
                    post_test=post_test)
        elif intention_type == IntentionType.TestCase:
            plans = _parsTestCase(suites, deviceId, executeType, tizenVer, \
                    tcId, resultFolderPath, stubPort, skip_package, devmgr)
        elif intention_type == IntentionType.TestSuite:
            if(Constants.GlobalProfile == None) or (Constants.GlobalProfile == ""):
                    profile = wrapper.get_profile()
                    Constants.GlobalProfile = profile
            plans = _parsTestSuite(suites, deviceId, executeType, tizenVer, \
                    None, resultFolderPath, stubPort, devmgr, skip_package, \
                    skip_tc, pre_test=pre_test, post_test=post_test)
        elif intention_type == IntentionType.AutoPlan:
            name = wrapper.get_plan_name()
            autoFile = wrapper.get_autoplanfile()
            plans = _parsAutoPlan(autoFile, name, executeType, tizenVer, \
                    resultFolderPath, stubPort, skip_package, \
                    skip_tc, devmgr, pre_test=pre_test, post_test=post_test)
        elif intention_type == IntentionType.TestProfile:
            profile_suites = wrapper.get_profile_suites()
            if not profile_suites:
                return None
            profile = wrapper.get_profile()
            Constants.GlobalProfile = profile
            plans = _parsTestProfile(profile_suites, deviceId, executeType, \
                    tizenVer, profile, resultFolderPath, stubPort, \
                    skip_package, skip_tc, devmgr, distribute_count, \
                    pre_test=pre_test, post_test=post_test)
        return plans
