#!/usr/bin/python

import shutil
import os
import datetime

from multiprocessing import Lock

from .constants import Constants
from .sdbmanager import SdbManager
from .logmanager import LOGGER
from .exception import DevNotFoundErr


class MultiRunnPlan(object):
    INSTANCE = None
    runningPlans = {}
    _observers = []

    def __init__(self):
        self._observers = []
        if MultiRunnPlan.INSTANCE is not None:
            raise Exception('A TestSingleton instance already exists')

    @classmethod
    def getInstance(cls):
        if cls.INSTANCE is None:
            cls.INSTANCE = MultiRunnPlan()
        return cls.INSTANCE

    def attach(self, observer):
        if not observer in self._observers:
            self._observers.append(observer)
        else:
            LOGGER.debug("The observer already exists")

    def detach(self, observer):
        if observer in self._observers:
            self._observers.remove(observer)
        else:
            LOGGER.debug("[DEBUG] The observer does not exist")

    def notify(self):
        LOGGER.debug(" MultiRunnPlan Notify ")
        for observer in self._observers:
            observer.update()

    #param string plan id
    #param TctShellPlan plan
    def addPlan(self, planid, plan):
        if planid:
            self.runningPlans[planid] = plan
        else:
            self.runningPlans['test'] = plan

    #return int
    def getPlansSize(self):
        return len(self.runningPlans)

    def removePlans(self, plans):
        for plan in plans:
            self.runningPlans.pop(plan.name, None)

    def clearPlans(self):
        self.runningPlans.clear()

    #return dictionary
    def getPlanDict(self):
        return self.runningPlans

    #Param TctShellPlan
    #return bool
    def isSelectedDevAvailable(self, plan):
        currDevId = plan.getDeviceId()
        runnDevs = self.getRunnDevice()
        for rDev in runnDevs:
            if rDev == currDevId:
                LOGGER.debug("%s currently occupied with other plans." \
                        % currDevId)
                return False

        LOGGER.debug("%s is now available" % currDevId)
        return True

    #return String[]
    def getRunnDevice(self):
        runDev = []
        for rplan in self.runningPlans.values():
            if rplan.isRunning() == True:
                runDev.append(rplan.getDeviceId())
        return runDev

    def printRunnPlan(self):
        for rplan in self.runningPlans.values():
            LOGGER.debug("Name : %s , isStart : %s" \
                    % (rplan.getPlanName(), rplan.isRunning()))

    def setCurrPlanRunning(self, plan):
        currPlanName = plan.getPlanName()
        for rPlan in self.runningPlans.values():
            if rPlan.getPlanName() == currPlanName:
                rPlan.setRunning(True)
                return True
        return False


class TctShellPlan:
    resultFolderPath = ""
    isRun = False
    isFinish = False
    isRerun = False

    #PARAM name = Full_web_mobile#1(primary key)
    #PARAM deviceid = '0000d81b00006200'
    #PARAM profile = 'mobile' or 'wearable' or 'tv'
    #PARAM executeType = ExecuteType class
    #PARAM suites = TctShellSuite []
    #PARAM tizenVer = 'tizen_web_2.4'
    #PARAM resultFolderPath = '/opt/tct/tizen_web_2.4/shell/result/'
    #PARAM stubPort = 8000
    def __init__(self, name, devmgr, deviceId, profile, executeType, suites, \
                 tizenVer, resultFolderPath, stubPort=8000):
        self.suites = []
        self.name = name
        self.devmgr = devmgr
        self.deviceId = deviceId
        self.buildId = None
        self.profile = profile
        self.executeType = executeType
        self.unpass = None
        for suite in suites:
            LOGGER.info("List: suite's name = %s" % str(suite.getSuiteName()))
            self.suites.append(suite)
        self.tizenVer = tizenVer
        self.resultFolderPath = resultFolderPath
        self.expectedTime = 0
        self.stubPort = stubPort
        self.planLock = Lock()
        if self.resultFolderPath is None:
            folderName = self.name + "_" + \
                    datetime.datetime.now().strftime('%Y-%m-%d_%H:%M:%S.%f')
            self.resultFolderPath = Constants.RESULT_FOLDER \
                    % (self.tizenVer, folderName)

    def acquire(self):
        self.planLock.acquire(True)

    def release(self):
        self.planLock.release()

    def addExpectedTime(self, etime):
        self.expectedTime += etime

    def addSuite(self, suite):
        self.suites.append(suite)

    def getPlanName(self):
        return self.name

    def getProfile(self):
        return self.profile

    def getSuites(self):
        return self.suites

    def getDeviceId(self):
        return self.deviceId

    def setDeviceId(self, deviceId):
        self.acquire()
        if self.deviceId is None:
            LOGGER.debug("plan [%s] now has device ID [%s]" \
                    % (self.getPlanName(), deviceId))
            self.deviceId = deviceId
        self.release()

    def getBuildId(self):
        if not self.buildId:
            dev = self.devmgr.getDevice(self.deviceId)
            if dev:
                self.buildId = dev.getDeviceBuildId()

        return self.buildId

    def isRunning(self):
        return self.isRun

    def setRunning(self, run):
        self.isRun = run

    def isFinished(self):
        return self.isFinish

    def isReRunning(self):
        return self.isRerun

    def setRerunning(self, rerun):
        self.isRerun = rerun

    def getExecuteType(self):
        return self.executeType

    def getStubPort(self):
        return self.stubPort

    def getTizenVersion(self):
        return self.tizenVer

    def setFinished(self):
        self.isFinish = True
        MRP_i = MultiRunnPlan.getInstance()
        MRP_i.notify()

    def getUnpass(self):
        return self.unpass

    def setUnpass(self, unpass):
        if self.unpass is None or self.unpass == False:
            self.unpass = unpass

    def getResultFolderPath(self):
        '''
        self.acquire()
        if self.resultFolderPath is None:
            LOGGER.error("make result dir path============")
            folderName = self.name + "_" + \
                    datetime.datetime.now().strftime('%Y-%m-%d_%H:%M:%S.%f')
            self.resultFolderPath = Constants.RESULT_FOLDER \
                    % (self.tizenVer, self.getBuildId(), folderName)
        self.release()
        '''
        return self.resultFolderPath

    #info get Tmp Folder path in device
    #return String
    def getDevTctTmpPath(self):
        return Constants.getDEVICE_SUITE_TARGET(self.tizenVer) + "tmp/"

    def setup_distribute(self, isSorted):
        self.devmgr.loadDeviceList()
        runningDevs = self.devmgr.getSdbDeviceList()
        if len(runningDevs) < 1:
            LOGGER.error("No device connected for distribute mode")
            return False
        LOGGER.info("Plan [%s] will be distributed to %d devices: %s" \
                % (self.name, len(runningDevs), \
                str([dev.devId for dev in runningDevs])))
        self.deviceId = None
        if (isSorted == True):
            def sortSuite(suites):
                return suites.suiteName
            self.getSuites().sort(key=sortSuite)
        else:
            self.sortSuites()
        return True

    def sortSuites(self):
        sorted_suites = []
        suites = self.getSuites()
        connection_suite = None
        for suite in suites:
            suite_name = suite.getSuiteName()

            autoCount = int(suite.getAutoNum())
            category = suite.category
            if category and category.find('Runtime') > -1:
                etime = autoCount * (Constants.SUITE_TEST_EXPECTED_TIME + 2)
            else:
                etime = (autoCount * 2) + Constants.SUITE_TEST_EXPECTED_TIME

            suite.setExpectedTime(etime)
            sorted_suites.append(suite)
        sorted_suites.sort(key=lambda x: x.expectedTime, reverse=True)

        self.suites = sorted_suites


class TctShellSuite:
    #PARAM suiteName = 'tct-capability-tests'
    #PARAM tcName = 'caps_displayresolution'
    #PARAM auto_num = 12
    #PARAM manual_num = 15
    #PARAM suite_pkg_name = 'common/tct-capability-tests-2.4.zip'
    #PARAM launcher = 'WRTLauncher'
    #PARAM category = 'Compliance'
    #PARAM tizenV = 'tizen_web_2.4'
    def __init__(self, suiteName, tcName, auto_num, manual_num, \
            suite_pkg_name, launcher, category, tizenV, skip_tc, \
            devmgr, pre_test, post_test):
        self.suiteName = suiteName
        self.tcName = tcName
        self.auto_num = auto_num
        self.manual_num = manual_num
        self.suite_pkg_name = suite_pkg_name
        self.launcher = launcher
        #category can be None
        self.category = category
        self.tizenV = tizenV
        self.expectedTime = 0
        self.runErrorStatus = False
        self.noAuto = False
        self.noManual = False
        self.skip_tc = skip_tc
        self.devmgr = devmgr
        self.pre_test = pre_test
        self.post_test = post_test

    def _liteCommand(self, deviceId, resultFolder, extype, \
            tcName, isRerun, stubPort, isSkip=None, reverse_tests=None):
        lcmd = ""
        if self.tizenV and \
            (self.tizenV.find("web") > -1 or self.tizenV.find("csharp") > -1):
            lcmd += Constants.LITE_CMD2 + " "
        else:
            lcmd += Constants.LITE_CMD1 + " "

        # -- priority
        if Constants.PRIORITY_VALUE:
            lcmd += Constants.PRIORITY

        lcmd += Constants.LITE_DEVICE_PARAM + " "

        if isSkip:
            lcmd += 'None' + " "
        else:
            lcmd += str(deviceId) + " "

        if isRerun:
            lcmd += Constants.LOCAL_PRE
            lcmd += os.path.join(resultFolder, \
                    self.suiteName + Constants.RERUN_SUFFIX) + " "
        elif reverse_tests is not None:
            lcmd += Constants.LOCAL_PRE
            lcmd += reverse_tests + " "
        else:
            if self.tizenV.find('csharp') > -1 or self.tizenV.find('web') > -1 or deviceId is None:
                lcmd += Constants.LOCAL_PRE
                lcmd += (Constants.LOCAL_SHELL_TEMP_PATH % deviceId)
                lcmd += "opt/" + self.suiteName + "/"
                lcmd += Constants.DEVICE_SUITE_DEF + " "
            else:
                lcmd += Constants.DEVICE_PRE
                lcmd += Constants.getDEVICE_SUITE_FOLDER(self.tizenV)
                lcmd += self.suiteName + "/"
                lcmd += Constants.DEVICE_SUITE_DEF + " "

        lcmd += extype.toLiteParam() + " "
        lcmd += Constants.LITE_NON_ACTIVE_PARAM + " "

        if tcName is not None:
            lcmd += Constants.TESTCASE_ID + " "
            lcmd += tcName + " "

        lcmd += "--tizen-version" + " "
        lcmd += self.tizenV + " "

        lcmd += "--stub-port" + " "
        lcmd += str(stubPort) + " "

        if self.skip_tc:
            lcmd += "--skip-tc "
            for tc in self.skip_tc:
                lcmd += str(tc)
                lcmd += " "

        if self.tizenV and (self.tizenV.find("web") > -1 or self.tizenV.find("csharp") > -1):
            timeout = Constants.DEFAULT_TIMEOUT
            if timeout is not None:
                lcmd += "--tc-timeout" + " "
                lcmd += timeout + " "

        if self.tizenV and (self.tizenV.find("web") > -1 or self.tizenV.find('csharp') > -1):
            lcmd += Constants.EXT_TYPE_PARAM + " "
            lcmd += Constants.COMM_TYPE_PARAM + " "
            lcmd += Constants.ENV_TYPE_PARAM + " "
        else:
            lcmd += Constants.LITE_E_PARAM + " "

        if deviceId:
            lcmd += Constants.LITE_CAPABILITY_PARAM + " "
            lcmd += Constants.LOCAL_CAPABILITY_PATH % deviceId + " "

        lcmd += Constants.LITE_OUTPUT_PARAM
        lcmd += os.path.join(resultFolder, self.suiteName)

        if isRerun:
            if extype.getCurrType() == ExecuteType.e_manual:
                lcmd += Constants.RERUN_MANUAL_RESULT_SUFFIX + " "
            else:
                lcmd += Constants.RERUN_AUTO_RESULT_SUFFIX + " "

            lcmd += " --rerun"
        else:
            if extype.getCurrType() == ExecuteType.e_manual:
                lcmd += Constants.MANUAL_RESULT_SUFFIX + " "
            else:
                lcmd += Constants.AUTO_RESULT_SUFFIX + " "

        return lcmd

    def executePlanAuto(self, deviceId, resultFolder, tcName, isRerun, \
            stubport):
        self.executePlaninLite(deviceId, resultFolder, ExecuteType('Auto'), \
                tcName, isRerun, stubport)

    def executePlanManual(self, deviceId, resultFolder, tcName, isRerun, \
            stubport):
        self.executePlaninLite(deviceId, resultFolder, ExecuteType('Manual'), \
                tcName, isRerun, stubport)

    def executePlaninLite(self, deviceId, resultFolder, exeType, tcName, \
            isRerun, stubport):
        exCmd = self._liteCommand(deviceId, resultFolder, exeType, tcName, \
                isRerun, stubport)

        isPass = True
        if deviceId:
            isPass = SdbManager.hostLiteCommand(exCmd)
        else:
            SdbManager.hostRecLiteCommand(exCmd)
            return None

        if isPass is False:
            cmd = ""
            if self.tizenV.find("native") > -1 or self.tizenV.find("2.4") > -1:
                tests = Constants.getDEVICE_TESTS_FILE(self.tizenV) % self.suiteName
                cmd = "ps aux | grep 'python /opt/testkit/lite_native/testkit-lite -f device:%s'" % tests
            else:
                tests = Constants.LOCAL_SHELL_TEMP_PATH % deviceId + "opt/" + self.suiteName + "/tests.xml"
                cmd = "ps aux | grep 'python /opt/testkit/lite_web_csharp/testkit-lite -f %s'" % tests

            result = str(SdbManager.hostCommandwithResult(cmd))
            grep_lines = result.split('\n')
            for line in grep_lines:
                if line and len(line) > 0 and line.find(self.suiteName) > -1:
                    proc_id = line.split()[1]
                    SdbManager.hostCommand('kill -9 %s' % proc_id)
                    if self.tizenV and (self.tizenV.find("web") > -1 or self.tizenV.find("csharp") > -1):
                        exCmd = self._liteCommand(deviceId, resultFolder, exeType, tcName, \
                             isRerun, stubport, True)
                        SdbManager.hostRecLiteCommand(exCmd)
                    else:
                        reverse_tests = self._native_installSuiteinHost()
                        exCmd = self._liteCommand(deviceId, resultFolder, exeType, tcName, \
                             isRerun, stubport, True, reverse_tests)
                        SdbManager.hostRecLiteCommand(exCmd)
                    LOGGER.error("[skip package : %s]" % self.suiteName)
                    break

    def _native_installSuiteinHost(self):
        hostTmpFolder = Constants.LOCAL_SHELL_TEMP_PATH % None
        localSuitePath = Constants.SUITES_REPOSITORY \
            % self.tizenV + self.suite_pkg_name
        self._installSuiteinHost(None, localSuitePath, hostTmpFolder)
        tmp_suite = hostTmpFolder + "opt/" + self.suiteName + "/tests.xml"
        return tmp_suite

    def getSuitePackageName(self):
        return self.suite_pkg_name

    def getSuiteName(self):
        return self.suiteName

    def getSuiteZipName(self):
        suiteFile = self.suite_pkg_name.split('/')
        return suiteFile[1]

    def getSuiteFullPath(self):
        return os.path.join(Constants.SUITES_REPOSITORY \
                % self.tizenV, self.suite_pkg_name)

    def checkExistSuiteFile(self):
        return os.path.isfile(self.getSuiteFullPath())

    def _fileCopy(self, src, destDir):
        if not Constants.checkFileExists(src):
            LOGGER.warning("The '%s' file exists error" % src)

        if not os.path.exists(destDir):
            os.makedirs(destDir, mode=0o777)

        shutil.copy(src, destDir)

    def getTestCase(self):
        return self.tcName

    def getAutoNum(self):
        return self.auto_num

    def getManualNum(self):
        return self.manual_num

    def getExpectedTime(self):
        return self.expectedTime

    def setExpectedTime(self, etime):
        self.expectedTime = etime

    def setRunErrorStatus(self, status):
        self.runErrorStatus = status

    def getNoAuto(self):
        return self.noAuto

    def getNoManual(self):
        return self.noManual

    def setNoAuto(self):
        self.noAuto = True

    def setNoManual(self):
        self.noManual = True

    def _sdb_recov(self, _devid):
        LOGGER.error(_devid + " sdb disconnect")
        self.devmgr.deleteFaultDevice(_devid)

    def _installSuiteinHost(self, _devid, localSuitePath, hostTmpFolder):
        if not os.path.exists(hostTmpFolder + "opt/" + self.suiteName \
                + "/" + Constants.INSTALL_ZIP_W3):
            # copy suite zip file
            self._fileCopy(localSuitePath, hostTmpFolder)

            # unzip suite zip file
            unzip_cmd = Constants.UNZIP + " " + hostTmpFolder \
                    + self.getSuiteZipName() + " -d " + hostTmpFolder
            SdbManager.hostCommand(unzip_cmd, 300)

        if _devid:
            try:
                inst_cmd = "python " + hostTmpFolder + "opt/" + self.suiteName \
                    + "/" + Constants.INSTALL_ZIP_W3 + " -i -s " + _devid
                SdbManager.hostCommand(inst_cmd, 300)
            except DevNotFoundErr:
                self._sdb_recov(_devid)
                return False
            except Exception:
                return False

        return True

    def _installSuiteinTarget(self, _devid, localSuitePath, remoteTmpFolder):
        try:
            if not SdbManager.sdbPush(_devid, localSuitePath, remoteTmpFolder):
                return False

            unzip_cmd = Constants.UNZIP + " " + remoteTmpFolder \
                + self.getSuiteZipName() + " -d " \
                + remoteTmpFolder.replace("tmp/", "")

            inst_cmd = remoteTmpFolder.replace("/tmp", "") + "opt/" \
                + self.suiteName + "/" + Constants.INSTALL_ZIP_24

            SdbManager.sdbShell(_devid, unzip_cmd, 300)
            SdbManager.sdbShell(_devid, inst_cmd, 300)
        except DevNotFoundErr:
            self._sdb_recov(_devid)
            return False
        except Exception:
            return False

        return True

    def installSuite(self, deviceId, remoteTmpFolder):
        localSuitePath = Constants.SUITES_REPOSITORY \
                % self.tizenV + self.suite_pkg_name
        instResult = True

        if self.tizenV.find("csharp") > -1 or \
            self.tizenV.find("web") > -1 or deviceId is None:
            hostTmpFolder = Constants.LOCAL_SHELL_TEMP_PATH % deviceId
            instResult = self._installSuiteinHost(\
                    deviceId, localSuitePath, hostTmpFolder)
        else:
            instResult = self._installSuiteinTarget(\
                    deviceId, localSuitePath, remoteTmpFolder)

        return instResult

    def _unInstallSuiteInHost(self, _devid, hostTmpFolder):
        suiteZipPath = hostTmpFolder + self.getSuiteZipName()
        removeSuitezip = "rm -f " + suiteZipPath
        SdbManager.hostCommand(removeSuitezip)

        localSuitePath = Constants.SUITES_REPOSITORY % self.tizenV + self.suite_pkg_name
        self._fileCopy(localSuitePath, hostTmpFolder)

        unzip_cmd = Constants.UNZIP + " " + hostTmpFolder \
                + self.getSuiteZipName() + " -d " + hostTmpFolder
        SdbManager.hostCommand(unzip_cmd)

        if _devid:
            try:
                unInstSuite = "python " + hostTmpFolder + "opt/" \
                    + self.suiteName + "/" + Constants.UNINSTALL_ZIP_W3 \
                    + " -s " + _devid
                SdbManager.hostCommand(unInstSuite,300)
            except DevNotFoundErr:
                self._sdb_recov(_devid)
                return False
            except Exception:
                return False

    def _unInstallSuiteInTarget(self, _devid, remoteFolder):
        try:
            removeSuite = "rm -f " + remoteFolder + self.getSuiteZipName()
            unInstSuite = remoteFolder.replace("/tmp", "") + "opt/" \
                + self.suiteName + "/" + Constants.UNINSTALL_ZIP_24

            SdbManager.sdbShell(_devid, removeSuite, 300)
            SdbManager.sdbShell(_devid, unInstSuite, 300)
        except DevNotFoundErr:
            self._sdb_recov(_devid)
            return False
        except Exception:
            return False

    def runPreTestScript(self, _devid):
        if self.pre_test:
            LOGGER.debug("run pre-test script: {}".format(self.pre_test))
            SdbManager.hostRecLiteCommand('bash {} {} {}'.format(self.pre_test, _devid, self.suiteName))


    def runPostTestScript(self, _devid):
        if self.post_test:
            LOGGER.debug("run post-test script: {}".format(self.post_test))
            SdbManager.hostRecLiteCommand('bash {} {} {}'.format(self.post_test, _devid, self.suiteName))

    def unInstallSuite(self, deviceId, remoteFolder):
        if self.tizenV.find("csharp") > -1 or self.tizenV.find("web") > -1 or deviceId is None:
            hostTmpFolder = Constants.LOCAL_SHELL_TEMP_PATH % deviceId
            self._unInstallSuiteInHost(deviceId, hostTmpFolder)
        else:
            self._unInstallSuiteInTarget(deviceId, remoteFolder)

    def sdbCheckSuite(self, _devid, suiteName):
        LOGGER.info("Entering checkSuiteExisted(String suiteName : %s)" \
                % suiteName)
        try:
            if self.tizenV and float(self.tizenV.split('_')[-1]) >= 3.0:
                rep_suiteName = suiteName.replace("tct-", "")
                host_check_cmd = "su - owner -c \"app_launcher -l | grep %s\"" \
                             % rep_suiteName
                output = SdbManager.sdbShell(_devid, host_check_cmd)
                if output and output.find(rep_suiteName) > -1:
                    return True
                else:
                    return False
            else:
                check_cmd = "wrt-launcher -l | grep " + suiteName
                resultMsg = SdbManager.sdbShell(_devid, check_cmd)
                if resultMsg and len(resultMsg) > 0:
                    return True
                else:
                    return False
        except DevNotFoundErr:
            self._sdb_recov(_devid)
            return False
        except Exception:
            return False


class ExecuteType:
    e_all = "All"
    e_auto = "Auto"
    e_manual = "Manual"

    currType = ""

    def __init__(self, extype):
        self.currType = extype

    @classmethod
    def createExecuteType(self, extype):
        executeType = None
        if self.e_all.lower() == extype.lower():
            executeType = ExecuteType(self.e_all)
        elif self.e_auto.lower() == extype.lower():
            executeType = ExecuteType(self.e_auto)
        elif self.e_manual.lower() == extype.lower():
            executeType = ExecuteType(self.e_manual)

        return executeType

    #return String
    def toLiteParam(self):
        if self.currType == self.e_auto:
            return " -A"
        elif self.currType == self.e_manual:
            return " -M"
        else:
            return ""

    #return String
    def getCurrType(self):
        return self.currType
