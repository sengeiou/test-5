#!/usr/bin/python

import threading
import time
from .shellplanner import *
from .result_summary import ResultSummary
from .logmanager import LOGGER
from .sdbmanager import SdbManager


class PlanExecutor(threading.Thread):
    plan = None
    autoworker = None
    maualworker = None
    thCounter = ""

    #Param TctshellPlan
    def __init__(self, plan, threadCounter, isPreconSet, devmgr):
        LOGGER.debug("Creating PlanExecutor, with [plan]: " \
                + plan.getPlanName())
        self.plan = plan
        threading.Thread.__init__(self)
        self.name = plan.getPlanName()
        self.tcCounter = threadCounter
        self.threadLock = threading.Lock()
        self.isPreconSet = isPreconSet
        self.devmgr = devmgr

    def run(self):
        time.sleep(1)
        LOGGER.debug("Starting PlanExecutor")

        self.threadLock.acquire()
        self.checkWorkerStatus()
        LOGGER.debug("setStartTest()")
        self.setStartTest()
        self.threadLock.release()

        exeType = self.plan.getExecuteType()
        if exeType.getCurrType() == ExecuteType.e_auto:
            self.autoworker = AutoSuiteWorker(self.plan, self.devmgr)
            self.autoworker.auto_test()

        elif exeType.getCurrType() == ExecuteType.e_manual:
            self.manualworker = ManualSuiteWorker(self.plan)
            self.manualworker.manual_test()

        else:
            self.autoworker = AutoSuiteWorker(self.plan, self.devmgr)
            self.autoworker.auto_test()

            self.manualworker = ManualSuiteWorker(self.plan)
            self.manualworker.manual_test()

        SdbManager.exportDumpFiles(self.plan.getDeviceId(), \
                self.plan.getResultFolderPath() + "/dump/")

        summary = ResultSummary(plans=[self.plan])
        summary.genResults()
        summary.genSummary()
        self.setFinishedTest()

    def checkWorkerStatus(self):
        multiPlanIns = MultiRunnPlan.getInstance()
        while True:
            if multiPlanIns.isSelectedDevAvailable(self.plan):
                break
            else:
                time.sleep(5)

    def setStartTest(self):
        multiPlanIns = MultiRunnPlan.getInstance()
        multiPlanIns.setCurrPlanRunning(self.plan)

    def setFinishedTest(self):
        self.plan.setRunning(False)
        self.plan.setFinished()


class AutoSuiteWorker:
    plan = None

    def __init__(self, plan, devmgr):
        self.plan = plan
        self.deviceId = self.plan.getDeviceId()
        self.devmgr = devmgr

    def auto_test(self):
        deviceId = self.deviceId
        suites = self.plan.getSuites()
        remTmpDir = self.plan.getDevTctTmpPath()
        resultFolder = self.plan.getResultFolderPath()
        isRerun = self.plan.isReRunning()
        stubPort = self.plan.getStubPort()

        for counter, suite in enumerate(suites):
            if not self._checkDeviceStatus():
                self._auto_test_inhost(suites[counter:])
                break

            if suite.getAutoNum() is None or int(suite.getAutoNum()) == 0:
                suite.setNoAuto()
                LOGGER.warning('Suite : %s , AutoNum : 0' \
                        % (suite.getSuiteName()))
                continue

            if suite.checkExistSuiteFile() == False:
                LOGGER.error("The %s file Exist error" \
                        % suite.getSuiteFullPath())
                continue
            suiteName = suite.getSuiteName()
            LOGGER.debug("current suite Auto count : %s " % suite.getAutoNum())

            LOGGER.info('Checking if the suite ' + suiteName \
                    + 'is installed already.')
            if suite.sdbCheckSuite(deviceId, suiteName):
                LOGGER.info('The suite ' + suiteName \
                        + ' is existed. uninstalling')
                LOGGER.info('Uninstalling the existed suite ' + suiteName)
                suite.unInstallSuite(deviceId, remTmpDir)

            LOGGER.info('Uploading the suite ' + suiteName)
            LOGGER.info('Installing the suite ' + suiteName)
            suite.installSuite(deviceId, remTmpDir)
            LOGGER.info('Executing the suite ' + suiteName \
                    + ' in testkit-lite.')
            suite.executePlanAuto(deviceId, resultFolder, \
                    suite.getTestCase(), isRerun, stubPort)

            LOGGER.info('removing the suite pkg file of the suite ' \
                    + suiteName)
            LOGGER.info('Uninstalling the suite ' + suiteName)
            suite.unInstallSuite(deviceId, remTmpDir)

        LOGGER.info("Finished to execute all auto test-cases")

    def _auto_test_inhost(self, suites):
        deviceId = None
        remTmpDir = self.plan.getDevTctTmpPath()
        resultFolder = self.plan.getResultFolderPath()
        isRerun = self.plan.isReRunning()
        stubPort = self.plan.getStubPort()

        for suite in suites:
            if suite.getAutoNum() is None or int(suite.getAutoNum()) == 0:
                suite.setNoAuto()
                LOGGER.warning('Suite : %s , AutoNum : 0' \
                        % (suite.getSuiteName()))
                continue

            suiteName = suite.getSuiteName()
            LOGGER.info('Uploading the suite ' + suiteName)
            LOGGER.info('Installing the suite ' + suiteName)
            suite.installSuite(deviceId, remTmpDir)
            LOGGER.info('Executing the suite ' + suiteName \
                    + ' in testkit-lite.')
            suite.executePlanAuto(deviceId, resultFolder, \
                    suite.getTestCase(), isRerun, stubPort)

            LOGGER.info('removing the suite pkg file of the suite ' \
                    + suiteName)
            LOGGER.info('Uninstalling the suite ' + suiteName)
            suite.unInstallSuite(deviceId, remTmpDir)

            LOGGER.debug("current suite Auto count : %s " % suite.getAutoNum())
            LOGGER.info("Finished to execute auto suite: [%s]" % suiteName)

    def _checkDeviceStatus(self):
        time_waited = 0
        reboot_tried = False
        while True:
            if not self.devmgr.isDeviceAvailable(self.deviceId):
                if time_waited >= Constants.NO_WORKERS_TIMEOUT:
                    LOGGER.error("Rebooting timeout device : %s" \
                            % self.deviceId)
                    return False
                if reboot_tried:
                    waiting_time = 10
                else:
                    waiting_time = Constants.RECOVERY_TIME
                LOGGER.error("Please reboot device : %s" % self.deviceId)
                time.sleep(waiting_time)
                time_waited += waiting_time
                reboot_tried = True
            else:
                break
        return True


class ManualSuiteWorker:
    plan = None

    def __init__(self, plan):
        self.plan = plan

    def manual_test(self):
        deviceId = self.plan.getDeviceId()
        suites = self.plan.getSuites()
        resultFolder = self.plan.getResultFolderPath()
        remTmpDir = self.plan.getDevTctTmpPath()
        isRerun = self.plan.isReRunning()
        stubPort = self.plan.getStubPort()
        for suite in suites:
            if suite.getManualNum() is None or int(suite.getManualNum()) == 0:
                suite.setNoManual()
                LOGGER.warning('Suite : %s , ManualNum : 0' \
                        % (suite.getSuiteName()))
                continue
            if suite.checkExistSuiteFile() == False:
                LOGGER.error("The %s file Exist error" % self.getSuiteFullPath)
                continue
            suiteName = suite.getSuiteName()
            LOGGER.debug("current suite Manual count : %s " \
                    % suite.getManualNum())

            LOGGER.info('Checking if the suite ' + suiteName \
                    + 'is installed already.')
            if suite.sdbCheckSuite(deviceId, suiteName):
                LOGGER.info('The suite ' + suiteName \
                        + ' is existed. uninstalling')
                LOGGER.info('Uninstalling the existed suite ' + suiteName)
                suite.unInstallSuite(deviceId, remTmpDir)

            LOGGER.info('Uploading the suite ' + suiteName)
            LOGGER.info('Installing the suite ' + suiteName)

            suite.installSuite(deviceId, remTmpDir)
            LOGGER.info('Executing the suite ' + suiteName \
                    + ' in testkit-lite.')
            suite.executePlanManual(deviceId, resultFolder, \
                    suite.getTestCase(), isRerun, stubPort)

            LOGGER.info('removing the suite pkg file of the suite ' \
                    + suiteName)
            LOGGER.info('Uninstalling the suite ' + suiteName)
            suite.unInstallSuite(deviceId, remTmpDir)

        LOGGER.info("Finished to execute all manual test-cases")
