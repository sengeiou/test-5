#!/usr/bin/python
#
# Copyright (C) 2012 Intel Corporation
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA  02110-1301, USA.
#
# Authors:
#              Tang, Shaofeng <shaofeng.tang@intel.com>

import re
import os
import os.path
import zipfile
import shutil
import configparser
from .logmanager import LOGGER

TCT_CONFIG_FILE = "/opt/tools/TCT_CONFIG"
tct_parser = configparser.ConfigParser()
tct_parser.read(TCT_CONFIG_FILE)

CONFIG_FILE = "/opt/tools/shell/CONFIG"
parser = configparser.ConfigParser()
parser.read(CONFIG_FILE)


class Constants:

    TCT_VERSION = "TCT-SHELL-3.0"

    TCT_HOME = "/opt/tct/"

    GlobalProfile = ""

    SUITE_TEST_EXPECTED_TIME = 7

    TCT_PLAN_FOLDER = "/opt/tools/shell/plan/"

    STYLE_FOLDER = "/opt/tools/shell/style/"

    DEVICE_HEALTH_CMD = "/opt/tct/%s/scripts/tct-config-device.py"

    HEALTH_CHECK_FILE_PATH = "/opt/tct/%s/scripts/healthcheck.ini"

    RESULT_FOLDER = "/opt/tct/%s/shell/result/%s/"

    RESULT_REPO = "/opt/tct/%s/shell/result/%s/"

    AUTO_RESULT_SUFFIX = ".auto.xml"

    MANUAL_RESULT_SUFFIX = ".manual.xml"

    RERUN_AUTO_RESULT_SUFFIX = ".auto.rerun.xml"

    RERUN_MANUAL_RESULT_SUFFIX = ".manual.rerun.xml"

    RERUN_SUFFIX = ".rerun.xml"

    TCT_LOG_FOLDER = "/opt/tools/shell/tmp/logs"

    DEFAULT_TIZENV = ""
    
    DEFAULT_TIMEOUT = ""
    
    IS_SORT_ENABLE = False

    #SDB Command
    SDB_PUSH = "sdb -s %s push"
    SDB_SHELL = "sdb -s %s shell"
    SDB_ROOT_ON = "sdb -s %s root on"
    SDB_DEVICES = "sdb devices"
    SDB_START_SERVER = "sdb start-server"
    SDB_KILL_SERVER = "sdb kill-server"
    SDB_CONNECT = "sdb connect %s"
    SDB_PULL = "sdb -s %s pull"
    SDB_CAT_CONFIG = " cat %s"
    SDB_LS = "sdb -s %s shell ls -al"
    SDB_DISPLAY_STOP = "sdb -s %s shell devicectl display stop"
    FILE_FOUND_SCRIPT = "[ -f %s ] && echo \"Found\" || echo \"Not Found\""

    UNZIP = "unzip -uo"

    LOCAL_CAPABILITY_PATH = "/opt/tools/shell/tmp/%s/device_capability.xml"
    LOCAL_BUILD_INFO_PATH = "/opt/tools/shell/tmp/%s/buildinfo.xml"
    LOCAL_SHELL_TEMP_PATH = "/opt/tools/shell/tmp/%s/"
    SOURCE_XML_PATH = "/opt/tct/%s/resource"

    DEVICE_ETC_PATH = "/etc/"
    CUSTOM_MODEL_CONFIG_SCRIPT = "custom_model_config.sh"

    DEVICE_MODEL_CONFIG_PATH_TEMP = "/tmp/model-config.xml"
    DEVICE_MODEL_CONFIG_PATH_ETC = "/etc/config/model-config.xml"
    DEVICE_INFO_INI_PATH = "/etc/info.ini"
    DEVICE_CPU_INFO_PATH = "/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq"
    EMUL_CPU_INFO_PATH = "/proc/cpuinfo"

    #Testkit-Lite
    LITE_CMD1 = "testkit-lite_native"
    LITE_CMD2 = "testkit-lite_web_csharp"
    PRIORITY_VALUE = False
    PRIORITY = "--priority P0 P1"
    LOCAL_PRE = "-f "
    DEVICE_PRE = "-f device:"
    LITE_E_PARAM = "-e ""WRTLauncher"""
    LITE_NON_ACTIVE_PARAM = "--non-active"
    LITE_DEVICE_PARAM = "--deviceid"
    LITE_CAPABILITY_PARAM = "--capability"
    TESTCASE_ID = "--id"
    EXECUTE_PREFF = " -e "
    ONLY_AUTO_CASES = "-A"
    ONLY_MANUAL_CASES = "-M"

    DEVICE_SUITE_DEF = "tests.xml"
    LITE_OUTPUT_PARAM = "-o "
    EXT_TYPE_PARAM = "-e xwalk"
    ENV_TYPE_PARAM = "--testenv \"Launcher=app_launcher \""
    COMM_TYPE_PARAM = "--comm tizenmobile"
    WRT_LAUNCHER_CMD = "WRTLauncher"

    #HOST/OPT
    SUITES_REPOSITORY = "/opt/tct/%s/packages/"

    INSTALL_ZIP_24 = "inst.sh"
    INSTALL_ZIP_W3 = "inst.py"

    UNINSTALL_ZIP_24 = "inst.sh -u"
    UNINSTALL_ZIP_W3 = "inst.py -u"

    #Plan Generator
    ALL_PROFILES = ['mobile', 'wearable', 'tv']
    DEFAULT_MATCH_REGEX = "*.zip"
    DEFAULT_UNMATCH_REGEX = None
    DEFAULT_PLAN_NAME = "Full_test"
    DEFAULT_PROFILE_NAME = "mobile"
    DEFAULT_EXECUTE_TYPE = "All"
    DEFAULT_PLAN_FILE = "tct_plan"

    REGEX_FOR_SPLIT_PKG_NAME = "-\d\.\d*"

    #Log Level
    DEFAULT_LOG_LEVEL = "INFO"
    LOG_LEVEL = None
    LOG_LEVELS = {"CRITICAL": 50,
                   "ERROR": 40,
                   "WARNING": 30,
                   "INFO": 20,
                   "DEBUG": 10,
                   "NOTSET": 0
                   }

    #Running Mode
    RUNNING_MODE_PLAN = "plan"
    RUNNING_MODE_RERUN = "rerun"
    RUNNING_MODE_SUITES = "suites"
    RUNNING_MODE_PROFILE = "profile"
    RERUNING_MODE = False
    DISTRIBUTE_MODE = False

    #PRECONFIGURE
    PRE_CONF_HOST_INI = "/opt/tools/shell/tmp/%s/tct-testconfig.ini"
    PRE_CONF_HOST_JSON = "/opt/tools/shell/tmp/%s/preconfigure.json"
    PRE_CONF_HOST_XML = "/opt/tools/shell/tmp/%s/tests.xml"
    PORT_CONF_HOST_JSON = "/opt/tools/shell/tmp/%s/portconfigure.json"
    NAT_CONF_HOST_TXT = "/opt/tools/shell/tmp/%s/TCT_Preconditions.txt"
    NAT_CONF_DEVICE_TXT = "/opt/usr/home/owner/share/"

    #Waiting Time
    #DEBUG PURPOSE. Original value: 300
    NO_WORKERS_TIMEOUT = 300
    #Temporary constant value. Should be dynamic.
    RECOVERY_TIME = 100

    DEVICE_SUITE_TARGET_24 = tct_parser.get('DEVICE', 'DEVICE_SUITE_TARGET_24')
    DEVICE_SUITE_TARGET_30 = tct_parser.get('DEVICE', 'DEVICE_SUITE_TARGET_30')

    @staticmethod
    def setRecoveryTime(timeout):
        Constants.RECOVERY_TIMEOUT = timeout

    @staticmethod
    def getDEVICE_TESTS_FILE(_tizenV):
        if _tizenV and float(_tizenV.split('_')[-1]) >= 3.0:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_30, "tct/opt/%s/tests.xml")
        else:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_24, "tct/opt/%s/tests.xml")

    @staticmethod
    def getDEVICE_SUITE_TARGET(_tizenV):
        if _tizenV and float(_tizenV.split('_')[-1]) >= 3.0:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_30, "tct/")
        else:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_24, "tct/")

    @staticmethod
    def getDEVICE_SUITE_FOLDER(_tizenV):
        if _tizenV and float(_tizenV.split('_')[-1]) >= 3.0:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_30, "tct/opt/")
        else:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_24, "tct/opt/")

    @staticmethod
    def getDEVICE_BUILD_INFO_PATH(_tizenV):
        if _tizenV and float(_tizenV.split('_')[-1]) >= 3.0:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_30, "Documents/tct/buildinfo.xml")
        else:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_24, "Documents/tct/buildinfo.xml")

    @staticmethod
    def getDEVICE_CAPABILITY_PATH(_tizenV):
        if _tizenV and float(_tizenV.split('_')[-1]) >= 3.0:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_30, "Documents/tct/capability.xml")
        else:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_24, "Documents/tct/capability.xml")

    @staticmethod
    def getDEVICE_XML_PATH(_tizenV):
        if _tizenV and float(_tizenV.split('_')[-1]) >= 3.0:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_30, "Documents/tct/")
        else:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_24, "Documents/tct/")

    @staticmethod
    def getPRE_CONF_DEVICE_INI(_tizenV):
        if _tizenV and float(_tizenV.split('_')[-1]) >= 3.0:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_30, "tct/opt/tct-testconfig/tct-testconfig.ini")
        else:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_24, "tct/opt/tct-testconfig/tct-testconfig.ini")

    @staticmethod
    def getPRE_CONF_DEVICE_JSON(_tizenV):
        if _tizenV and float(_tizenV.split('_')[-1]) >= 3.0:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_30, "tct/opt/tct-testconfig/preconfigure.json")
        else:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_24, "tct/opt/tct-testconfig/preconfigure.json")

    @staticmethod
    def getPRE_CONF_DEVICE_XML(_tizenV):
        if _tizenV and float(_tizenV.split('_')[-1]) >= 3.0:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_30, "tct/opt/tct-testconfig/tests.xml")
        else:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_24, "tct/opt/tct-testconfig/tests.xml")

    @staticmethod
    def getPORT_CONF_DEVICE_JSON(_tizenV):
        if _tizenV and float(_tizenV.split('_')[-1]) >= 3.0:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_30, "tct/opt/tct-testconfig/portconfigure.json")
        else:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_24, "tct/opt/tct-testconfig/portconfigure.json")

    @staticmethod
    def getTCT_PORT_CONF_DEVICE_JSON(_tizenV):
        if _tizenV and float(_tizenV.split('_')[-1]) >= 3.0:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_30, "tct/portconfigure.json")
        else:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_24, "tct/portconfigure.json")

    @staticmethod
    def getTCT_PRE_CONF_DEVICE_JSON(_tizenV):
        if _tizenV and float(_tizenV.split('_')[-1]) >= 3.0:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_30, "tct/preconfigure.json")
        else:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_24, "tct/preconfigure.json")

    @staticmethod
    def getNAT_CONF_DEVICE_TXT(_tizenV):
        if _tizenV and float(_tizenV.split('_')[-1]) >= 3.0:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_30, "tct/opt/tct-testconfig/TCT_Preconditions.txt")
        else:
            return os.path.join(Constants.DEVICE_SUITE_TARGET_24, "tct/opt/tct-testconfig/TCT_Preconditions.txt")

    @staticmethod
    def setLogLevel(lvl):
        Constants.LOG_LEVEL = lvl

    @staticmethod
    def setRerunMode(isRerun):
        Constants.RERUNING_MODE = isRerun

    @staticmethod
    def setDistMode(isDist):
        Constants.DISTRIBUTE_MODE = isDist

    @staticmethod
    def isDistMode():
        return Constants.DISTRIBUTE_MODE

    @staticmethod
    def checkBuildIds(devs):
        check = True
        if len(devs) == 0:
            check = False

        first_buildId = None
        for count, dev in enumerate(devs):
            dev_buildId = dev.getDeviceBuildId()
            if count == 0:
                first_buildId = dev_buildId
            if not dev_buildId:
                check = False
            if not first_buildId in dev_buildId:
                check = False

        return check

    @staticmethod
    def getSuiteNameFromFile(suiteFile):
        suffixes = [Constants.AUTO_RESULT_SUFFIX, \
                 Constants.MANUAL_RESULT_SUFFIX, \
                 Constants.RERUN_AUTO_RESULT_SUFFIX, \
                 Constants.RERUN_MANUAL_RESULT_SUFFIX]
        for suffix in suffixes:
            if suiteFile.endswith(suffix):
                suiteFile = suiteFile[:-len(suffix)]
                return suiteFile

    @staticmethod
    def checkFileExists(aPath):
        if os.path.exists(aPath):
            return True
        else:
            return False

    @staticmethod
    def getTempPath(filepath):
        xmlFolder = Constants.LOCAL_SHELL_TEMP_PATH % "temp_xml"
        if not os.path.isdir(xmlFolder):
            os.makedirs(xmlFolder, mode=0o777)

        xml_name = os.path.basename(filepath)
        temp_path = os.path.join(xmlFolder, xml_name)
        return temp_path

    @staticmethod
    def unzip_package(filepath):
        path = os.path.expanduser("~")
        os.chdir(path)
        if os.path.exists(Constants.DEFAULT_PLAN_FILE):
            shutil.rmtree(Constants.DEFAULT_PLAN_FILE)

        os.makedirs(Constants.DEFAULT_PLAN_FILE, mode=0o777)
        f = zipfile.ZipFile(filepath, 'r')
        for file in f.namelist():
            f.extract(file, path + "/" + Constants.DEFAULT_PLAN_FILE)

    @staticmethod
    def clean_unzip_file():
        os.chdir(os.path.expanduser("~"))
        if os.path.exists(Constants.DEFAULT_PLAN_FILE):
            shutil.rmtree(Constants.DEFAULT_PLAN_FILE)

    @staticmethod
    def move_log_file(src_file, dest_folder):
        log_folder = os.path.join(dest_folder, 'logs')
        if not os.path.isfile(src_file):
            LOGGER.warning('%s does not exist' % src_file)
            return False
        if not os.path.isdir(log_folder):
            os.mkdir(log_folder, mode=0o777)

        count = 1
        src_basename = os.path.basename(src_file)
        src_dir = os.path.dirname(src_file)
        title, ext = os.path.splitext(src_basename)
        while True:
            if os.path.exists(os.path.join(log_folder, src_basename)):
                src_basename = title + "_%s%s" % (count, ext)
                count += 1
            else:
                break

        rename_src = os.path.join(src_dir, src_basename)
        os.rename(src_file, rename_src)
        shutil.copy(rename_src, log_folder)
        return True

    @staticmethod
    def indent(elem, level=0):
        i = "\n" + level * "  "
        if len(elem):
            if not elem.text or not elem.text.strip():
                elem.text = i + "  "
            if not elem.tail or not elem.tail.strip():
                elem.tail = i
            for elem in elem:
                Constants.indent(elem, level + 1)
            if not elem.tail or not elem.tail.strip():
                elem.tail = i
        else:
            if level and (not elem.tail or not elem.tail.strip()):
                elem.tail = i

    @staticmethod
    def isSdbNetwork(deviceId):
        patt = re.compile('\d{1,3}\.\d{1,3}\.\d{1,3}.\d{1,3}:')
        ma = patt.match(deviceId)
        if ma:
            return True
        else:
            return False

    '''
    @staticmethod
    def getDeviceExceptions():
        devices = []
        try:
            devs = parser.get('DISTRIBUTE_MODE', 'DEVICE_EXCEPTIONS')
            devs = devs.splitlines()
            for dev in devs:
                if dev != '':
                    devices.append(dev)
                    LOGGER.info("Ignoring device: %s" % dev)
        except Exception as e:
            LOGGER.error("CONFIG file Parsing Error: %s" % e)
        finally:
            return devices
    '''

    @staticmethod
    def set_default_tizenV(_tizenV):
        Constants.DEFAULT_TIZENV = _tizenV

    @staticmethod
    def set_default_timeout(_timeout):
        Constants.DEFAULT_TIMEOUT = _timeout

    @staticmethod
    def get_tct_binaryV():
        tct_binV = ""
        ver_path = '/opt/tct/%s/VERSION' % Constants.DEFAULT_TIZENV
        if os.path.exists(ver_path):
            ver_file = open('/opt/tct/%s/VERSION' % \
                    Constants.DEFAULT_TIZENV, 'r')
            tct_binV = ver_file.readline().strip()
        return tct_binV

    @staticmethod
    def set_sort_enable(_issorted):
        Constants.IS_SORT_ENABLE = _issorted

    @staticmethod
    def get_sort_enable():
        return Constants.IS_SORT_ENABLE

