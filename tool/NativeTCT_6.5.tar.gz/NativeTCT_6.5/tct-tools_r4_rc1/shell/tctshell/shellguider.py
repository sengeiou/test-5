#!/usr/bin/python

import os
import configparser
import string
import json

from .logmanager import LOGGER
from .sdbmanager import SdbManager
from .constants import Constants
from xml.etree import ElementTree

class Guider:
    _conf_prompts = []
    deviceIds = []

    def __init__(self, plan, deviceIds=None):
        if deviceIds is None:
            self.deviceIds = [plan.getDeviceId()]
        else:
            self.deviceIds = deviceIds
        self.deviceId = self.deviceIds[0]
        self.tizenVer = plan.getTizenVersion()
        self.stubPort = plan.getStubPort()
        self.manual_items = {}
        self.conf_items = {}
        self.suites = {}

        for suite in plan.getSuites():
            self.suites[suite.getSuiteName()] = suite

        self.conf_file = Constants.PRE_CONF_HOST_INI % self.deviceId

    def init_items(self):
        self._fill_items()
        self._read_conf()
        self.read(self.conf_file)

    def read(self, filename):
        LOGGER.debug("reading %s file" % filename)
        try:
            fp = open(filename)
        except IOError:
            LOGGER.warning("open file fail...")

        self._read(fp, filename)
        fp.close()

    def _read(self, fp, fpname):
        lineno = 0
        comment = None;
        prompts = []
        while True:
            line = fp.readline()
            if not line:
                break
            lineno = lineno + 1
            # comment or blank line?
            if line.strip() == '':
                continue
            if line.split(None, 1)[0].lower() == 'rem' and line[0] in "rR":
                # no leading whitespace
                continue
            if line[0] in '#;':
                comment = line;
                continue
            if line[0] in '[':
                comment = None;
                continue
            if line.find('='):
                linelist = line.split('=')
                prompts.append((linelist[0], comment))
        self._conf_prompts = prompts

    def _read_conf(self):
        parser = configparser.ConfigParser()
        parser.read(self.conf_file)
        for section in parser.sections():
            if not section:
                continue
            opts = {}
            for n, v in parser.items(section):
                if n:
                    opts[n] = v
            self.conf_items[section] = opts

    def _fill_items(self):
        command = "cat " + Constants.PRE_CONF_HOST_XML % self.deviceId
        result =  SdbManager.hostCommandwithResult(command)
        if result is None :
            LOGGER.warning("Obtain tct_testconfig content error...")
            self._exit(0)

        xml_tree = ElementTree.fromstring(result)

        for set in ElementTree.Element.findall(xml_tree, "suite/set"):
            module_name = ElementTree.Element.get(set, "name", None)
            if module_name:
                descs = []
                for desc in ElementTree.Element.findall(set, "testcase/description/steps/step/step_desc"):
                    if desc is not None:
                        descs.append(desc.text)
            self.manual_items[module_name] = descs

    def is_update_config(self, pkg_name):
        #if self.conf_items.has_key(pkg_name):
        if pkg_name in self.conf_items:
            return True
        return False

    def get_confs(self, pkg_name):
        return self.conf_items.get(pkg_name)

    def _update_portenv(self):
        #read json
        for devId in self.deviceIds:
            if os.path.isfile(Constants.PORT_CONF_HOST_JSON % devId) :
                fread = open(Constants.PORT_CONF_HOST_JSON % devId, "r")
                port_data = json.loads(fread.read())
                fread.close()

                port_data[0]['STUB_PORT'] = self.stubPort
                fwrite = open(Constants.PORT_CONF_HOST_JSON % devId,"w")
                json.dump(port_data, fwrite,indent = 4)
                fwrite.close()
            else :
                LOGGER.warning("Not Found %s config file" % Constants.PORT_CONF_HOST_JSON % devId)
                raise

    def setup_manual_env(self):
        self._show_manual_setup()
        self._show_overall_infos()
        self._update_json()
        self._push_preconfigure()
        if self.tizenVer.find("native") > -1:
            self._update_txt()
            self._push_tc_config()

    def setup_default_env(self):
        self._update_portenv()
        self._push_portconfigure()

    def _push_preconfigure(self):
        for devId in self.deviceIds:
            local = Constants.PRE_CONF_HOST_JSON % devId
            remote = Constants.getTCT_PRE_CONF_DEVICE_JSON(self.tizenVer)
            SdbManager.sdbPush(devId, local, remote)

    def _push_portconfigure(self):
        for devId in self.deviceIds:
            local = Constants.PORT_CONF_HOST_JSON % devId
            remote = Constants.getTCT_PORT_CONF_DEVICE_JSON(self.tizenVer)
            SdbManager.sdbPush(devId, local, remote)

    def _push_tc_config(self):
        for devId in self.deviceIds:
            local = Constants.NAT_CONF_HOST_TXT % devId
            remote = Constants.NAT_CONF_DEVICE_TXT
            SdbManager.sdbPush(devId, local, remote)

    def _filter_suits(self, items):
        keys = set()
        if self.suites and items:
            suit_keys = set(self.suites.keys())
            item_keys = set(items.keys())
            keys = keys|(suit_keys & item_keys)
        return list(keys)

    def _show_manual_setup(self):
        keys = self._filter_suits(self.manual_items)
        if not keys:
            LOGGER.debug("No any pre-configure to be configured.")
            return

        LOGGER.info("\nHi,guys, before the start, there are some pre-configures must be provided,"
              "and you just should input (Y)es or simply press Enter if your test environment "
              "has met the request, otherwise, please input (N)o and the program will exit.")

        LOGGER.info("Device Id : %s " % str(self.deviceIds))

        for module in keys:
            descs = self.manual_items.get(module)
            if descs:
                LOGGER.info("")
                LOGGER.info("Module: %s" % module)
                LOGGER.info("")
                i = 1
                for desc in descs:
                    LOGGER.info('(%r) %s' % (descs.index(desc) + 1, desc))
                    i += i
        result = True
        while  result:
            answer = input("\nHave you set the device as descriped above? [Yes/No]: ")
            if answer and (answer.lower() == "no" or answer.lower() == "n"):
                LOGGER.warning("\nYour environment can't meet the test's request. Exit...")
                self._exit(0)
            if answer and (answer.lower() == "yes" or answer.lower() == "y"):
                result = False
        LOGGER.info("")

    def _show_overall_infos(self):
        keys = self._filter_suits(self.conf_items)
        if not keys:
            LOGGER.debug("No conf params are needed here.")
            return

        LOGGER.info("Overall needed configure is as below, please confirm:\n")
        index = 1
        for k,p in self._conf_prompts:
            for pkg in keys:
                v = self._get_value(pkg, k)
                if v is not None:
                    LOGGER.info ('{i}. {p}'.format(i = index, p = p))
                    LOGGER.info('{0: <30}{v}'.format(k + ":", v = v))
                    index += 1
        LOGGER.info("\nIf needed, please update %s file. " % (Constants.PRE_CONF_HOST_INI % str(self.deviceIds)))
        result = True
        while  result:
            next_step = input("Continue to run test? [Yes/No]: ")
            if next_step and (next_step.lower() == "n" or next_step.lower() == "no"):
                self._exit(0)
            if next_step and (next_step.lower() == "yes" or next_step.lower() == "y"):
                result = False
                LOGGER.info("OK! All is well. Let's go ahead...")

    def _exit(self, code=None):
        LOGGER.info("Bye-bye ^_^")
        if code is None:
            code = 0
        raise

    def _get_value(self, section, opt):
        #if self.conf_items.has_key(section):
        if section in self.conf_items:
            vs = self.conf_items.get(section)
            #if vs and vs.has_key(opt.lower()):
            if vs and opt.lower() in vs:
                return vs.get(opt.lower())
        return None

    def _update_json(self):
        for devId in self.deviceIds:
            self._read_conf()
            list = []
            dic = {}
            for value in self.conf_items.values():
                for k,v in value.items():
                    dic[k.upper()] = v
            list.append(dic)
            fp = open(Constants.PRE_CONF_HOST_JSON % devId,"w")
            json.dump(list, fp,indent = 4)

    def _update_txt(self):
        for devId in self.deviceIds:
            self._read_conf()
            dic = {}

            tc_conf_file = open(Constants.NAT_CONF_HOST_TXT % devId, "w")
            for value in self.conf_items.values():
                for k,v in value.items():
                    dic[str.upper(k)] = v

            for k, v in dic.items():
                tc_conf_file.write(k+"="+v+"\n")

            tc_conf_file.close()

