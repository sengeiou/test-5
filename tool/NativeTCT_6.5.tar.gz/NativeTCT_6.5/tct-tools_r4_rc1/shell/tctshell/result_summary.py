#!/usr/bin/python

from xml.etree import ElementTree
import os
import sys
import glob
import shutil
import errno
import copy
from .constants import Constants
from .logmanager import LOGGER

DEBUG = True


def ele_set(element, attrib, content):
    if content:
        element.set(attrib, content)


def ele_find(ele, child):
    if ele.find(child) is not None:
        return ele.find(child)
    else:
        return ElementTree.Element(child)


def copyfiledir(src, dst):
    try:
        shutil.copytree(src, dst)
        return dst
    except OSError as exc:
        if exc.errno == errno.ENOTDIR:
            shutil.copy(src, dst)
            return dst
        else:
            raise


class ResultSummary:
    env = None
    summary = None
    capability = None
    suites = []
    planid = None
    unpass = None

    def __init__(self, plans=None, rerun_suiteFiles=None):
        self.am_suiteFiles = []
        self.result_suiteFiles = []
        self.suiteFiles = {}
        self.rerun_suiteFiles = rerun_suiteFiles
        self.am_suites = []
        self.suites = []
        self.profile = None
        self.deviceid = None
        self.planid = None
        self.plans = plans
        self.planDict = {}
        self.wrapper = None
        if plans:
            headplan = plans[0]
            self.head_profile = headplan.getProfile()
            self.head_deviceid = headplan.getDeviceId()

        self.env = self.ResEnvironment()
        self.summary = self.ResSummary()
        self.capability = self.ResCapabilities()

    def genSummary(self, _resultFolder=None):
        if Constants.RERUNING_MODE:
            self.suiteFiles = self._rerun_findResultSuites_plan()
        else:
            self.suiteFiles = self._findResultSuites(_resultFolder)

        for planFolder, plan in self.suiteFiles.items():
            suiteResults_plan = []
            for suite_am in plan.keys():
                suiteResults_plan.append(suite_am + ".xml")

            currPlan = self.planDict[planFolder]
            self.profile = currPlan.getProfile()
            self.deviceid = currPlan.getDeviceId()
            self.suites = []
            self.env = self.ResEnvironment()
            self.summary = self.ResSummary()
            self.capability = self.ResCapabilities()
            self.planid = currPlan.getPlanName()
            self.parse(suiteResults_plan)
            self.summary_to_xml(os.path.join(planFolder, "summary.xml"))
            if _resultFolder is None:
                self.genPlanStatus(currPlan)
        return

    def genPlanStatus(self, plan):
        root = ElementTree.Element('ns3:plan_status')
        ele_set(root, 'xmlns:ns3', 'http://www.example.org/plan_status/')
        ele_set(root, 'name', plan.getPlanName())
        ele_set(root, 'profile', plan.getProfile())
        ele_set(root, 'executeType', plan.getExecuteType().getCurrType())
        ele_set(root, 'tizenVersion', plan.getTizenVersion())
        device = ElementTree.Element('device')
        ele_set(device, 'device_id', plan.getDeviceId())
        ele_set(device, 'build_id', plan.getBuildId())
        auto_tasks = ElementTree.Element('auto_tasks')
        manual_tasks = ElementTree.Element('manual_tasks')
        if plan.getExecuteType().getCurrType() == "Auto":
            for suite in plan.getSuites():
                executed = ElementTree.Element('executed')
                executed.text = suite.getSuiteName()
                auto_tasks.append(executed)
        elif plan.getExecuteType().getCurrType() == "Manual":
            for suite in plan.getSuites():
                executed = ElementTree.Element('executed')
                executed.text = suite.getSuiteName()
                manual_tasks.append(executed)
        elif plan.getExecuteType().getCurrType() == "All":
            for suite in plan.getSuites():
                executed = ElementTree.Element('executed')
                executed.text = suite.getSuiteName()
                auto_tasks.append(executed)
                manual_tasks.append(executed)

        root.append(device)
        root.append(auto_tasks)
        root.append(manual_tasks)

        Constants.indent(root)
        tree = ElementTree.ElementTree()
        tree._setroot(root)
        tree.write(os.path.join(plan.getResultFolderPath(), \
                "plan_status.xml"), encoding="UTF-8")

    def prepareRerun(self, result):
        suiteFiles = {}
        suitePkgs = {}
        if os.path.isdir(result):
            if os.path.isfile(os.path.join(result, "plan_status.xml")):
                suiteFiles = self.prepareRerun_Plan(result)
        elif os.path.isfile(result):
            suiteFiles = self.prepareRerun_Suite(result)
        else:
            LOGGER.warning("%s result does not exist" % result)
            raise

        for planFolder, plan in suiteFiles.items():
            plan_status = os.path.join(planFolder, "plan_status.xml")
            LOGGER.debug("plan folder path = %s" % planFolder)
            if not os.path.isfile(plan_status):
                LOGGER.warning("%s does not exist" % plan_status)
                raise
            xml_tree = ElementTree.parse(plan_status)
            xml_root = xml_tree.getroot()
            plan_name = xml_root.get('name')
            executeType = xml_root.get('executeType')
            profile = xml_root.get('profile')
            if not profile:
                LOGGER.warning("Couldn`t retrieve 'profile' attribute of plan_status.xml")
                raise
            tizenVersion = xml_root.get('tizenVersion')
            device = ele_find(xml_root, 'device')
            device_id = device.get('device_id')
            build_id = device.get('build_id')
            suite_pkgs = []
            for suite in plan:
                suiteName = os.path.basename(suite)
                suite_pkg_name = None
                profiles = [profile, "common"]
                for prof in profiles:
                    suite_pkg_repo = os.path.join(Constants.SUITES_REPOSITORY \
                            % tizenVersion, prof)
                    if not os.path.isdir(suite_pkg_repo):
                        continue
                    os.chdir(suite_pkg_repo)
                    for suite_pkg in glob.glob("%s*.zip" % suiteName):
                        suite_pkg_name = os.path.abspath(suite_pkg)
                    if suite_pkg_name is not None:
                        suite_pkgs.append(suite_pkg_name)
                        break
                if suite_pkg_name is None:
                    LOGGER.warning("[%s] suite does not exist." % (suiteName))
                    yesorno = None
                    while not (yesorno in ['y', 'n']):
                        yesorno = input(\
                                "Continue without this suite? [y/n]")
                    if yesorno == 'n':
                        LOGGER.warning("please check the default suite \
                                repository: %s[profile]/" \
                                % Constants.SUITES_REPOSITORY \
                                % "[tizen_version]")
                        raise
            suitePkgs[planFolder] = [[plan_name, executeType, profile, \
                    tizenVersion, device_id, build_id, \
                    ], suite_pkgs]
        return suitePkgs

    def prepareRerun_Suite(self, result):
        suiteFiles = {}
        planFolder = os.path.dirname(result)
        suiteFiles[planFolder] = {}
        suiteFiles[planFolder][result[:-4]] = result
        return self.genRerunFile(suiteFiles)

    def prepareRerun_Plan(self, result):
        suiteFiles = {}
        suiteFiles[result] = {}
        os.chdir(result)
        for suite in glob.glob("*.xml"):
            if 'auto.' in suite or 'manual.' in suite or 'rerun' in suite \
                    or 'status.xml' in suite or suite == 'summary.xml':
                        continue
            suiteFile = os.path.abspath(suite)
            suiteFiles[result][suiteFile[:-4]] = suiteFile
        return self.genRerunFile(suiteFiles)

    def genRerunFile(self, rerun_suiteFiles):
        if not bool(rerun_suiteFiles):
            LOGGER.debug("No suite results exist...")
            raise
        filtered_suiteFiles = copy.deepcopy(rerun_suiteFiles)
        self.env = self.ResEnvironment()
        self.summary = self.ResSummary()
        self.capability = self.ResCapabilities()
        self.env.isNull = False
        self.summary.isNull = False
        self.capability.isNull = False
        for planFolder, plan in rerun_suiteFiles.items():
            for suite_am in plan.keys():
                self.suites = []
                result_file = suite_am + ".xml"
                if os.path.isfile(result_file):
                    self.parse([result_file])
                    if not self.rerun_to_xml(suite_am + ".rerun.xml"):
                        del filtered_suiteFiles[planFolder][suite_am]
        return filtered_suiteFiles

    def checkResults(self):
        self.suiteFiles = self._findResultSuites()
        NotRunSuites = []
        for planFolder, plan in self.suiteFiles.items():
            currPlan = self.planDict[planFolder]
            self.profile = currPlan.getProfile()
            self.deviceid = currPlan.getDeviceId()
            for suite_path, suite_am in plan.items():
                if len(suite_am) < 1:
                    NotRunSuites.append(os.path.basename(suite_path))
                    LOGGER.error("No test results returned from lite: %s", \
                            os.path.basename(suite_path))

        return NotRunSuites

    def genResults(self):
        self.suiteFiles = self._findResultSuites()
        NotRunSuites = []
        for planFolder, plan in self.suiteFiles.items():
            currPlan = self.planDict[planFolder]
            self.profile = currPlan.getProfile()
            self.deviceid = currPlan.getDeviceId()
            for suite_path, suite_am in plan.items():
                if len(suite_am) < 1:
                    NotRunSuites.append(os.path.basename(suite_path))
                    LOGGER.critical("No test results returned from lite: %s", \
                            os.path.basename(suite_path))
                    continue
                if '__auto_skip' in suite_am:
                    suite_am.remove('__auto_skip')
                if '__manual_skip' in suite_am:
                    suite_am.remove('__manual_skip')
                if len(suite_am) < 1:
                    LOGGER.warning("Test results not returned from lite \
                            (No manual or auto testcases): %s", \
                            os.path.basename(suite_path))
                    continue

                self.env = self.ResEnvironment()
                self.summary = self.ResSummary()
                self.capability = self.ResCapabilities()
                self.suites = []
                self.parse(suite_am)
                if Constants.RERUNING_MODE:
                    dst = suite_path + "_rerun_result_tmp.xml"
                    tmp_dst = Constants.getTempPath(dst)
                    self.result_to_xml(tmp_dst)
                    self.mergeRerunResults(suite_path + ".xml", tmp_dst)
                    os.remove(tmp_dst)
                else:
                    self.result_to_xml(suite_path + ".xml")

                currPlan.setUnpass(self.getUnpass())
        return

    def getUnpass(self):
        return self.unpass

    def parse(self, suiteFiles):
        unpass = False
        suite_count = 0
        for suiteFile in suiteFiles:
            LOGGER.debug("ABOUT TO PARSE %s" % suiteFile)
            if not Constants.checkFileExists(suiteFile):
                LOGGER.warning("[%s] not found" % suiteFile)
                continue
            if not suiteFile.split("/")[-1].find("tct-") > -1:
                if not suiteFile.split("/")[-1].find(".Tests") > -1:
                    continue
            xml_tree = ElementTree.parse(suiteFile)
            xml_root = xml_tree.getroot()
            if self.env.isNull:
                self.env.parse(ele_find(xml_root, 'environment'))
                if self.env.device_id=="None" and self.plans:
                    LOGGER.debug("%s has inaccurate device_id information" % suiteFile)
                    self.env.device_id = self.plans[0].getDeviceId()
                    LOGGER.debug("Updated device_id : %s" % self.env.device_id)
                dev_buildinfo = Constants.LOCAL_BUILD_INFO_PATH % self.env.device_id
                if os.path.exists(dev_buildinfo):
                    xml_infotree = ElementTree.parse(dev_buildinfo)
                    xml_inforoot = xml_infotree.getroot()
                    for buildinfo in xml_inforoot.findall('buildinfo'):
                        if buildinfo.get('name')=='model' and self.env.device_model=="":
                            self.env.device_model = buildinfo.find('value').text
                        elif buildinfo.get('name')=='manufacturer' and self.env.manufacturer=="":
                            self.env.manufacturer = buildinfo.find('value').text
                        elif buildinfo.get('name')=='buildVersion' and self.env.build_id=="":
                            self.env.build_id = buildinfo.find('value').text
                if self.env.tct_profile is None:
                    self.env.tct_profile = self.profile
            if self.summary.isNull:
                self.summary.parse(ele_find(xml_root, 'summary'))
            else:
                self.summary.merge_time(ele_find(xml_root, 'summary'))

            suite_summary = ele_find(xml_root, 'summary')
            suite_start_at = ele_find(suite_summary, 'start_at').text
            suite_end_at = ele_find(suite_summary,'end_at').text

            suite = self.ResSuite(suite_start_at, suite_end_at)
            ele_suite = ele_find(xml_root, 'suite')
            suite.parse(ele_suite)
            if suite.name is None:
                suite.name = Constants.getSuiteNameFromFile(\
                        os.path.basename(suiteFile))
            self.suites.append(suite)
            if suite.getUnpass():
                LOGGER.debug("[%s] has at least one unpassed testcase" \
                        % str(suite.name))
                unpass = True
            suite_count += 1
        if suite_count < 1:
            LOGGER.warning("No suite results to summarize")
            return

        if self.capability.isNull:
            dev_cap = Constants.LOCAL_CAPABILITY_PATH % self.env.device_id
            if not os.path.isfile(dev_cap):
                LOGGER.error("Device capability does not exist for device: \
                        [%s]" % self.env.device_id)
            else:
                xml_captree = ElementTree.parse(\
                        Constants.LOCAL_CAPABILITY_PATH % self.env.device_id)
                xml_caproot = xml_captree.getroot()
                self.capability.parse(xml_caproot)
        self.unpass = unpass
        return

    def mergeresult_parse(self, src1, src2, priority="FAIL"):
        xml_tree1 = ElementTree.parse(src1)
        xml_tree2 = ElementTree.parse(src2)
        xml_root1 = xml_tree1.getroot()
        xml_root2 = xml_tree2.getroot()
        self.suites = []
        if self.env.isNull:
            self.env.parse(ele_find(xml_root1, 'environment'))
            if self.env.device_id=="None" and self.plans:
                LOGGER.debug("%s has inaccurate device_id information" % suiteFile)
                self.env.device_id = self.plans[0].getDeviceId()
                LOGGER.debug("Updated device_id : %s" % self.env.device_id)
            dev_buildinfo = Constants.LOCAL_BUILD_INFO_PATH % self.env.device_id
            if os.path.exists(dev_buildinfo):
                xml_infotree = ElementTree.parse(dev_buildinfo)
                xml_inforoot = xml_infotree.getroot()
                for buildinfo in xml_inforoot.findall('buildinfo'):
                    if buildinfo.get('name')=='model' and self.env.device_model=="":
                        self.env.device_model = buildinfo.find('value').text
                    elif buildinfo.get('name')=='manufacturer' and self.env.manufacturer=="":
                        self.env.manufacturer = buildinfo.find('value').text
                    elif buildinfo.get('name')=='buildVersion' and self.env.build_id=="":
                        self.env.build_id = buildinfo.find('value').text
            if self.env.tct_profile is None:
                self.env.tct_profile = self.profile

        if self.summary.isNull:
            self.summary.parse(ele_find(xml_root1, 'summary'))

        for suite1 in xml_root1.findall('suite'):
            suite2 = None
            for lookformatch in xml_root2.findall('suite'):
                if lookformatch.get('name') == suite1.get('name'):
                    suite2 = lookformatch
                    break

            suite_summary = ele_find(xml_root1, 'summary')
            suite_start_at = ele_find(suite_summary, 'start_at').text
            suite_end_at = ele_find(suite_summary, 'end_at').text

            suite_obj = self.ResSuite(suite_start_at, suite_end_at)

            if suite2 is None:
                self.suites.append(suite_obj.parse(suite1))
            else:
                self.suites.append(suite_obj.mergeresult_parse(\
                        suite1, suite2, priority))

        if self.capability.isNull:
            dev_cap = Constants.LOCAL_CAPABILITY_PATH % self.env.device_id
            if not os.path.isfile(dev_cap):
                LOGGER.warning("Device capability does not exist for device: \
                        [%s]" % self.env.device_id)
            else:
                xml_captree = ElementTree.parse(\
                        Constants.LOCAL_CAPABILITY_PATH % self.env.device_id)
                xml_caproot = xml_captree.getroot()
                self.capability.parse(xml_caproot)
        return self

    def result_to_xml(self, dest):
        self.copy_style(dest)
        decl_root = ElementTree.Element(None)
        decl1 = ElementTree.PI('xml-stylesheet', \
                'type="text/xsl" href="./style/testresult.xsl"')
        decl1.tail = "\n"
        decl_root.append(decl1)
        #decl_root.append(decl2)
        root = ElementTree.Element('test_definition')
        root.append(self.env.to_xml())
        root.append(self.summary.to_xml())
        for suite in self.suites:
            root.append(suite.result_to_xml())
        Constants.indent(root)
        decl_root.append(root)
        tree = ElementTree.ElementTree()
        tree._setroot(decl_root)
        LOGGER.debug("ABOUT TO WRITE RESULTS INTO %s\n" % dest)
        tree.write(dest, encoding="UTF-8")
        LOGGER.info("RESULTS TO XML: writing into %s\n" % dest)

    def rerun_to_xml(self, dest):
        root = ElementTree.Element('test_definition')
        for suite in self.suites:
            root.append(suite.result_to_xml(fail_only=True))
        hasUnpass = False
        for suite in root.findall('suite'):
            if list(suite) != []:
                hasUnpass = True
        if not hasUnpass:
            return False
        Constants.indent(root)
        tree = ElementTree.ElementTree()
        tree._setroot(root)
        LOGGER.debug("ABOUT TO WRITE RERUN INTO %s\n" % dest)
        tree.write(dest, encoding="UTF-8")
        LOGGER.info("RERUN TO XML: writing into %s\n" % dest)
        return True

    def summary_to_xml(self, dest):
        self.copy_style(dest)
        decl_root = ElementTree.Element(None)
        decl1 = ElementTree.PI('xml-stylesheet', \
                'type="text/xsl" href="./style/summary.xsl"')
        decl1.tail = "\n"
        decl_root.append(decl1)
        root = ElementTree.Element('result_summary')
        ele_set(root, 'plan_name', self.planid)
        root.append(self.env.to_xml())
        root.append(self.summary.to_xml())
        root.append(self.capability.to_xml())
        suites = []
        for suite in self.suites:
            suites.append(suite)
        if (Constants.get_sort_enable() == True):
            def sortSuite(suites):
                return suites.name
            suites.sort(key=sortSuite)
        for suite in suites:
            root.append(suite.summary_to_xml())
        Constants.indent(root)
        decl_root.append(root)
        tree = ElementTree.ElementTree()
        tree._setroot(decl_root)
        LOGGER.debug("ABOUT TO WRITE SUMMARY INTO %s\n" % dest)
        tree.write(dest, encoding="UTF-8")
        LOGGER.info("SUMMARY TO XML: writing into %s\n" % dest)

    def setSortValue(self,wrapper):
        self.wrapper = wrapper;

    def _findResultSuites(self, _resultFolder=None):
        if Constants.RERUNING_MODE:
            auto_suffix = Constants.RERUN_AUTO_RESULT_SUFFIX
            manual_suffix = Constants.RERUN_MANUAL_RESULT_SUFFIX
        else:
            auto_suffix = Constants.AUTO_RESULT_SUFFIX
            manual_suffix = Constants.MANUAL_RESULT_SUFFIX
        suiteFiles = {}
        self.planDict = {}
        for plan in self.plans:
            plan_resultFolder = None
            if _resultFolder is None:
                plan_resultFolder = plan.getResultFolderPath()
            else:
                plan_resultFolder = _resultFolder

            suiteFiles[plan_resultFolder] = {}
            self.planDict[plan_resultFolder] = plan
            for suite in plan.getSuites():
                mergedsuite = os.path.join(plan_resultFolder, suite.suiteName)
                suiteFiles[plan_resultFolder][mergedsuite] = []
                autosuite = mergedsuite + auto_suffix
                manualsuite = mergedsuite + manual_suffix
                if suite.getNoAuto():
                    suiteFiles[plan_resultFolder][mergedsuite]\
                            .append('__auto_skip')
                if suite.getNoManual():
                    suiteFiles[plan_resultFolder][mergedsuite]\
                            .append('__manual_skip')
                if os.path.isfile(autosuite):
                    suiteFiles[plan_resultFolder][mergedsuite]\
                            .append(autosuite)
                if os.path.isfile(manualsuite):
                    suiteFiles[plan_resultFolder][mergedsuite]\
                            .append(manualsuite)
        return suiteFiles

    def _rerun_findResultSuites_plan(self):
        suiteFiles = {}
        plan_resultFolder = self.plans[0].getResultFolderPath()
        suiteFiles[plan_resultFolder] = {}
        os.chdir(plan_resultFolder)
        for suiteFile in glob.glob("*.xml"):
            if 'auto.xml' in suiteFile or 'manual.xml' in suiteFile \
                    or 'rerun.xml' in suiteFile or 'status.xml' \
                    in suiteFile or suiteFile == 'summary.xml':
                continue
            suiteFiles[plan_resultFolder][suiteFile[:-4]] = []
        return suiteFiles

    def mergeRerunResults(self, src1, src2):
        self.mergeSuiteResults(src1, src2, priority="PASS")

    def mergeSuiteResults(self, src1, src2, priority="FAIL"):
        self.suites = []
        self.env = self.ResEnvironment()
        self.summary = self.ResSummary()
        self.capability = self.ResCapabilities()
        self.mergeresult_parse(src1, src2, priority)
        self.result_to_xml(src1)
        return

    def copy_style(self, dest):
        styleFolder = os.path.join(os.path.dirname(dest), 'style')
        if not os.path.isdir(styleFolder):
            copyfiledir(Constants.STYLE_FOLDER, styleFolder)

    def fetch_logs(self, dest):
        return

    class ResEnvironment:
        def __init__(self):
            self.other = None
            self.build_id = None
            self.tct_version = None
            self.tct_profile = None
            self.device_id = None
            self.device_model = None
            self.device_name = None
            self.host = None
            self.manufacturer = None
            self.resolution = None
            self.screen_size = None
            self.isNull = True

        def parse(self, env):
            self.build_id = env.get('build_id')
            #should be added to Constants ..............
            self.tct_profile = env.get('tct_profile')
            self.tct_version = Constants.get_tct_binaryV()
            self.device_id = env.get('device_id')
            self.device_model = env.get('device_model')
            self.device_name = env.get('device_name')
            self.host = env.get('host')
            self.manufacturer = env.get('manufacturer')
            self.resolution = env.get('resolution')
            self.screen_size = env.get('screen_size')
            self.other = ele_find(env, 'other')
            self.isNull = False

        def to_xml(self):
            env = ElementTree.Element('environment')
            ele_set(env, 'build_id', self.build_id)
            ele_set(env, 'tct_version', self.tct_version)
            ele_set(env, 'tct_profile', self.tct_profile)
            ele_set(env, 'device_id', self.device_id)
            if self.device_model is None:
                ele_set(env, 'device_model', "None")
            else:
                ele_set(env, 'device_model', self.device_model)
            ele_set(env, 'device_name', self.device_name)
            ele_set(env, 'host', self.host)
            ele_set(env, 'manufacturer', self.manufacturer)
            ele_set(env, 'resolution', self.resolution)
            ele_set(env, 'screen_size', self.screen_size)
            other = ElementTree.Element('other')
            env.append(other)
            #other needs to be added.....
            return env

    class ResSummary:
        def __init__(self):
            self.isNull = True
            self.test_plan_name = None
            self.start_at = None
            self.end_at = None

        def parse(self, summary):
            self.test_plan_name = summary.get('test_plan_name')
            self.start_at = ele_find(summary, 'start_at').text
            self.end_at = ele_find(summary, 'end_at').text
            self.isNull = False

        def merge_time(self, summary):
            start_at2 = ele_find(summary, 'start_at').text
            end_at2 = ele_find(summary, 'end_at').text
            if self.start_at and start_at2:
                self.start_at = min(self.start_at, start_at2)
            if self.end_at and end_at2:
                self.end_at = max(self.end_at, end_at2)

        def to_xml(self):
            summary = ElementTree.Element('summary')
            ele_set(summary, 'test_plan_name', self.test_plan_name)
            start_at = ElementTree.Element('start_at')
            if self.start_at:
                start_at.text = self.start_at
            summary.append(start_at)
            end_at = ElementTree.Element('end_at')
            if self.end_at:
                end_at.text = self.end_at
            summary.append(end_at)
            return summary

    class ResCapabilities:

        def __init__(self):
            self.isNull = True
            self.capList = []

        def parse(self, caps):
            for xml_cap in caps.findall('capability'):
                cap = self.ResCapability()
                cap.parse(xml_cap)
                self.capList.append(cap)
            self.isNull = False

        def to_xml(self):
            caps = ElementTree.Element('capabilities')
            for cap in self.capList:
                caps.append(cap.to_xml())
            return caps

        class ResCapability:
            def __init__(self):
                self.name = None
                self.support = None
                self.typ = None
                self.val = None

            def parse(self, cap):
                self.name = cap.get('name')
                self.support = cap.get('support')
                self.typ = cap.get('type')
                if self.typ!='boolean':
                    self.val = cap.find('value').text

            def to_xml(self):
                cap = ElementTree.Element('capability')
                ele_set(cap, 'name', self.name)
                ele_set(cap, 'support', self.support)
                ele_set(cap, 'type', self.typ)
                if self.typ!='boolean':
                    val = ElementTree.SubElement(cap, 'value')
                    val.text = self.val
                return cap

    class ResSuite:

        def __init__(self, start_at="", end_at=""):
            self.name = None
            self.category = None
            self.launcher = None
            self.total_case = None
            self.pass_case = None
            self.pass_rate = None
            self.fail_case = None
            self.fail_rate = None
            self.block_case = None
            self.block_rate = None
            self.na_case = None
            self.na_rate = None
            self.suite_set = []
            self.unpass = None
            self.start_at = start_at
            self.end_at = end_at

        def getUnpass(self):
            return self.unpass

        def mergeresult_parse(self, suite1, suite2, priority="FAIL"):
            self.name = suite1.get('name')
            self.category = suite1.get('category')
            self.launcher = suite1.get('launcher')
            for suite_set1 in suite1.findall('set'):
                suite_set2 = None
                for lookformatch in suite2.findall('set'):
                    if lookformatch.get('name') == suite_set1.get('name'):
                        suite_set2 = lookformatch
                        break

                if suite_set2 is None:
                    self.suite_set.append(self.Set().parse(suite_set1))
                else:
                    self.suite_set.append(self.Set().mergeresult_parse(\
                            suite_set1, suite_set2, priority))

            return self

        def parse(self, suite):
            unpass = False
            self.name = suite.get('name')
            self.category = suite.get('category')
            self.launcher = suite.get('launcher')
            for suite_set in suite.findall('set'):
                setparser = self.Set()
                self.suite_set.append(setparser.parse(suite_set))
                if setparser.getUnpass():
                    unpass = True
            self.unpass = unpass
            total_cnt = 0
            pass_cnt = 0
            fail_cnt = 0
            block_cnt = 0
            na_cnt = 0
            for suite_set in suite.findall('set'):
                for tc in suite_set.findall('testcase'):
                    result = tc.get('result')
                    total_cnt += 1
                    if result == "PASS":
                        pass_cnt += 1
                    elif result == "FAIL":
                        fail_cnt += 1
                    elif result == "BLOCK":
                        block_cnt += 1
                    elif result == "N/A":
                        na_cnt += 1
            self.total_case = str(total_cnt)
            if total_cnt == 0:
                if self.name is not None:
                    LOGGER.warning("No testcases in the suite: [%s]" \
                            % self.name)
                #prevent division by zero
                total_cnt = 1
            self.pass_case = str(pass_cnt)
            self.pass_rate = "%.2f" % (float(pass_cnt) / \
                    float(total_cnt) * 100)
            self.fail_case = str(fail_cnt)
            self.fail_rate = "%.2f" % (float(fail_cnt) / \
                    float(total_cnt) * 100)
            self.block_case = str(block_cnt)
            self.block_rate = "%.2f" % (float(block_cnt) / float(total_cnt) \
                    * 100)
            self.na_case = str(na_cnt)
            self.na_rate = "%.2f" % (float(na_cnt) / float(total_cnt) * 100)

            return self

        def result_to_xml(self, fail_only=False):
            suite = ElementTree.Element('suite')
            ele_set(suite, 'category', self.category)
            ele_set(suite, 'launcher', self.launcher)
            ele_set(suite, 'name', self.name)
            for suite_set in self.suite_set:
                checkset = suite_set.to_xml(fail_only)
                if checkset.find('testcase') is not None:
                    suite.append(suite_set.to_xml(fail_only))
            return suite

        def summary_to_xml(self):
            suite = ElementTree.Element('suite')
            ele_set(suite, 'name', self.name)

            start_at_case = ElementTree.Element('start_at')
            if self.start_at:
                start_at_case.text = self.start_at

            end_at_case = ElementTree.Element('end_at')
            if self.end_at:
                end_at_case.text = self.end_at

            total_case = ElementTree.Element('total_case')
            if self.total_case:
                total_case.text = self.total_case

            pass_case = ElementTree.Element('pass_case')
            if self.pass_case:
                pass_case.text = self.pass_case
            pass_rate = ElementTree.Element('pass_rate')
            if self.pass_rate:
                pass_rate.text = self.pass_rate
            fail_case = ElementTree.Element('fail_case')
            if self.fail_case:
                fail_case.text = self.fail_case
            fail_rate = ElementTree.Element('fail_rate')
            if self.fail_rate:
                fail_rate.text = self.fail_rate
            block_case = ElementTree.Element('block_case')
            if self.block_case:
                block_case.text = self.block_case
            block_rate = ElementTree.Element('block_rate')
            if self.block_rate:
                block_rate.text = self.block_rate
            na_case = ElementTree.Element('na_case')
            if self.na_case:
                na_case.text = self.na_case
            na_rate = ElementTree.Element('na_rate')
            if self.na_rate:
                na_rate.text = self.na_rate

            suite.append(start_at_case)
            suite.append(end_at_case)
            suite.append(total_case)
            suite.append(pass_case)
            suite.append(pass_rate)
            suite.append(fail_case)
            suite.append(fail_rate)
            suite.append(block_case)
            suite.append(block_rate)
            suite.append(na_case)
            suite.append(na_rate)
            return suite

        class Set:
            def __init__(self):
                self.name = None
                self.set_debug_msg = None
                self.testcase = []
                self.capabilities = []
                self.unpass = None

            def getUnpass(self):
                return self.unpass

            def parse(self, suite_set):
                unpass = False
                self.name = suite_set.get('name')
                self.set_debug_msg = suite_set.get('set_debug_msg')
                capabilities = ele_find(suite_set, 'capabilities')
                for cap in capabilities.findall('capability'):
                    self.capabilities.append(self.Capability().parse(cap))
                for testcase in suite_set.findall('testcase'):
                    tcparser = self.Testcase()
                    self.testcase.append(tcparser.parse(testcase))
                    if tcparser.getUnpass():
                        unpass = True
                self.unpass = unpass
                return self

            def mergeresult_parse(self, suite_set1, \
                    suite_set2, priority="FALSE"):
                self.name = suite_set1.get('name')
                self.set_debug_msg = suite_set1.get('set_debug_msg')
                capabilities = suite_set1.find('capabilities')
                capabilities = ele_find(suite_set1, 'capabilities')
                for cap in capabilities.findall('capability'):
                    self.capabilities.append(self.Capability().parse(cap))
                for testcase1 in suite_set1.findall('testcase'):
                    testcase2 = None
                    for lookformatch in suite_set2.findall('testcase'):
                        if lookformatch.get('id') == testcase1.get('id'):
                            testcase2 = lookformatch
                            break
                    if testcase2 is None:
                        self.testcase.append(self.Testcase().parse(testcase1))
                    else:
                        self.testcase.append(\
                                self.Testcase().mergeresult_parse(\
                                testcase1, testcase2, priority))
                return self

            def to_xml(self, fail_only):
                suite_set = ElementTree.Element('set')
                ele_set(suite_set, 'name', self.name)
                ele_set(suite_set, 'set_debug_msg', self.set_debug_msg)
                capabilities = ElementTree.Element('capabilities')
                for cap in self.capabilities:
                    capabilities.append(cap.to_xml())
                if len(self.capabilities) > 0:
                    suite_set.append(capabilities)
                for testcase in self.testcase:
                    tc = testcase.to_xml(fail_only)
                    if tc is not None:
                        suite_set.append(tc)
                return suite_set

            class Capability:
                def __init__(self):
                    self.name = None

                def parse(self, cap):
                    self.name = cap.get('name')
                    return self

                def to_xml(self):
                    cap = ElementTree.Element('capability')
                    ele_set(cap, 'name', self.name)
                    return cap

            class Testcase:
                def __init__(self):
                    self.Id = None
                    self.component = None
                    self.execution_type = None
                    self.priority = None
                    self.purpose = None
                    self.result = None
                    self.test_script_entry = None
                    self.actual_result = None
                    self.start = None
                    self.end = None
                    self.stdout = None
                    self.stderr = None
                    self.unpass = None
                    self.onload_delay = None

                def getUnpass(self):
                    return self.unpass

                def parse(self, tc):
                    self.Id = tc.get('id')
                    self.component = tc.get('component')
                    self.execution_type = tc.get('execution_type')
                    self.priority = tc.get('priority')
                    self.purpose = tc.get('purpose')
                    self.result = tc.get('result')
                    self.onload_delay = tc.get('onload_delay')
                    self.test_script_entry = ele_find(\
                            ele_find(tc, 'description'),\
                            'test_script_entry').text
                    self.actual_result = ele_find(\
                            ele_find(tc, 'result_info'), \
                            'actual_result').text
                    self.start = ele_find(ele_find(tc, 'result_info'),\
                            'start').text
                    self.end = ele_find(\
                            ele_find(tc, 'result_info'), 'end').text
                    self.stdout = ele_find(ele_find(tc, 'result_info'),\
                            'stdout').text
                    self.stderr = ele_find(ele_find(tc, 'result_info'),\
                            'stderr').text
                    if self.result != "PASS":
                        self.unpass = True
                    return self

                def mergeresult_parse(self, tc1, tc2, priority="FAIL"):
                    self.Id = tc1.get('id')
                    self.component = tc1.get('component')
                    self.execution_type = tc1.get('execution_type')
                    self.priority = tc1.get('priority')
                    self.purpose = tc1.get('purpose')
                    self.onload_delay = tc1.get('onload_delay')
                    result1 = tc1.get('result')
                    result2 = tc2.get('result')
                    if priority == "FAIL":
                        if result1 == "FAIL":
                            tc = tc1
                        elif result2 == "FAIL":
                            tc = tc2
                        elif result1 == "BLOCK":
                            tc = tc1
                        elif result2 == "BLOCK":
                            tc = tc2
                        elif result1 == "N/A":
                            tc = tc1
                        elif result2 == "N/A":
                            tc = tc2
                        else:
                            tc = tc1
                    if priority == "PASS":
                        tc = tc2
                    self.result = tc.get('result')
                    self.test_script_entry = ele_find(\
                            ele_find(tc, 'description'),\
                            'test_script_entry').text
                    self.actual_result = ele_find(\
                            ele_find(tc, 'result_info'), \
                            'actual_result').text
                    self.start = ele_find(ele_find(tc, 'result_info'), \
                            'start').text
                    self.end = ele_find(ele_find(tc, 'result_info'), \
                            'end').text
                    self.stdout = ele_find(ele_find(tc, 'result_info'), \
                            'stdout').text
                    self.stderr = ele_find(ele_find(tc, 'result_info'), \
                            'stderr').text
                    return self

                def to_xml(self, fail_only):
                    if fail_only and self.result == "PASS":
                        return
                    tc = ElementTree.Element('testcase')
                    ele_set(tc, 'component', self.component)
                    ele_set(tc, 'execution_type', self.execution_type)
                    ele_set(tc, 'id', self.Id)
                    ele_set(tc, 'priority', self.priority)
                    ele_set(tc, 'purpose', self.purpose)
                    ele_set(tc, 'onload_delay', self.onload_delay)
                    if not fail_only:
                        ele_set(tc, 'result', self.result)
                    description = ElementTree.Element('description')
                    tse = ElementTree.Element('test_script_entry')
                    if self.test_script_entry:
                        tse.text = self.test_script_entry
                    description.append(tse)
                    tc.append(description)
                    if fail_only:
                        return tc
                    result_info = ElementTree.Element('result_info')
                    actual_result = ElementTree.Element('actual_result')
                    if self.actual_result:
                        actual_result.text = self.actual_result
                    start = ElementTree.Element('start')
                    if self.start:
                        start.text = self.start
                    end = ElementTree.Element('end')
                    if self.end:
                        end.text = self.end
                    stdout = ElementTree.Element('stdout')
                    if self.stdout:
                        stdout.text = self.stdout
                    stderr = ElementTree.Element('stderr')
                    if self.stderr:
                        stderr.text = self.stderr
                    result_info.append(actual_result)
                    result_info.append(start)
                    result_info.append(end)
                    result_info.append(stdout)
                    result_info.append(stderr)
                    tc.append(result_info)
                    return tc
