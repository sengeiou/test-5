#!/usr/bin/python

import time
from multiprocessing import Process

from .logmanager import LOGGER
from .sdbmanager import SdbManager

class DumpMonitor(Process):

    def __init__(self, _devid, _dump_name):
        Process.__init__(self)
        self.daemon = True
        self.name = "DumpMonitor"
        self.devid = _devid
        self.dumpName = _dump_name
        self.isFinish = False

    def run(self):
        LOGGER.debug("Starting DumpMonitor : %s" % self.devid)
        cmd = self._make_ls_command()
        if not cmd:
            return

        while True:
            if self.isFinish:
                break
            time.sleep(10)
            result = SdbManager.sdbShell(self.devid, cmd)
            if result and self.dumpName:
                for dName in self.dumpName.split(','):
                    if dName and str(result).find(dName) > -1:
                        self.devIns.add_dump_monitor_dev(self.devid)
                        return

    def _make_ls_command(self):
        dump_dir_path = SdbManager.findDumpPath(self.devid)
        if dump_dir_path:
            dump_ls_cmd = "ls -al %s" % dump_dir_path
            return dump_ls_cmd
        else:
            return None

    def kill_dumpmonitor(self):
        self.isFinish = True

