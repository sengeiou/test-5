#!/usr/bin/python

import os
import sys
import glob
from optparse import *
from .constants import Constants
import xml.etree.ElementTree as etree
from .shellplanner import ExecuteType
from .devicemanager import DeviceManager
from .logmanager import LOGGER


def varnarg(option, opt_str, value, parser):
    """ parser srg"""
    value = []
    import re
    for arg in parser.rargs:
        if re.search('^--.+', arg) or re.search('^-[\D]', arg):
            break
        value.append(arg)

    del parser.rargs[:len(value)]
    setattr(parser.values, option.dest, value)


class IntentionType:
    TestPlan = 1
    TestSuite = 2
    TestCase = 3
    AutoPlan = 4
    DistPlan = 5
    TestProfile = 6


class ShellWrapper:
    def __init__(self, devmgr):
        self.devmgr = devmgr
        self.running_mode = None
        self.options = None
        self.USAGE = "\n\
    run examples: \n\
        tct-shell --testplan  <somewhere>/testplan.xml\n\
        tct-shell --test package1 package2 ... packageN\n\
        tct-shell --test package1 --id caps_screenSizeNormal\n\
        tct-shell --rerun-fail '<somewhere>/result_folder/\n\
    \n\
    Note: \n\
        1) Proxy settings should be disabled when execute webapi packages\n\
        2) run command 'tct-shell', it might not be able to locate related module, \n\
           run command 'export PYTHONPATH=/usr/lib/python2.7/site-packages' to resolve this issue"

    def print_usage(self):
        print (self.USAGE)

    def parse_options(self, argv):
        option_list = [
            make_option("--testplan", "-p", dest="testplan_file", \
                    action="callback", callback=varnarg, \
                    help="Specify the testplan.xml as the test plan."),
            make_option("--profile", "-f", dest="profile", action="callback", \
                    callback=varnarg, help="Specify testing profile. [mobile,wearable,tv]"),
            make_option("--test", "-t", dest="suites", action="callback", \
                    callback=varnarg, help="Specify testing suites. If more than one suite is provided, list them all and separate them with whitespace"),
            make_option("--id", dest="testcase_id", action="callback", \
                    callback=varnarg, help="Specify the ID of a test case to run"),
            make_option("--rerun-fail", dest="fail_result_xml", \
                    action="callback", callback=varnarg,
                        help="Rerun all failed test cases, according to the specified XML."),
            make_option("--distribute", dest="dist_mode",action="callback", callback=varnarg, \
                    help="Specify the testplan.xml for distributing a plan to multiple devices"),
            make_option("--all", "-A", dest="all_tc", action="store_true", \
                    help="All test cases will be executed."),
            make_option("--manual", "-M", dest="only_manual", \
                    action="store_true", help="Only manual test cases will be executed"),
            make_option("--tizen-version", dest="tizenversion", \
                    action="callback", callback=varnarg, \
                    help="Specify the name of tizen-version. The tizen-version is defined in the local repository. and its path is '/opt/tct/'"),
            make_option("--deviceid", "-d", dest="deviceid", \
                    action="callback", callback=varnarg, \
                    help="Set sdb device serial information."),
            make_option("--sort", "-s", dest="sort_packages", \
                     action="store_true", help="Execute sorted packages"),
            make_option("--dbutedevid", dest="dbutedevid", action="callback", callback=varnarg, help="Set sdb device serial information for distribute mode"),
            make_option("--disable", dest="disable_preconfigure", action="store_false", default=True, help="disable the function of pre_configure"),
            make_option("--output", "-o", dest="resultfile", \
                    action="callback", callback=varnarg,
                        help="Specify the output file for result XML. If more than one test xml file provided, results will be merged into this outputfile"),
            make_option("--skip-package", dest="skip_package", action="callback", \
                    callback=varnarg, help="Specify the package names for exclude from the test"),
            make_option("--skip-tc", dest="skip_tc", action="callback", \
                    callback=varnarg, help="Specify the testcase id for exclude from the test"),
            make_option("--log", "-l", dest="loglevel", action="callback", callback=varnarg,
                    help="Set Log level. Logs that are less severe than the level will be ignored. Log levels (in descending severity order): [CRITICAL, ERROR, WARNING, NOTSET, INFO, DEBUG]"),
            make_option("--pre-test", dest="pre_test", action="callback", \
                    callback=varnarg, help="Before running suite, run a given script before installing testsuite."),
            make_option("--post-test", dest="post_test", action="callback", \
                    callback=varnarg, help="After running suite, run a given script before uninstalling testsuite."),
            make_option("--tc-timeout", dest="tc_timeout", action="callback", \
                    callback=varnarg, help="Specify the timeout for TC")
        ]

        # detect non-params
        if len(argv) == 1:
            argv.append("--help")

        Constants.GlobalProfile = ""

        PARSERS = OptionParser(option_list=option_list, usage=self.USAGE)
        (self.options, args) = PARSERS.parse_args()

        #set log level (has to be done first to dislay logs)
        if self.check_log_level():
            if self.options.loglevel is None:
                LOGGER.setLevel(Constants.LOG_LEVELS[Constants.DEFAULT_LOG_LEVEL])
            else:
                LOGGER.setLevel(Constants.LOG_LEVELS[self.options.loglevel[0]])

        if self.is_dist_mode():
            conflicts = ["--distribute"]
            if self.options.deviceid is not None:
                conflicts.append("--deviceid")
            self.conflict_exit(conflicts)
            Constants.setDistMode(True)

        if self.is_testplan_mode():
            conflicts = ["--testplan"]
            if self.options.fail_result_xml is not None:
                conflicts.append("--rerun-fail")
            if self.options.profile is not None:
                conflicts.append("--profile")
            if self.options.suites is not None:
                conflicts.append("--test")
            if self.options.testcase_id is not None:
                conflicts.append("--id")
            self.conflict_exit(conflicts)
            self.running_mode = Constants.RUNNING_MODE_PLAN

        elif self.is_fail_rerun_mode():
            conflicts = ["--rerun-fail"]
            if self.options.profile is not None:
                conflicts.append("--profile")
            if self.options.suites is not None:
                conflicts.append("--test")
            if self.options.testcase_id is not None:
                conflicts.append("--id")
            self.conflict_exit(conflicts)
            self.running_mode = Constants.RUNNING_MODE_RERUN
            Constants.setRerunMode(True)
        elif self.is_suite_mode():
            self.running_mode = Constants.RUNNING_MODE_SUITES
        elif self.is_profile_mode():
            self.running_mode = Constants.RUNNING_MODE_PROFILE

        if self.options.all_tc and self.options.only_manual:
            conflicts = ["--all", "--manual"]
            self.conflict_exit(conflicts)

        self.check_args_number()
        self.check_args_exist()

        if not self.options.tizenversion and not self.is_fail_rerun_mode():
            LOGGER.error("The default tizen version could not be set.")
            conflicts = ["--tizen-version"]
            conflicts.append(None)
            self.conflict_exit(conflicts)

    def conflict_exit(self, conflicts):
        if conflicts == None or len(conflicts) <= 1:
            return

        os.system("tct-shell -h")
        LOGGER.error("\ntct-shell: Conflicted options: %s" % conflicts)
        raise

    def check_args_exist(self):
        opt = ""
        if self.running_mode == Constants.RUNNING_MODE_PLAN and len(self.options.testplan_file) > 0:
            if not Constants.checkFileExists(self.options.testplan_file[0]):
                opt = "--testplan"
        elif self.running_mode == Constants.RUNNING_MODE_RERUN and len(self.options.fail_result_xml) > 0:
            if not Constants.checkFileExists(self.options.fail_result_xml[0]):
                opt = "--rerun-fail"

        if self.options.tizenversion and len(self.options.tizenversion) > 0:
            if not self.check_tizen_version():
                opt = "--tizen-version"

        if self.options.skip_package and len(self.options.skip_package) > 0:
            if not self.check_skip_package():
                opt = "--skip-package"

        if self.options.skip_tc and len(self.options.skip_tc) > 0:
            if not self.check_skip_tc():
                opt = "--skip-tc"

        if self.options.pre_test and len(self.options.pre_test) > 0:
            if not self.check_pre_test():
                opt = "--pre-test"
        if self.options.post_test and len(self.options.post_test) > 0:
            if not self.check_post_test():
                opt = "--post-test"

        if len(opt) > 0:
            os.system("tct-shell -h")
            LOGGER.error("\ntct-shell: error: \"%s\" option requires a proper argument" % opt)
            raise

    def check_args_number(self):
        opt = ""
        if self.running_mode == Constants.RUNNING_MODE_PLAN and len(self.options.testplan_file) < 1:
            opt = "--testplan"
        elif self.running_mode == Constants.RUNNING_MODE_RERUN and len(self.options.fail_result_xml) < 1:
            opt = "--rerun-fail"
        elif self.running_mode == Constants.RUNNING_MODE_PROFILE and len(self.options.profile) < 1:
            opt = "--profile"
        elif self.running_mode == Constants.RUNNING_MODE_SUITES and len(self.options.suites) < 1:
            opt = "--test"
        elif self.options.deviceid is not None and len(self.options.deviceid) < 1:
            opt = "--deviceid"
        elif self.options.testcase_id is not None and len(self.options.testcase_id) < 1:
            opt = "--id"
        elif self.options.tizenversion is not None and len(self.options.tizenversion) < 1:
            opt = "--tizen-version"
        elif self.options.skip_package is not None and len(self.options.skip_package) < 1:
            opt = "--skip-package"
        elif self.options.skip_tc is not None and len(self.options.skip_tc) < 1:
            opt = "--skip-tc"

        if len(opt) > 0:
            os.system("tct-shell -h")
            LOGGER.error("\ntct-shell: error: \"%s\" option requires an argument" % opt)
            raise

    def check_log_level(self):
        if self.options.loglevel is not None:
            if len(self.options.loglevel) < 1:
                os.system("tct-shell -h")
                LOGGER.error("\ntct-shell: error: \"--log\" option requires an argument")
                raise
            else:
                if not self.options.loglevel[0].upper() in ['NOTSET', 'CRITICAL', 'ERROR', 'WARNING', 'INFO', 'DEBUG']:
                    os.system("tct-shell -h")
                    LOGGER.error("\ntct-shell: error: \"--log\" option requires a proper argument.")
                    raise

        return True

    def check_tizen_version(self):
        tizenversion = self.options.tizenversion[0]
        if not Constants.checkFileExists(Constants.TCT_HOME + tizenversion):
            LOGGER.error("A required \'/opt/tct/" + tizenversion + "\' could not be found.")
            return False
        else:
            Constants.set_default_tizenV(tizenversion)
        return True

    def check_skip_package(self):
        packages = self.options.skip_package[0]
        packLen = len(packages)
        return packLen > 0

    def check_skip_tc(self):
        tc = self.options.skip_tc[0]
        tcLen = len(tc)
        return tcLen > 0

    def check_pre_test(self):
        script = self.options.pre_test[0]
        return os.path.isfile(script)

    def check_post_test(self):
        script = self.options.post_test[0]
        return os.path.isfile(script)

    def get_tc_timeout(self):
        if self.options.tc_timeout is not None:
            return self.options.tc_timeout[0]
        else:
            return None

    def getIntentionType(self):
        if self.options.testplan_file is not None:
            return IntentionType.TestPlan
        elif self.options.testcase_id is not None:
            return IntentionType.TestCase
        elif self.options.suites is not None:
            return IntentionType.TestSuite
        elif self.options.profile is not None:
            return IntentionType.TestProfile
        return -1

    def get_planfile(self):
        if self.is_testplan_mode():
            return self.options.testplan_file[0]

    def get_profile(self):
        if self.options.profile is not None:
            return self.options.profile[0]
        else:
            return None

    def get_result_for_rerun(self):
        return self.options.fail_result_xml[0]

    def get_plan_name(self):
        plan_name = ""
        if self.is_testplan_mode():
            plan_name = os.path.basename(self.get_planfile())[:-4]
        return plan_name

    def get_default_stubPort(self):
        return '8000'

    def get_resultFolderPath(self):
        if (self.options.resultfile is not None) and (self.options.resultfile[0] is not None):
            return self.options.resultfile[0]

    def get_deviceId(self):
        self.devmgr.loadDeviceList()
        devices = self.devmgr.getSdbDeviceList()
        if self.options.deviceid:
            for dev in devices:
                if dev.devId == self.options.deviceid[0]:
                    return self.options.deviceid[0]
            LOGGER.error("Error! [%s] device is not connected" % self.options.deviceid[0])
            raise
        else:
            if len(devices) < 1:
                LOGGER.error("No device is connected")
                raise Exception('Device connection is required')
            if len(devices) == 1:
                LOGGER.info("Executing in device : %s" % devices[0].getDeviceId())
                return devices[0].getDeviceId()
            elif len(devices) > 1:
                LOGGER.info("Connected Devices: ...\n")
                for dev in devices:
                    dev._printDevInfo()
                devId = input("Choose device id : ")
                while not devId in [dev.getDeviceId() for dev in devices]:
                    devId = input("Invalid device id!\n\nChoose device id :  \n")
                LOGGER.info("Executing in device : %s" % devId)
                return devId

    def get_profile_name(self):
        plan_file = None
        profile_name = None
        if self.is_testplan_mode():
            plan_file = self.get_planfile()
        if plan_file:
            tree = etree.parse(plan_file)
            root = tree.getroot()
            if root.get('profile') is not None:
                profile_name = root.get('profile')
        return profile_name

    def get_execute_type(self):
        exe_t = None
        if self.options.all_tc:
            exe_t = ExecuteType.createExecuteType("All")
        elif self.options.only_manual:
            exe_t = ExecuteType.createExecuteType("Manual")
        else:
            exe_t = ExecuteType.createExecuteType("Auto")
        return exe_t

    def get_tizenV(self):
        if (self.options.tizenversion is not None) and (self.options.tizenversion[0] is not None):
            return self.options.tizenversion[0]

    def getChoosenProfile(self,suite_name):
        suite_repo = Constants.SUITES_REPOSITORY % self.get_tizenV()
        LOGGER.info("Select profiles for [%s] :" % suite_name)
        for profile in os.listdir(suite_repo):
            if profile=="common" or profile=="pkg_infos":
                continue
            else:
                LOGGER.info(" - %s" % profile)
        suite_temp_profile = None
        while not suite_temp_profile in os.listdir(suite_repo):
            suite_temp_profile = input("\nChoose profile: ")
        if (Constants.GlobalProfile is None) or (Constants.GlobalProfile == ""):
            Constants.GlobalProfile = suite_temp_profile

    def _chooseProfile(self, path_suites):
        suite_profiles = {}
        for suite_path in path_suites:
            suite_zipname = os.path.basename(suite_path)
            sprofile = os.path.basename(os.path.dirname(suite_path))
            if not suite_zipname in suite_profiles:
                suite_profiles[suite_zipname] = []
            suite_profiles[suite_zipname].append(sprofile)
        for suiteName, suiteProfile in suite_profiles.items():
            suite_name = "-".join(suiteName[:-4].split("-")[:-1])
            if len(suiteProfile) == 1:
                if ("common" in suiteProfile) and (self.get_profile() is None):
                    self.getChoosenProfile(suite_name)
                suite_profiles[suiteName] = suiteProfile[0]
                continue
            LOGGER.info("Multiple profiles for [%s] :" % suite_name)
            if "common" in suiteProfile:
                self.getChoosenProfile(suite_name)
            for profile_i in suiteProfile:
                LOGGER.info(" - %s" % profile_i)
            suite_profile = None
            while not suite_profile in suiteProfile:
                suite_profile = input("\nChoose profile: ")
            suite_profiles[suiteName] = suite_profile
        return suite_profiles

    def get_suites(self):
        suites = []
        filtered_suites = []
        suite_repo = Constants.SUITES_REPOSITORY % self.get_tizenV()
        sel_profile = None
        if self.options.profile is not None:
            sel_profile = self.get_profile()
        suite_profiles = {}
        if self.options.suites:
            if sel_profile is None:
                for suite_name in self.options.suites:
                    for profiles in os.listdir(suite_repo):
                        if profiles == "pkg_infos":
                            continue
                        for package in glob.glob(suite_repo + profiles + "/*.zip"):
                            if package.find(suite_name) > -1:
                                suites.append(package)
                    if (len(suites) < 1):
                        LOGGER.error("Error! [%s] suite does not exists" % suite_name)
            else:
                if os.path.exists(os.path.join(suite_repo, sel_profile)):
                    for suite_name in self.options.suites:
                        for package in glob.glob(suite_repo + sel_profile + "/*.zip"):
                            if package.find(suite_name) > -1:
                                suites.append(package)
                if os.path.exists(os.path.join(suite_repo, "common")):
                    for suite_name in self.options.suites:
                        for package in glob.glob(suite_repo + "common/*.zip"):
                            if package.find(suite_name) > -1:
                                suites.append(package)
                if (len(suites) < 1):
                    LOGGER.error("Error! [%s] suite does not exists in [%s] profile" % (suite_name, sel_profile))

        suite_profiles = self._chooseProfile(suites)

        check_profile = None
        multiProfiles = False
        for suiteName, suiteProfile in suite_profiles.items():
            if suiteProfile != 'common':
                if check_profile is not None and check_profile != suiteProfile:
                    multiProfiles = True
                if check_profile is None:
                    check_profile = suiteProfile
            filtered_suites.append(os.path.join(suite_repo, suiteProfile, suiteName))
        if multiProfiles:
            LOGGER.warning("WARNING: Multiple suites run with different profiles")
        return filtered_suites

    def get_profile_suites(self):
        suites = []
        suite_repo = Constants.SUITES_REPOSITORY % self.get_tizenV()
        sel_profile = self.get_profile()
        for profiles in os.listdir(suite_repo):
            if profiles == "pkg_infos":
                continue
            if profiles in sel_profile or profiles == "common":
                for package in sorted(glob.glob(suite_repo + profiles + "/*.zip")):
                    suites.append(os.path.join(suite_repo, profiles, package))

        if len(suites) == 0:
            LOGGER.error('Not found test suites')
            return None

        return suites

    def get_testcase_id(self):
        tc_id = ""
        if self.options.testcase_id is not None:
            #tc_id = " --id %s" % self.options.testcase_id[0] + " --debug"
            tc_id = self.options.testcase_id[0]
        return tc_id

    def get_running_mode(self):
        return self.running_mode

    def get_skip_package(self):
        if self.options.skip_package is not None:
            return self.options.skip_package

    def get_skip_tc(self):
        if self.options.skip_tc is not None:
            return self.options.skip_tc

    def get_pre_test(self):
        if self.options.pre_test is not None:
            return self.options.pre_test[0]

    def get_post_test(self):
        if self.options.post_test is not None:
            return self.options.post_test[0]

    def is_testplan_mode(self):
        return self.options.testplan_file is not None

    def is_profile_mode(self):
        return self.options.profile

    def is_single_mode(self):
        return self.options.testcase_id is not None

    def is_enable_preconf_func(self):
        return self.options.disable_preconfigure

    def is_suite_mode(self):
        return self.options.suites is not None

    def is_fail_rerun_mode(self):
        return self.options.fail_result_xml is not None

    def is_dist_mode(self):
        return self.options.dist_mode is not None

    def get_output_param(self):
        return "-o %s" % self.get_output_file_name()

    def fetch_logs(self, executors):
        logs = {}
        for executor in executors:
            if executor.name == 'ResultManager':
                continue
            plan = executor.plan
            planFolder = plan.getResultFolderPath()
            if not planFolder in logs:
                logs[planFolder] = []
            logs[planFolder].append(\
                    os.path.join(Constants.TCT_LOG_FOLDER, 'MainProcess.log'))
            logs[planFolder].append(\
                    os.path.join(Constants.TCT_LOG_FOLDER, 'critical.log'))
            logs[planFolder].append(\
                    os.path.join(Constants.TCT_LOG_FOLDER, 'debug.log'))
            logs[planFolder].append(\
                    os.path.join(Constants.TCT_LOG_FOLDER, 'error.log'))
            logs[planFolder].append(\
                    os.path.join(Constants.TCT_LOG_FOLDER, 'info.log'))
            logs[planFolder].append(\
                    os.path.join(Constants.TCT_LOG_FOLDER, 'warning.log'))

            if hasattr(executor, 'all_dev_threads'):
                for autoPlanExecutor in executor.all_dev_threads:
                    logs[planFolder].append(\
                            os.path.join(Constants.TCT_LOG_FOLDER, '%s.log' % \
                            autoPlanExecutor.name))

                    logs[planFolder].append(\
                            os.path.join(Constants.TCT_LOG_FOLDER, 'E_%s.log' % \
                            autoPlanExecutor.name))

        for planFolder, thread_logs in logs.items():
            for src_logs in thread_logs:
                Constants.move_log_file(src_logs, planFolder)

    def getDbuteDevIds(self):
        return self.options.dbutedevid

    def isSortPackage(self):
        if self.options.sort_packages is not None:
           return True
        else:
           return False


    def get_distribute_count(self):
        if self.options.dist_mode and len(self.options.dist_mode) > 0:
            return self.options.dist_mode[0]
