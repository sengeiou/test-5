#!/usr/bin/python

from Tkinter import *

class ActionFrame(Frame):
    def __init__(self, parent):
	Frame.__init__(self, parent)
	self.parent = parent
        self.planMenus = []
        self.devMenus = []
        self.tVerMenus = []
	self.plans = []
	self.devices = []
	self.tVersions = []
	self.scenario = []
	self.checkReady = []

    def initUI(self):
        for plan in self.plans:
            self.addPlan()
	self.infoLabel = Label(self.parent, text = "Prepare plans: choose plan, device id and tizen version.\n--Plans that aren't ready will be ignored", width = 75, height =4)
	self.infoLabel.grid(column = 1, row = 0, columnspan=4)
        self.addButton = Button(self.parent, text='Add Plan', command=self.addPlan, width = 37, height = 2)
        self.addButton.grid(column=1, row=1, columnspan=2, sticky='w')
        self.doneButton = Button(self.parent, text='Done', command=self.done, width = 37, height=2)
        self.doneButton.grid(column=2, row=1, columnspan=2, sticky='E')


    def importData(self, plans, devices, tVersions):
        self.plans = plans
        self.devices = devices
        self.tVersions = tVersions
        self.planOptions = plans[:]
        self.devOptions = devices[:]
        self.tVerOptions = tVersions[:]
        self.set_default()

    def set_default(self):
        self.planOptions.insert(0, "Select plan")
        self.devOptions.insert(0, "Select device")
        self.tVerOptions.insert(0, "Select version")
    
    def check(self, internal_v, index, op_mode):
	for i in range(len(self.planMenus)):
            selectedPlan = self.planMenus[i].get()
            selectedDevice = self.devMenus[i].get()
            selectedVersion = self.tVerMenus[i].get()
            if not ("Select " in selectedPlan + selectedDevice + selectedVersion):
		self.checkReady[i].config(text="Plan #%d : Ready" %(i+1), fg="green")
	    else:
		self.checkReady[i].config(text="Plan #%d"%(i+1), fg='red')

    def addPlan(self):
        tail = len(self.planMenus)
        self.planMenus.append(StringVar(self.parent))
        self.planMenus[tail].set(self.planOptions[0])
	self.planMenus[tail].trace_variable('w', callback=self.check)
        self.devMenus.append(StringVar(self.parent))
        self.devMenus[tail].set(self.devOptions[0])
	self.devMenus[tail].trace_variable('w', callback=self.check)
        self.tVerMenus.append(StringVar(self.parent))
        self.tVerMenus[tail].set(self.tVerOptions[0])
	self.tVerMenus[tail].trace_variable('w', callback=self.check)
	self.checkReady.append(Label(self.parent, text="Plan #%d" %(tail+1), fg='red'))
	self.checkReady[tail].config(width = 15)
	self.checkReady[tail].grid(column = 0, row = tail+2)
        w = apply(OptionMenu, (self.parent, self.planMenus[tail]) + tuple(self.planOptions))
        w.config(width = 15)
        w.grid(column = 1, row = tail+2)
        w = apply(OptionMenu, (self.parent, self.devMenus[tail]) + tuple(self.devOptions))
        w.config(width = 40)
        w.grid(column = 2, row = tail+2)
        w = apply(OptionMenu, (self.parent, self.tVerMenus[tail]) + tuple(self.tVerOptions))
        w.config(width = 10)
        w.grid(column = 3, row = tail+2)
	self.check("", "", "")
    def run(self):
        #Button(root, text='Start', command=self.onStart, width=10).pack(side=LEFT)
        #Button(root, text='Exit', command=self.onExit, width=10).pack(side=LEFT)
        self.parent.mainloop()

    def done(self):
	for i in range(len(self.planMenus)):
	    selectedPlan = self.planMenus[i].get()
	    selectedDevice = self.devMenus[i].get()
	    selectedVersion = self.tVerMenus[i].get()
	    if not ("Select " in selectedPlan + selectedDevice + selectedVersion):
		strDevlist = [str(dev) for dev in self.devices]
	        print strDevlist
		print self.devices
		self.scenario.append([selectedPlan, self.devices[strDevlist.index(selectedDevice)], selectedVersion])
	    self.parent.quit()

    def getScenData(self):
	return self.scenario
