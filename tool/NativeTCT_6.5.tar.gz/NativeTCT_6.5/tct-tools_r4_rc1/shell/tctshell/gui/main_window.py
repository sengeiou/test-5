#!/usr/bin/python
from action_frame import ActionFrame
from Tkinter import *

class MainWindow:
    def __init__(self, title='Empty Title'):
	self.root = Tk()
	self.root.title(title)
	self.root.geometry("900x500+300+300")

    def getActionFrame(self):
	self.actionFrame = ActionFrame(self.root)

    def importData(self, plans, devices, tVersions):
	self.actionFrame.importData(plans, devices, tVersions)
	self.actionFrame.initUI()
    def run(self):
	#Button(root, text='Start', command=self.onStart, width=10).pack(side=LEFT)
	#Button(root, text='Exit', command=self.onExit, width=10).pack(side=LEFT)
	self.root.mainloop()
    def getScenData(self):
	return self.actionFrame.getScenData()

    def onExit(self):
	self.root.quit()

    def onStart(self):
	print "START"
