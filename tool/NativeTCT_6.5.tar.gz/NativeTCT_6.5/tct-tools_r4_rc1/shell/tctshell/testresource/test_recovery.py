#!/usr/bin/python

import os, sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from usbmonitor import UsbMonitor
from devicemanager import DeviceManager

class Testusbmonitor:

    def __init__(self):
	self.usbins = None
	self.devins = DeviceManager.getInstance()
        print ''

    def testThread(self):
        self.usbins = UsbMonitor()
        self.usbins.start()

    def killThread(self):
	self.usbins.finishThread()

if __name__ == "__main__":
    ins = Testusbmonitor()
    ins.testThread()
    raw_input()
    ins.killThread()
