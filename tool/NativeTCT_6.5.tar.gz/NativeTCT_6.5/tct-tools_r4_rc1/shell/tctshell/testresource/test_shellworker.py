#!/usr/bin/python

import os, sys
import time

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from test_shellplanner import *
from shellworker import *

class TestShellWorker:

    def __init__(self):
        print ''

    def testInitPlanExecutor(self, plan, count):   
        return PlanExecutor(plan, 1)    

    def testRunPlanExecutor(self):
        planner = TestShellPlanner()
        plan1 = planner.testInitShellPlan()
        multiins = MultiRunnPlan._getInstance()
        multiins.addPlan(plan1.getPlanName(), plan1)

        exe1 = self.testInitPlanExecutor(plan1, 1)
        exe1.start()

    def testCheckRunningPlan(self):
        planner = TestShellPlanner()
        plan1 = planner.testInitShellPlan()
        plan2 = planner.testInitShellPlan2()
        multiins = MultiRunnPlan._getInstance()
        multiins.addPlan(plan1.getPlanName(), plan1)
        multiins.addPlan(plan2.getPlanName(), plan2)

        multiins.printRunnPlan()
        multiins.setCurrPlanRunning(plan1)
     
        multiins.printRunnPlan()
      
    def testGetRunnDevice(self):
        planner = TestShellPlanner()
        plan1 = planner.testInitShellPlan()
        plan2 = planner.testInitShellPlan2()
        multiins = MultiRunnPlan._getInstance()
        multiins.addPlan(plan1.getPlanName(), plan1)
        multiins.addPlan(plan2.getPlanName(), plan2)

        multiins.setCurrPlanRunning(plan1)
        print multiins.getRunnDevice()

    def testIsSelectedDevAvailable(self):
        planner = TestShellPlanner()
        plan1 = planner.testInitShellPlan()
        plan2 = planner.testInitShellPlan2()
        multiins = MultiRunnPlan._getInstance()
        multiins.addPlan(plan1.getPlanName(), plan1)
        multiins.addPlan(plan2.getPlanName(), plan2)

        multiins.setCurrPlanRunning(plan1)
        ins2 = MultiRunnPlan._getInstance()
        print ins2.isSelectedDevAvailable(plan2)

    def testCheckRecoveryDevice(self):
        planner = TestShellPlanner()
        ins = AutoSuiteWorker(planner)
        print ins.checkRecoveryDevice('10.113.74.133:26101')
        
        
if __name__ == "__main__":
    ins = TestShellWorker()
#    ins.testRunPlanExecutor()
#    ins.testCheckRunningPlan()
#    ins.testGetRunnDevice()
#    ins.testIsSelectedDevAvailable()
    ins.testCheckRecoveryDevice()

 
