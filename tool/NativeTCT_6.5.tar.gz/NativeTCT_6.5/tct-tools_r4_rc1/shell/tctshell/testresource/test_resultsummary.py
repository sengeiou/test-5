import os, sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from result_summary import ResultSummary
from shellplanner import TctShellPlan, TctShellSuite, ExecuteType
from logmanager import LOGGER

LOGGER.setLevel("DEBUG")


s1 = TctShellSuite('tct-3dtransforms-css3-tests' , '', '', '', '', '', '' ,'')
s2 = TctShellSuite('tct-capability-tests' , '', '', '', '', '', '' ,'')
s3 = TctShellSuite('tct-fonts-css3-tests' , '', '', '', '', '', '' ,'')
s4 = TctShellSuite('tct-security-tcs-tests' , '', '', '', '', '', '' ,'')

exe_t = ExecuteType.createExecuteType('Auto')

p = TctShellPlan('tmp_name', '0000d85b00006200', 'prof', exe_t, [s1, s2, s3, s4], 'tizen_web_2.4', '/opt/tct/tizen_web_2.4/shell/result/Tizen-2.4.0_Mobile-TM1_20151015.2026/rerun_test_1#1_2016-02-12_21:13:23.364388')


rs = ResultSummary([p])

rs.genSummary()

print p.getUnpass()
