#!/usr/bin/python
import os
import timeit
from time import sleep
tctshell_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(tctshell_path)

plan_file = '/opt/tools/shell/plan/S_mobile_plan.xml'
plan_file2 = '/opt/tools/shell/plan/2.4_mobileF.xml'

start_plan = timeit.default_timer()
os.system("./tct-shell -p %s --tizen-version tizen_web_2.4 -l DEBUG --disable" %plan_file2)
stop_plan = timeit.default_timer()

start_distribute = timeit.default_timer()
os.system("./tct-shell --distribute %s --tizen-version tizen_web_2.4 -l DEBUG --disable" %plan_file2)
stop_distribute = timeit.default_timer()

start_autoplan = timeit.default_timer()
#os.system('./tct-shell --autoplan %s --tizen-version tizen_web_2.4 -l DEBUG --disable' %plan_file2)
stop_autoplan = timeit.default_timer()


plan_time = stop_plan - start_plan
autoplan_time = stop_autoplan - start_autoplan
distribute_time = stop_distribute - start_distribute

print "-"*50

print "\nTest Plan Mode: %d\nAuto Plan Mode: %d\nDistribute Plan Mode: %d\n" %(plan_time, autoplan_time, distribute_time)

print "-"*50


