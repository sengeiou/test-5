import os, sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import threading
from logmanager import LOGGER

class TestLogManager:
    def __init__(self):
	LOGGER.setLevel('DEBUG')
	self.thread1 = threading.Thread(target=self.thread_test, name="Sample_Thread_1")
	self.thread2 = threading.Thread(target=self.thread_test, name="Sample_Thread_1")
	self.thread3 = threading.Thread(target=self.thread_test, name="Sample_Thread_2")

    def thread_test(self):
	LOGGER.debug("thread starting")
	for i in range(10):
	    LOGGER.debug("Counting from 0 to 9: %d" %i)

    def start_test(self):
	LOGGER.debug("Starting Main Test")
	self.thread1.start()
	self.thread1.join()
	self.thread2.start()
	self.thread3.start()

if __name__ == "__main__":
    testLog = TestLogManager()
    testLog.start_test()
