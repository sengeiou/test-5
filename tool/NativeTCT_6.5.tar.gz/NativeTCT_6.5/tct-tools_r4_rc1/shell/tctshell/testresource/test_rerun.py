#!/usr/bin/python

import os
import glob

plan_name = 'plan_rerun_test'
scen_name = 'scen_rerun_test'
tizenVer = 'tizen_web_2.4'

tctshell_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.chdir(tctshell_path)
print tctshell_path
rerun_only = None
while not rerun_only in ['y', 'n']:
    rerun_only = raw_input("rerun_only? ")

if rerun_only == 'n':
    os.system('./tct-plan-generator -m tct-capability-tests --tizen-version %s -o /opt/tools/shell/plan/%s.xml' %(tizenVer, plan_name))

    os.system('./tct-scen-generator -p %s,0000d81400006200,%s %s,0000d81b00006200,%s -o /opt/tools/shell/scen/%s.xml' %(plan_name, tizenVer, plan_name, tizenVer, scen_name))

    os.system('./tct-shell -s /opt/tools/shell/scen/%s.xml -l DEBUG' %scen_name)

    raw_input("Start rerun?")

os.chdir('/opt/tct/%s/shell/result/Tizen-2.4.0_Mobile-TM1_20151015.2026' %tizenVer)

for result in glob.glob("*%s*" %scen_name):
    _result = os.path.abspath(result)
    os.chdir(tctshell_path)
    os.system('./tct-shell --rerun-fail %s -l DEBUG' %_result)
    break
