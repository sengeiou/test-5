#!/usr/bin/python

import os, sys
import time

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from netstatmonitor import *
 
class TestNetstatLogger:
 
    def __init__(self):
        print ''


if __name__ == "__main__":
    print "====================== START TestNetstatLogger ========================"
    netins = NetstatMonitor('10.113.74.133:26101')
    netins.start()
    time.sleep(2)
    netins.waitThread()
    time.sleep(2)
    netins.restartThread()
    print "====================== FINISH TestNetstatLogger ========================"
