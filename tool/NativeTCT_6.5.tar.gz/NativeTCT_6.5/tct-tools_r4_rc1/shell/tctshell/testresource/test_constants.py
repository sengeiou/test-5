#!/usr/bin/python

import os, sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from logmanager import LOGGER
from devicemanager import DeviceManager

class TestConstants:

    DEVICE_IDS = ['0000d81400006200', '0000d81b00006200', '00004e310000324d'] 
    CONN_DEVICE_ID = None
    TEST_TEMP_FOLDER = "/tempFiles/"
    TEST_SUITE_FILE = "tct-capability-tests-2.4.zip"

    @staticmethod
    def checkConnectedDevice():
        devIns = DeviceManager._getInstance()
        devIns._loadDeviceList()
        
        for devid in TestConstants.DEVICE_IDS:
            if devIns._isDeviceAvailable(devid) == True:
                TestConstants.CONN_DEVICE_ID = devid
                break
 
        if TestConstants.CONN_DEVICE_ID is None:
            sys.exit("not connect device")
        else:
            LOGGER.info("connected " + TestConstants.CONN_DEVICE_ID)

    @staticmethod    
    def checkTestResourceFile():
        suiteFilePath = TestConstants.getAbsPath(TestConstants.TEST_TEMP_FOLDER \
                        + TestConstants.TEST_SUITE_FILE)
        if os.path.exists(suiteFilePath):
            LOGGER.info("checked %s file" % suiteFilePath)
        else:
            LOGGER.error("The '%s' file exists error" % suiteFilePath)

    @staticmethod
    def getAbsPath(fileName):
        return os.path.dirname(os.path.abspath( __file__ )) + fileName
