#!/usr/bin/python
from result_summary import ResultSummary


summary1 = ResultSummary("/opt/tct/tizen_web_2.4/manager/result/2016-01-12_15-10-43-526/tct-capability-tests.xml")
summary1.unmarshal()
'''
try:
    summary1.unmarshal()
except Exception, e:
    print "[ Error: reading suite result fail, error %s ]\n" % e
'''
