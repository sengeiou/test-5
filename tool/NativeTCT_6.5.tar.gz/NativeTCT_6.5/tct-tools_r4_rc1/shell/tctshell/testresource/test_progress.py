#!/usr/bin/python
import sys
import os
from Tkinter import *
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from gui.progress import Demo

prog = Demo(Tk())
prog.mainloop()
