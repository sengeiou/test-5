#!/usr/bin/python

import os, sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from shellplanner import *
from test_constants import *

class TestShellPlanner:

    def __init__(self):
        self.devId1 = '0000d81b00006200'
        self.devId2 = '0000d81400006200'
        self.devId3 = '00004e310000324d'
        self.devId4 = '0000d8f800006200'

    #return TctShellPlan
    def testInitShellPlan(self):
        suite1 = TctShellSuite('tct-capability-tests', None, 15,0, \
                 'common/tct-capability-tests-2.4.zip', 'WRTLauncher',\
                 'Compliance', 'tizen_web_2.4', 8000)

        '''
        suite2 = TctShellSuite('tct-alarm-tizen-tests', None, 60,0, \
                 'common/tct-alarm-tizen-tests-2.4.zip', 'WRTLauncher', \
                 'Tizen Web Device APIs', 'tizen_web_2.4', 8000)

        '''
        suites = [suite1]

        return TctShellPlan('testPlan1', self.devId2, 'mobile', ExecuteType('Auto'),suites, \
               'tizen_web_2.4', '/opt/tct/tizen_web_2.4/shell/result/testresult/')      

    def testInitShellPlan2(self):
        suite1 = TctShellSuite('tct-capability-tests', None, 15,0, \
                 'common/tct-capability-tests-2.4.zip', 'WRTLauncher',\
                 'Compliance', 'tizen_web_2.4', 8000)

        suite2 = TctShellSuite('tct-alarm-tizen-tests', None, 60,0, \
                 'common/tct-alarm-tizen-tests-2.4.zip', 'WRTLauncher', \
                 'Tizen Web Device APIs', 'tizen_web_2.4', 8000)

        suites = [suite1, suite2]

        return TctShellPlan('testPlan2', self.devId3, 'mobile', ExecuteType('Auto'),suites, \
               'tizen_web_2.4', '/opt/tct/tizen_web_2.4/shell/result/testresult/')    

   
    def testInitShellPlan3(self):
        suite1 = TctShellSuite('tct-capability-tests', None, 15,0, \
                 'common/tct-capability-tests-3.0.zip', 'WRTLauncher',\
                 'Compliance', 'tizen_web_3.0', 8000)

        suites = [suite1]

        return TctShellPlan('testPlan3', self.devId3, 'mobile', ExecuteType('Auto'),suites, \
               'tizen_web_3.0', '/opt/tct/tizen_web_3.0/shell/result/testresult/')    

    def testInitShellPlan4(self):
        suite1 = TctShellSuite('tct-capability-tests', None, 15,0, \
                 'common/tct-capability-tests-2.4.zip', 'WRTLauncher',\
                 'Compliance', 'tizen_web_2.4', 8000)

        suites = [suite1]

        return TctShellPlan('testPlan4', self.devId4, 'mobile', ExecuteType('Auto'),suites, \
               'tizen_web_2.4', '/opt/tct/tizen_web_2.4/shell/result/testresult/')    


    def testInstSuiteinHost(self):
        plan1 = self.testInitShellPlan3()
        suite = plan1.getSuites(); 
        #suite[0].installSuite(plan1.getDeviceId(), plan1.getDevTctTmpPath())
        suite[0].sdbCheckSuite(plan1.getDeviceId(), suite[0].getSuiteName())
	#suite[0].unInstallSuite(plan1.getDeviceId(), plan1.getDevTctTmpPath())

    def testInstSuiteinTarget(self):
        plan1 = self.testInitShellPlan4()
        suite = plan1.getSuites(); 
        suite[0].installSuite(plan1.getDeviceId(), plan1.getDevTctTmpPath())
        suite[0].sdbCheckSuite(plan1.getDeviceId(), suite[0].getSuiteName())
	suite[0].unInstallSuite(plan1.getDeviceId(), plan1.getDevTctTmpPath())
        

if __name__ == "__main__":
    ins = TestShellPlanner()
    ins.testInstSuiteinHost()
    ins.testInstSuiteinTarget()





 
