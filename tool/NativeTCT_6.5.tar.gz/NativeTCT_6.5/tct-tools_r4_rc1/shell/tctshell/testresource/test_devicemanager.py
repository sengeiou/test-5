#!/usr/bin/python

import os, sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from devicemanager import *

class TestDeviceManager:

    def __init__(self):
        


