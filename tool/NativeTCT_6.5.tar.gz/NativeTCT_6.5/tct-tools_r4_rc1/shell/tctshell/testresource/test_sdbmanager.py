#!/usr/bin/python

import os, sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from sdbmanager import SdbManager
from logmanager import LOGGER
from test_constants import TestConstants

class TestSdbManager:
 
    def __init__(self):
        TestConstants.checkConnectedDevice()
        TestConstants.checkTestResourceFile()    

        self.deviceId = TestConstants.CONN_DEVICE_ID
        self.suiteFilePath = TestConstants.getAbsPath(TestConstants.TEST_TEMP_FOLDER + \
                             TestConstants.TEST_SUITE_FILE)
        self.suiteFile = TestConstants.TEST_SUITE_FILE
   
    def testSdbPush(self):
        local = self.suiteFilePath
        remote = '/opt/usr/media/tct/tmp/'

        SdbManager.sdbShell(self.deviceId, "rm -rf " + remote + self.suiteFile)
        SdbManager.sdbPush(self.deviceId, local, remote)
   
    def testSdbPull(self):
        self.testSdbPush()

        local = self.suiteFilePath + "-test"
        SdbManager.hostCommand("rm -rf " + local)

        remote = '/opt/usr/media/tct/tmp/' + self.suiteFile
        SdbManager.sdbPull(self.deviceId, remote, local)
        
    def testSdbShell(self):
        SdbManager.sdbShell(self.deviceId, 'ls -l')

    def testSdbRootOn(self):
        SdbManager.sdbRootOn(self.deviceId)

if __name__ == "__main__":
    print "==================== START TestSDManager ====================="
    ins = TestSdbManager()
    ins.testSdbPush()
    ins.testSdbPull()
    ins.testSdbShell()
    ins. testSdbRootOn()
    print "==================== FINISH TestSDManager ====================="

