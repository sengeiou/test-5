import logging
import os
import shutil

BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE = range(8)

RESET_SEQ = "\033[0m "
COLOR_SEQ = "\033[%dm "
BOLD_SEQ = "\033[1m "

LEVELS = {"CRITICAL": 50,
          "ERROR": 40,
          "WARNING": 30,
          "INFO": 20,
          "DEBUG": 10,
          "NOTSET": 0
          }

COLORS = {"CRITICAL": YELLOW,
          "ERROR": RED,
          "WARNING": YELLOW,
          "INFO": WHITE,
          "DEBUG": CYAN,
          "NOTSET": WHITE
          }


def formatter_message(message, use_color=True):
    if use_color:
        message = message.replace("$RESET", RESET_SEQ)\
                .replace("$BOLD", BOLD_SEQ)
    else:
        message = message.replace("$RESET", "").replace("$BOLD", "")

    return message


class ColoredFormatter(logging.Formatter):

    def __init__(self, msg, datefmt, use_color=True):
        logging.Formatter.__init__(self, msg, datefmt)
        self.use_color = use_color

    def format(self, record):
        levelname = record.levelname
        record_msg = record.msg
        if self.use_color and levelname in COLORS:
            if levelname == "ERROR":
                colorsq = "\033[1;%dm "
            else:
                colorsq = COLOR_SEQ
            colored_msg = colorsq % (30 + COLORS[levelname]) \
                    + record_msg + RESET_SEQ
            record.msg = colored_msg

        return logging.Formatter.format(self, record)

class MultiHandler(logging.Handler):

    def __init__(self, dirname):
        super(MultiHandler, self).__init__()
        self.files = {}
        self.dirname = dirname

    def flush(self):
        self.acquire()
        try:
            for fp in self.files.values():
                fp.flush()
        finally:
            self.release()

    def _get_or_open(self, key):
        self.acquire()
        try:
            if key in self.files:
                return self.files[key]
            else:
                file_path = os.path.join(self.dirname, "%s.log" % key)
                if os.path.exists(file_path):
                    os.remove(file_path)
                fp = open(file_path, "a")
                self.files[key] = fp
                return fp
        finally:
            self.release()

    def deformat(self, msg):
        import re
        ansi_escape = re.compile(r'\x1b[^m]*m')

        return ansi_escape.sub('', msg)

    def emit(self, record):
        try:
            fp = self._get_or_open(record.processName)
            msg = self.format(record)
            #fp.write('%s\n' % self.deformat(msg).encode("utf-8"))
            fp.write("%s\n" % str(msg))
        except (KeyboardInterrupt, SystemExit):
            raise
        except UnicodeDecodeError:
            pass
        except:
            self.handleError(record)


class LogManager:

    def __init__(self, logname="mTCT", log_format=\
            '%(asctime)15s %(processName)18s #%(levelname).3s %(module) 18s:%(lineno)-4d %(message)s', \
            dirname="/opt/tools/shell/tmp/logs"):
        self._remove_logdir(dirname)
        colorformatter1 = ColoredFormatter(formatter_message(log_format), \
                "%Y-%m-%d_%H:%M:%S", False)

        stderr_handler = logging.StreamHandler()
        stderr_handler.setFormatter(colorformatter1)
        logging.getLogger().addHandler(stderr_handler)

        infoHandler = logging.FileHandler(dirname + "/info.log")
        infoHandler.setLevel(logging.INFO)
        infoHandler.setFormatter(colorformatter1)

        debugHandler = logging.FileHandler(dirname + "/debug.log")
        debugHandler.setLevel(logging.DEBUG)
        debugHandler.setFormatter(colorformatter1)

        errorHandler = logging.FileHandler(dirname + "/error.log")
        errorHandler.setLevel(logging.ERROR)
        errorHandler.setFormatter(colorformatter1)

        warnHandler = logging.FileHandler(dirname + "/warning.log")
        warnHandler.setLevel(logging.WARNING)
        warnHandler.setFormatter(colorformatter1)

        criticalHandler = logging.FileHandler(dirname + "/critical.log")
        criticalHandler.setLevel(logging.CRITICAL)
        criticalHandler.setFormatter(colorformatter1)

        multi_handler = MultiHandler(dirname)
        multi_handler.setFormatter(colorformatter1)
        logging.getLogger().addHandler(multi_handler)

        _logger = logging.getLogger(logname)
        _logger.addHandler(infoHandler)
        _logger.addHandler(debugHandler)
        _logger.addHandler(errorHandler)
        _logger.addHandler(warnHandler)
        _logger.addHandler(criticalHandler)

        _logger.setLevel('INFO')
        self.logger = _logger

    def _get_logger(self):
        return self.logger

    def _remove_logdir(self, dirname):
        if os.path.exists(dirname):
            shutil.rmtree(dirname)
        if not os.path.exists(dirname):
            os.makedirs(dirname, mode=0o777)

        if not os.access(dirname, os.W_OK):
            raise Exception("Directory %s not writeable" % dirname)


LOGGER = LogManager()._get_logger()
