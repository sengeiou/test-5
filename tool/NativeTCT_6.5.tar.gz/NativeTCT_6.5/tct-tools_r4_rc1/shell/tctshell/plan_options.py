#!/usr/bin/python
#
# Copyright (C) 2012 Intel Corporation
# 
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
#
# Authors:
#              Tang, Shaofeng <shaofeng.tang@intel.com>

import sys
import os
import re
import platform
import glob
from optparse import *
from constants import Constants
from logmanager import LOGGER


#show all available suites
def _show_available_suites(option, opt_str, value, parser):
    print "Test Suites:...\n"
    os.chdir("/opt/tct/")
    for t_version in glob.glob("tizen*"):
        print "Tizen Version : %s" % t_version
        package_dir = os.path.join(os.path.abspath(t_version), 'packages')
        if not os.path.isdir(package_dir):
            continue
        os.chdir(package_dir)
        for profile in glob.glob("*"):
            if profile == 'pkg_infos':
                continue
            print "      profile : %s" % profile
            os.chdir(os.path.abspath(profile))
            for files in glob.glob("*.zip"):
                print "                " + files[:-4]
            os.chdir('../')
        os.chdir('../../')
    sys.exit(1)


def _print_planfolder(option, opt_str, value, parser):
    print "Plan folder: %s" % Constants.TCT_PLAN_FOLDER
    os.system("tree %s" % Constants.TCT_PLAN_FOLDER)
    sys.exit(1)


def varnarg(option, opt_str, value, parser):
    """ parser srg"""
    value = []
    for arg in parser.rargs:
        if re.search('^--.+', arg) or re.search('^-[\D]', arg):
            break
        value.append(arg)

    del parser.rargs[:len(value)]
    setattr(parser.values, option.dest, value)


class PlanGeneratorOptions:

    def __init__(self):
        self._j = os.path.join
        self._e = os.path.exists
        self._d = os.path.dirname
        self._b = os.path.basename
        self._abspath = os.path.abspath
        self.testkit_dir = "/opt/testkit/lite"
        self.LOG_DIR = self.testkit_dir
        self.PID_FILE = self._j(self.LOG_DIR, "pid.log")
        if not platform.system() == "Linux":
            self.testkit_dir = self._d(self._abspath(__file__))
            sys.path += [self._j(self.testkit_dir)]
            self.testkit_dir = self._j(self.testkit_dir, "results")
        #self.clean_context()
        self.options = None
        self.options = None
        self.running_mode = None
        self.USAGE = "tct-plan-generator [options] --output <somewhere/testplan.xml>\n\
examples: \n\
          tct-plan-generator  -p mobile -o  <somewhere>/testplan.xml\n\
          tct-plan-generator  -p mobile -o  <somewhere>/testplan.xml -r <somewhere>/repository_folder\n\
          tct-plan-generator  -p mobile -o  <somewhere>/testplan.xml -r <somewhere>/repository_folder --match '<regex>'\n\
\n\
    generate a test plan to include all suites in the local repository: \n\
          tct-plan-generator  -p mobile -o  <somewhere>/testplan.xml\n\
    generate a test plan to include all suites in the special repository: \n\
          tct-plan-generator  -p mobile -o  <somewhere>/testplan.xml -r <somewhere>/repository_folder\n\
    generate a test plan to include the suites in the special repository which name is matched with 'webapi*.rpm': \n\
          tct-plan-generator  -p mobile -o  <somewhere>/testplan.xml -r <somewhere>/repository_folder  --match 'webapi*.rpm'\n\
    generate a test plan to include the suites in the special repository which name is matched with 'webapi*.rpm', and exclude the file 'webapi-tizen-push-tests-2.1.6-1.1.armv7l.rpm': \n\
          tct-plan-generator  -p mobile -o  <somewhere>/testplan.xml -r <somewhere>/repository_folder  --match 'webapi*.rpm' --unmatch push\n\
\n\
Note: \n\
          1) run command 'tct-plan-generator', it might not be able to locate related module, run command 'export PYTHONPATH=/usr/lib/python2.7/site-packages' to resolve this issue"

    def print_usage(self):
        print self.USAGE

    def parse_options(self, argv):
        option_list = [
                make_option("-o", "--output", dest="testplan_file", \
                        action="callback", callback=varnarg, \
                        help="Specify the generating testplan in a XML file."),
                make_option("-e", "--execute", dest="execute_type", \
                        action="callback", callback=varnarg, \
                        help="Specify the execute_type of testplan in a XML file."),
                make_option("-r", "--repository", dest="repository_folder", \
                        action="callback", callback=varnarg, \
                        help="Specify the path of local repository."),
                make_option("--tizen-version", dest="tizenversion", \
                        action="callback", callback=varnarg, \
                        help="Specify the name of tizen-version you want to run test. The tizen-version is defined in the local repository. and its path is '/opt/tct/'"),
                make_option("-m", "--match", dest="match_regex", \
                        action="callback", callback=varnarg, \
                        help="The regex for matching filename."),
                make_option("-p", "--profile", dest="test_profile", \
                        action="callback", callback=varnarg, \
                        help="The profile of the test plan."),
                make_option("-u", "--unmatch", dest="unmatch_regex", \
                        action="callback", callback=varnarg, \
                        help="The regex for unmatching filename."),
                make_option("--plan-list", dest="show_plan_folder", \
                        action="callback", callback=_print_planfolder, \
                        help="List all existed plan in the Plan folder. The plan folder is defined in the configure '/opt/tct/shell/CONF'"),
                make_option("-a", "--all-suites", dest="show_suites", \
                        action="callback", callback=_show_available_suites, \
                        help="Show all available test-suites"),
                ]
        # detect non-params
        if len(argv) == 1:
            argv.append("-h")
        PARSERS = OptionParser(option_list=option_list, usage=self.USAGE)
        (self.options, args) = PARSERS.parse_args()

        if self.options.tizenversion:
            self.check_tizen_version()
        else:
            LOGGER.error("The default tizen version could not be set.")
            sys.exit("No tizen version specified")

        if not self.options.match_regex:
            LOGGER.error("The default match_regex could not be set.")
            sys.exit("No match regex specified. Use -m or --match option")

    def check_tizen_version(self):
        tizenversion = self.options.tizenversion[0]
        VER_PATTERN = "^tizen_web_\d.\d|^tizen_native_\d.\d|^tizen_csharp_\d.\d"
        pa = re.compile(VER_PATTERN, re.I)
        ma = pa.match(tizenversion)
        if ma is None:
            LOGGER.error("A required \"/opt/tct/" + tizenversion + \
                    " could not be found.")
            sys.exit("Invalid Tizen version. Tizen version must be in the form of tizen_(web|native|csharp)_#.#")
            return False
        return True

    def get_repository_folder(self):
        if (self.options.repository_folder is not None) and \
            (self.options.repository_folder[0] is not None):
            return self.options.repository_folder[0]
        else:
            return Constants.SUITES_REPOSITORY % self.get_tizenV()

    def get_match_regex(self):
        if (self.options.match_regex is not None) and \
                (self.options.match_regex[0] is not None):
            return self.options.match_regex[0]
        else:
            return Constants.DEFAULT_MATCH_REGEX

    def get_plan_name(self):
        if (self.options.testplan_file is not None) and \
                (self.options.testplan_file[0] is not None):
            name, ext = os.path.splitext(self.options.testplan_file[0])
            return name.split("/")[-1]
        else:
            return Constants.DEFAULT_PLAN_NAME

    def get_profile_name(self):
        if (self.options.test_profile is not None) and \
                 (self.options.test_profile[0] is not None):
            return self.options.test_profile[0]
        else:
            return Constants.DEFAULT_PROFILE_NAME

    def get_execute_type(self):
        if (self.options.execute_type is not None) and \
                (self.options.execute_type[0] is not None):
            return self.options.execute_type[0]
        else:
            return Constants.DEFAULT_EXECUTE_TYPE

    def get_tizenV(self):
        if (self.options.tizenversion is not None) and \
                (self.options.tizenversion[0] is not None):
            return self.options.tizenversion[0]
        else:
            print "Error: Please specify Tizen version with [--tizen-version] option"
            sys.exit(1)

    def get_output(self):
        if (self.options.testplan_file is not None) and \
                (self.options.testplan_file[0] is not None):
            d = os.path.abspath(os.path.dirname(self.options.testplan_file[0]))
            if not os.path.exists(d):
                os.makedirs(d)
            return os.path.abspath(self.options.testplan_file[0])
        else:
            return Constants.TCT_PLAN_FOLDER + "generated_plan.xml"

    def get_unmatch_regex(self):
        if (self.options.unmatch_regex is not None) and \
                (self.options.unmatch_regex[0] is not None):
            return self.options.unmatch_regex[0]
        else:
            return Constants.DEFAULT_UNMATCH_REGEX
