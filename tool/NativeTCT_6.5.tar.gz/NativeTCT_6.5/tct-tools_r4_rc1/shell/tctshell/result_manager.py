#!/usr/bin/python

import os
import threading
from xml.etree import ElementTree

from .logmanager import LOGGER
from .result_summary import ResultSummary
from .constants import Constants
from .shellplanner import MultiRunnPlan


class ResultManager:

    #MultiRunnPlan instance
    mrp = None

    def __init__(self):
        self.mrp = MultiRunnPlan.getInstance()
        self.mrp.attach(self)
        self.lock = threading.Lock()
        self.summary_lock = threading.Lock()
        self.plans = []

    def importResult(self):
        plan = None
        merge_groups = {}
        #plans = self.mrp.getPlanDict().values()[:]
        plans = list(self.mrp.getPlanDict().values())[:]

        for plan in plans:
            tizenVer_buildId = "%s_%s" \
                    % (plan.getTizenVersion(), plan.getBuildId())

            #if merge_groups.has_key(tizenVer_buildId):
            if tizenVer_buildId in merge_groups:
                continue

            merge_group = []
            for plan in plans:
                if "%s_%s" % (plan.getTizenVersion(), plan.getBuildId()) \
                        == tizenVer_buildId:
                    merge_group.append(plan)
            merge_groups[tizenVer_buildId] = merge_group

            #folder path grouping
            #return plans that have finished.
        return merge_groups

    def waitForFinishedPlans(self):
        #self.plans = self.mrp.getPlanDict().values()[:]
        p_list = list(self.mrp.getPlanDict().values())
        self.plans = p_list[:]
        while bool(self.mrp.getPlanDict()):
            LOGGER.debug("waiting for lock")
            self.lock.acquire()
            LOGGER.debug("Lock acquired")
            self.checkFinished()
        LOGGER.debug("All plans finished")
        self.print_result_summaries()

    def update(self):
        LOGGER.debug('waiting for summary lock')
        self.summary_lock.acquire()
        LOGGER.debug('summary lock acquired')
        self.lock.release()
        LOGGER.debug("lock released")

    def checkFinished(self):
        LOGGER.debug("Waiting for a plan to finish --> waiting for a lock")
        self.lock.acquire()
        LOGGER.debug("Notified: Plan finished. \
                Check for auto summary merge. --> lock acquired")
        finished_groups = []
        merge_groups = self.importResult()
        for tizenVer_buildId in merge_groups:
            finished_groups.append(tizenVer_buildId)
            for plan in merge_groups[tizenVer_buildId]:
                if not plan.isFinished():
                    finished_groups.remove(tizenVer_buildId)
                    break
        for group in finished_groups:
            self.genSummary(merge_groups[group])
            self.mrp.removePlans(merge_groups[group])
        self.lock.release()
        LOGGER.debug("lock released")
        self.summary_lock.release()
        LOGGER.debug("summary lock released")

    def genSummary(self, plans):
        summary_file = None
        if len(plans) == 1:
            summary_file = os.path.join(\
                    plans[0].getResultFolderPath(), 'summary.xml')
        if summary_file is not None:
            if not os.path.isfile(summary_file):
                LOGGER.warning("Summary file [%s] does not exist" % summary_file)

    def print_result_summaries(self):
        resultFolderPaths = []
        tizenV = None
        if self.plans:
            for plan in self.plans:
                if tizenV is None:
                    tizenV = plan.getTizenVersion()

                resultFolderPath = plan.getResultFolderPath()
                summary_xml = os.path.join(resultFolderPath, 'summary.xml')
                self.print_result_summary(summary_xml)
                resultFolderPaths.append(\
                        (plan.getPlanName(), resultFolderPath))

        distribute = " --distribute" if Constants.isDistMode() else ""
        rerun_command = "tct-shell --tizen-version {0} --rerun-fail %s {1}".\
            format(tizenV, distribute)
        for result in resultFolderPaths:
            LOGGER.info("[%s] Rerun command: %s" \
                    % (result[0], rerun_command % result[1]))

    def print_result_summary(self, result_file):
        if not os.path.isfile(result_file):
            LOGGER.warning("Result_file [%s] does not exist" % result_file)
            return
        tree = ElementTree.parse(result_file)
        root = tree.getroot()
        suites = root.findall('suite')
        total_cases = 0
        pass_cases = 0
        fail_cases = 0
        block_cases = 0
        na_cases = 0
        for total_i in root.findall('suite/total_case'):
            total_cases += int(total_i.text)
        for pass_i in root.findall('suite/pass_case'):
            pass_cases += int(pass_i.text)
        for fail_i in root.findall('suite/fail_case'):
            fail_cases += int(fail_i.text)
        for block_i in root.findall('suite/block_case'):
            block_cases += int(block_i.text)
        for na_i in root.findall('suite/na_case'):
            na_cases += int(na_i.text)

        LOGGER.info("[Result: execute %d suites]" % len(suites))
        LOGGER.info("[  total case number: %d ]" % total_cases)
        if total_cases > 0:
            LOGGER.info("[    Pass Rate: %.2f" \
                    % (float(pass_cases) * 100 / total_cases) + "% ]")
        else:
            LOGGER.info("[    Pass Rate: 0% ]")
        LOGGER.info("[    PASS case number: %d ]" % pass_cases)
        LOGGER.info("[    FAIL case number: %d ]" % fail_cases)
        LOGGER.info("[    BLOCK case number: %d ]" % block_cases)
        LOGGER.info("[    N/A case number: %d ]" % na_cases)
        for suite in suites:
            LOGGER.info(" Suite: %s" % suite.get("name"))
            suite_total_cases = suite.find('total_case').text
            suite_pass_cases = suite.find('pass_case').text
            suite_fail_cases = suite.find('fail_case').text
            suite_block_cases = suite.find('block_case').text
            suite_na_cases = suite.find('na_case').text
            suite_pass_rate = suite.find('pass_rate').text
            LOGGER.info("      |---total case number: %s " % suite_total_cases)
            LOGGER.info("      |      |---Pass rate: %s " \
                    % suite_pass_rate + "%")
            LOGGER.info("      |      |---PASS case number: %s " \
                    % suite_pass_cases)
            LOGGER.info("      |      |---FAIL case number: %s " \
                    % suite_fail_cases)
            LOGGER.info("      |      |---BLOCK case number: %s " \
                    % suite_block_cases)
            LOGGER.info("      |      |---N/A case number: %s " \
                    % suite_na_cases)
