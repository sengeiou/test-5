#!/usr/bin/python

import time

from .sdbmanager import SdbManager
from .logmanager import LOGGER
from multiprocessing import Process


class NetstatMonitor(Process):

    netstat_cmd = 'netstat -tan | grep %s'
    deviceId = ""

    def __init__(self, deviceId, devmgr):
        Process.__init__(self)
        self.daemon = True
        self.name = "Netstat_%s" % deviceId.split('.')[-1].split(':')[0]
        self.deviceId = deviceId
        self.__suspend = True
        self.devmgr = devmgr
        self.recovery_lock = None
        self.isFinish = False

    def run(self):
        LOGGER.debug("Starting NetstatLogger")
        state_changed = False
        wasConnected = True
        while True:
            if self.isFinish:
                break
            time.sleep(10)
            exit_code, stdout, stderr = SdbManager.sdbCommand(\
                    self.netstat_cmd % self.deviceId, 3)
            outLog = stdout.read()
            netValues = self.parsingLogData(outLog)
            isConnected = self.checkConnectState(netValues)
            state_changed = isConnected is not wasConnected

            if state_changed:
                if isConnected:
                    LOGGER.info("Device connected")
                    self.device_recovered()
                else:
                    LOGGER.error("Device disconnected")
                self.reLoadDeviceList()
            wasConnected = isConnected

    def kill_netMonitor(self):
        self.isFinish = True

    def getThreadStatus(self):
        return self.__suspend

    def restartThread(self):
        time.sleep(10)
        LOGGER.info("Starting %s device monitor" % self.deviceId)
        self.__suspend = False

    def reLoadDeviceList(self):
        LOGGER.debug('Netstat: reLoadDeviceList')
        if not self.devmgr.loadDeviceList():
            LOGGER.error('0 device is connected')

    def parsingLogData(self, outLog):
        outLog = outLog.rstrip()
        resultLog = outLog.split(' ')
        parsLog = []
        for log in resultLog:
            if len(log) != 0:
                parsLog.append(log)

        return parsLog

    def setup_recovery(self, lock):
        self.recovery_lock = lock

    def device_recovered(self):
        try:
            self.recovery_lock.release()
        except:
            pass

    def checkConnectState(self, netValues):
        for val in netValues:
            if val and val.find('ESTABLISHED') != -1:
                return True

        return False
