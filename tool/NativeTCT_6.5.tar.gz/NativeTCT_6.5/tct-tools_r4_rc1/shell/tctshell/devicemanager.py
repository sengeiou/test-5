#!/usr/bin/python

import queue
from multiprocessing.managers import BaseManager

from .sdbmanager import SdbManager
from .constants import Constants
from .logmanager import LOGGER
from xml.etree import ElementTree
from .exception import DevNotFoundErr


class DeviceManager(object):
    devices = []
    dbutedevIds = []
    dumpMonitor_q = queue.Queue()

    def __init__(self):
        if len(self.devices) == 0:
            self.loadDeviceList()

    def _updateConnDevice(self, connDevices):
        self._resetDevices()

        for dev in connDevices:
            self.devices.append(dev)

    def _resetDevices(self):
        listSize = len(self.devices)
        del self.devices[0:listSize]

    def deleteFaultDevice(self, _devid):
        if len(self.devices) < 1:
            return False
        else:
            devs = self.getSdbDeviceList()
            for idx, dev in enumerate(devs):
                devId = dev.getDeviceId()
                if devId == _devid:
                    del self.devices[idx]
                    return True
        return False

    def isDeviceAvailable(self, deviceId):
        if len(self.devices) == 0:
            return False
        else:
            devs = self.getSdbDeviceList()
            for dev in devs:
                devId = dev.getDeviceId()
                if devId == deviceId:
                    return True
        return False

    def getDeviceSize(self):
        return len(self.devices)

    def getSdbDeviceList(self):
        if self.dbutedevIds:
            remake_devices = []
            for devid in self.dbutedevIds:
                dev = self.getDevice(devid)
                if dev:
                    remake_devices.append(dev)

            return remake_devices
        else:
            return self.devices

    def getDevice(self, deviceId):
        for dev in self.devices:
            if dev.getDeviceId() == deviceId:
                return dev

        LOGGER.error("The '%s' device Id exists error" % deviceId)
        return None

    def loadDeviceList(self):
        connDevices = []
        sdbOutLog = SdbManager.sdbDevices()
        if not sdbOutLog:
            return False
        devicesInfo = sdbOutLog.replace("List of devices attached", "")
        devList = devicesInfo.split('\n')

        for dev in devList:
            if len(dev) > 1:
                devInfoItem = dev.split('\t')
                if len(devInfoItem) < 2:
                    continue
                devId = devInfoItem[0].rstrip()
                devType = devInfoItem[1].rstrip()
                devName = devInfoItem[2].rstrip()
                if not (devType == "unknown" or devType == "offline" \
                        or devId == "unknown" or devId == "offline"):
                    connDevices.append(SdbDevice(devId, devName, devType))
                else:
                    raise DevNotFoundErr(devId)

        if len(connDevices) > 0:
            self._updateConnDevice(connDevices)
            LOGGER.debug("Connected Devices = %s" \
                    % str([dev.devId for dev in self.devices]))
            return True
        else:
            self._resetDevices()
            LOGGER.debug("Reset Devices List")
            return False

    def setDbuteDevIds(self, _devIds):
        self.dbutedevIds = _devIds

    def add_dump_monitor_dev(self, _devid):
        LOGGER.debug("add dump monitor dev : %s" % _devid)
        self.dumpMonitor_q.put(_devid)

    '''
    def check_dump_monitor_que(self, _devid):
        LOGGER.debug("check dump monitor queue : %s" % _devid)
        temp_devs = []
        while not self.dumpMonitor_q.empty():
            devid = self.dumpMonitor_q.get()
            if devid == _devid:
                return True
            else:
                temp_devs.append(devid)

        for dev in temp_devs:
            self.dumpMonitor_q.put(dev)

        return False
    '''


class SdbDevice:
    def __init__(self, devId, devName, devType):
        self.devId = devId
        self.devName = devName
        self.devType = devType
        self.devBuildId = ""

    def _printDevInfo(self):
        LOGGER.info("===== Device Infomation =====")
        LOGGER.info(" Name : " + self.devName)
        LOGGER.info(" Id   : " + self.devId)
        LOGGER.info(" Type : " + self.devType)
        LOGGER.info("=============================")

    def getDeviceId(self):
        return self.devId

    def getDeviceName(self):
        return self.devName

    def getDeviceType(self):
        return self.devType

    def getDeviceBuildId(self):
        if self.devBuildId == "":
            infoFilePath = Constants.LOCAL_BUILD_INFO_PATH % self.devId
            if Constants.checkFileExists(infoFilePath) is False:
                LOGGER.error("Not Found BuildInfo.xml file in %s" % self.devId)
                LOGGER.error('Path : %s' % infoFilePath)
                return None
            try:
                xml_tree = ElementTree.parse(infoFilePath)
                xml_root = xml_tree.getroot()

                for buildinfo in xml_root.findall('buildinfo'):
                    if buildinfo.get("name") == "buildVersion":
                        self.devBuildId = buildinfo.find("value").text
                        return self.devBuildId

            except Exception as e:
                LOGGER.warning("[ reading buildInfo XML fail, error : %s ] " % e)
                return None
        else:
            return self.devBuildId

class DevBaseManager(BaseManager):
    pass

DevBaseManager.register('DeviceManager', DeviceManager)

