#!/usr/bin/python

from multiprocessing import Queue
from .shellguider import Guider
from .testenvironment import TestEnvironment
from .usbmonitor import UsbMonitor
from .netstatmonitor import NetstatMonitor
from .dumpmonitor import DumpMonitor

from .logmanager import LOGGER
from .constants import Constants


class EnvironmentManager:
    def __init__(self, plans, isPreconSet, devmgr):
        self.plans = plans
        self.dev_plans = {}
        self.env_threads = []
        self.connDevices = []
        self.isPreconSet = isPreconSet
        self.usb_monitor = None
        self.netstat_monitors = []
        self.dump_monitors = []
        self.dev_recovery_locks = {}
        self.devmgr = devmgr
        self.orgPlans()
        self.load_devices()
        self.init_monitors()

    def init_monitors(self):
        if Constants.isDistMode():
            for dev in self.connDevices:
                dev_id = dev.getDeviceId()
                if dev_id is None:
                    continue
                if Constants.isSdbNetwork(dev_id):
                    pass
                    #netstat_m = NetstatMonitor(dev_id, self.devmgr)
                    #self.netstat_monitors.append(netstat_m)
                else:
                    if not self.usb_monitor:
                        pass
                        #self.usb_monitor = UsbMonitor(self.devmgr)
                '''
                if self.dump_name:
                    dump_m = DumpMonitor(dev_id, self.dump_name)
                    self.dump_monitors.append(dump_m)
                '''
        else:
            pass
            '''
            for devId in self.dev_plans.keys():
                if Constants.isSdbNetwork(devId):
                    netstat_m = NetstatMonitor(devId, self.devmgr)
                    self.netstat_monitors.append(netstat_m)
                else:
                    if not self.usb_monitor:
                        self.usb_monitor = UsbMonitor(self.devmgr)
            '''

    def kill_monitors(self):
        if self.usb_monitor:
            self.usb_monitor.kill_usbmonitor()

        self.kill_netstatMonitor()

        for dumpM in self.dump_monitors:
            dumpM.kill_dumpmonitor()

    def kill_netstatMonitor(self):
        for nsMonitor in self.netstat_monitors:
            nsMonitor.kill_netMonitor()

    def kill_usbMonitor(self, devid):
        if self.usb_monitor:
            self.usb_monitor.device_recovered(devid)

    def start_usbMonitor(self):
        if self.usb_monitor:
            self.usb_monitor.start()

    def start_netstatMonitor(self):
        for nsMonitor in self.netstat_monitors:
            nsMonitor.start()

    def start_dumpMonitor(self):
        for dumpMonitor in self.dump_monitors:
            dumpMonitor.start()

    def load_devices(self):
        self.devmgr.loadDeviceList()
        self.connDevices = self.devmgr.getSdbDeviceList()

    def orgPlans(self):
        if self.plans:
            for plan in self.plans:
                if len(plan.getSuites()) < 1:
                    continue
                deviceId = plan.getDeviceId()
                tizenVer = plan.getTizenVersion()

                if not deviceId in self.dev_plans:
                    self.dev_plans[deviceId] = {}

                if not tizenVer in self.dev_plans[deviceId]:
                    self.dev_plans[deviceId][tizenVer] = []

                self.dev_plans[deviceId][tizenVer].append(plan)

    def env_setup(self):
        err_msg_queue = Queue()
        for devId, devId_val in self.dev_plans.items():
            for tizenVer, plans in devId_val.items():
                if Constants.isDistMode():
                    for dev in self.connDevices:
                        tEn = TestEnvironment(tizenVer, dev.getDeviceId(), \
                                self.isPreconSet, err_msg_queue, self.devmgr)
                        tEn.start()
                        self.env_threads.append(tEn)
                else:
                    tEn = TestEnvironment(tizenVer, devId, self.isPreconSet, \
                            err_msg_queue, self.devmgr)
                    tEn.start()
                    self.env_threads.append(tEn)

        for thread in self.env_threads:
            thread.join()

        if not err_msg_queue.empty():
            raise

    def guider_setup(self):
        for devId, devId_val in self.dev_plans.items():
            for tizenVer, plans in devId_val.items():
                for plan in plans:
                    if Constants.isDistMode():
                        guider = Guider(plan, [dev.getDeviceId() \
                                for dev in self.connDevices])
                    else:
                        guider = Guider(plan)

                    guider.init_items()
                    if self.isPreconSet:
                        guider.setup_manual_env()
                    guider.setup_default_env()

    def check_build_ids(self):
        if Constants.isDistMode() and \
                not Constants.checkBuildIds(self.connDevices):
            LOGGER.error("All connected devices should have the same build ids for distribute/auto-plan mode.")
            LOGGER.error("Devices with different build ids connected")
            raise
        return True

    def setup(self):
        self.env_setup()
        self.check_build_ids()
        self.guider_setup()

    def start_monitor(self):
        self.start_usbMonitor()
        self.start_netstatMonitor()
        self.start_dumpMonitor()

    def recovery_setup(self, workers):
        for worker in workers:
            if Constants.isSdbNetwork(worker.deviceId):
                for nsMonitor in self.netstat_monitors:
                    if nsMonitor.deviceId == worker.deviceId:
                        nsMonitor.setup_recovery(worker.rebootLock)
            else:
                if self.usb_monitor:
                    self.usb_monitor.setup_recovery(\
                            worker.deviceId, worker.rebootLock)
