#!/usr/bin/python
import os
import configparser
from multiprocessing import Process

from .devicemanager import DeviceManager
from .sdbmanager import SdbManager
from .logmanager import LOGGER
from .constants import Constants
from .getcapabilities import GetCap


class TestEnvironment(Process):

    tizenVer = None
    deviceId = None

    def __init__(self, tizenVer, deviceId, isPreconSet, queue, devmgr):
        Process.__init__(self)
        self.tizenVer = tizenVer
        self.deviceId = deviceId
        self.name = "E_{}".format(deviceId)
        self.isPreconSet = isPreconSet
        self.queue = queue
        self.devmgr = devmgr

    def run(self):
        if not self.isPreconSet:
            SdbManager.sdbRootOn(self.deviceId)
        self._isDeviceReady()
        if self.isPreconSet:
            self._reset_health_res_indevice()
        if self.tizenVer == 'tizen_native_6.5' or self.tizenVer == 'tizen_web_6.5' or self.tizenVer == 'tizen_csharp_6.5' or self.tizenVer == 'tizen_native_7.0' or self.tizenVer == 'tizen_web_7.0' or self.tizenVer == 'tizen_csharp_7.0':
            if not self._getCustomModelConfig():
                self.queue.put('no model config')
                return
        self._getDeviceCapability()

        if not self._isHealthCheckPassed():
            self.queue.put('Fail_Healthcheck')
            return

        if not self._isPreconfigPassed():
            self.queue.put('Fail_Preconfig')
            return

        if not self._checkDeviceCapability():
            self.queue.put('Fail_CheckDeviceCapability')
            return

        #SdbManager.resetDumpFiles(self.deviceId)

    def _isDeviceReady(self):
        if self.deviceId:
            return self.devmgr.isDeviceAvailable(self.deviceId)
        else:
            if self.devmgr.getDeviceSize() == 1:
                return True
            else:
                LOGGER.error("No device is connected, \
                        please check or try to reconnect it again")
                return False

    def _reset_health_res_indevice(self):
        tctDir = Constants.getDEVICE_SUITE_TARGET(self.tizenVer)

        delsuitedir_cmd = "rm -rf " + tctDir + "opt/*"
        deltmpdir_cmd = "rm -rf " + tctDir + "tmp/*"

        SdbManager.sdbShell(self.deviceId, delsuitedir_cmd)
        SdbManager.sdbShell(self.deviceId, deltmpdir_cmd)

    def _read_health_check_ini(self):
        parser = configparser.ConfigParser()
        if not os.path.exists(\
                Constants.HEALTH_CHECK_FILE_PATH % self.tizenVer):
            LOGGER.warning("Can`t find the healthcheck.ini file...")
            return

        parser.read(Constants.HEALTH_CHECK_FILE_PATH % self.tizenVer)
        for section in parser.sections():
            if not section:
                continue
            values = []
            for n, v in parser.items(section):
                values.append(v.split(","))
            return values

    def _extractFiles(self):
        shell_tmp_dir = Constants.LOCAL_SHELL_TEMP_PATH % self.deviceId
        model_config = os.path.join(shell_tmp_dir, 'model-config.xml')
        info_ini = os.path.join(shell_tmp_dir, 'info.ini')
        cpu_max_freq = os.path.join(shell_tmp_dir, 'cpuinfo_max_freq')
        cpu_info = os.path.join(shell_tmp_dir, 'cpuinfo')

        if os.path.exists(model_config):
            os.remove(model_config)
        if os.path.exists(info_ini):
            os.remove(info_ini)
        if os.path.exists(cpu_max_freq):
            os.remove(cpu_max_freq)
        if os.path.exists(cpu_info):
            os.remove(cpu_info)
        if self.tizenVer == 'tizen_native_6.5' or self.tizenVer == 'tizen_web_6.5' or self.tizenVer == 'tizen_csharp_6.5' or self.tizenVer == 'tizen_native_7.0' or self.tizenVer == 'tizen_web_7.0' or self.tizenVer == 'tizen_csharp_7.0':
               LOGGER.info("Pull /tmp/model_config.xml = /etc/config/model-config.xml AND /hal/etc/config/model-config.xml")
               SdbManager.sdbPull(self.deviceId, Constants.DEVICE_MODEL_CONFIG_PATH_TEMP, shell_tmp_dir)
        else:
               LOGGER.info("Pull /etc/config/model-config.xml")
               SdbManager.sdbPull(self.deviceId, Constants.DEVICE_MODEL_CONFIG_PATH_ETC, shell_tmp_dir)

        SdbManager.sdbPull(self.deviceId, Constants.DEVICE_INFO_INI_PATH, shell_tmp_dir)
        SdbManager.sdbPull(self.deviceId, Constants.DEVICE_CPU_INFO_PATH, shell_tmp_dir)
        SdbManager.sdbPull(self.deviceId, Constants.EMUL_CPU_INFO_PATH, shell_tmp_dir)

    def _getCustomModelConfig(self):
        if Constants.checkFileExists(os.path.join(Constants.SOURCE_XML_PATH % \
                                                  self.tizenVer, Constants.CUSTOM_MODEL_CONFIG_SCRIPT)) is False:
            LOGGER.error("custom_model_config.sh file not found on given Source path")
            return False
        scriptmountrw_cmd = "mount -o rw,remount /"
        SdbManager.sdbShell(self.deviceId, scriptmountrw_cmd)
        custom_model_config_script = os.path.join(Constants.SOURCE_XML_PATH % \
                                                  self.tizenVer, Constants.CUSTOM_MODEL_CONFIG_SCRIPT)
        LOGGER.info("push CustomModelConfig script in DEVICE_ETC_PATH")                                        
        SdbManager.sdbPush(self.deviceId, custom_model_config_script, Constants.DEVICE_ETC_PATH)

        scriptrun_cmd = Constants.DEVICE_ETC_PATH + Constants.CUSTOM_MODEL_CONFIG_SCRIPT
        scriptdel_cmd = "rm " + Constants.DEVICE_ETC_PATH + Constants.CUSTOM_MODEL_CONFIG_SCRIPT
        
        LOGGER.info("Executing CustomModelCoonfig script");
        SdbManager.sdbShell(self.deviceId, scriptrun_cmd)
        LOGGER.info("Deleting CustomModelCoonfig script from DEVICE_ETC_PATH");
        SdbManager.sdbShell(self.deviceId, scriptdel_cmd)
        return True


    def _getDeviceCapability(self):
        buil_file = Constants.LOCAL_BUILD_INFO_PATH % self.deviceId
        LOGGER.debug('buildinfo path : %s' % buil_file)
        if os.path.exists(buil_file):
            os.remove(buil_file)

        capa_file = Constants.LOCAL_CAPABILITY_PATH % self.deviceId
        LOGGER.debug('capability path : %s' % capa_file)
        if os.path.exists(capa_file):
            os.remove(capa_file)

        self._extractFiles()

        getCap = GetCap(self.tizenVer, self.deviceId)
        getCap.run()

        return True

    def _isHealthCheckPassed(self):
        healtlist = self._read_health_check_ini()

        counter = 0
        counter_loop = 0

        if Constants.GlobalProfile == "":
            counter = len(healtlist) - 1
        else:
            counter = len(healtlist)

        LOGGER.info("value of counter is " + str(counter))
        LOGGER.info("value of GlobalProfile is " + str(Constants.GlobalProfile))

        if not healtlist:
            return False
        for l in healtlist:
            counter_loop = counter_loop + 1
            if counter_loop > counter:
                break

            if self.tizenVer.find("native") > -1 and l[1].find("tinyweb") > -1:
                continue

            proc = l[1].strip()

            command = "python " + \
                    (Constants.DEVICE_HEALTH_CMD % self.tizenVer) \
                    + " " + "--deviceid " + self.deviceId \
                    + " --check" + " --procid=" + proc
            try:
                outLog, errLog = SdbManager.sdbCommand(command, 180)
            except Exception as ex:
                LOGGER.error(str(ex))
                return False
            '''
            if exit_code is None:
                LOGGER.error("The device configuration \
                        is not right [Health Check : %s]." % l)
                return False
            '''
            LOGGER.info(str(outLog))
            if str(outLog).find('#ERROR#') > -1 or \
                    str(outLog).find('#WARNING#') > -1:
                LOGGER.warning(l[0].strip() + ": fail")
            else:
                LOGGER.info(l[0].strip() + ": pass")
        LOGGER.info("Return From isHealthCheckPassed, return value : True")
        return True

    def _checkDeviceCapability(self):
        capa_file = Constants.LOCAL_CAPABILITY_PATH % self.deviceId
        LOGGER.debug('capability path : %s' % capa_file)
        if not os.path.exists(capa_file):
            return False

        return True

    def _isPreconfigPassed(self):
        SdbManager.sdbPull(self.deviceId, \
                Constants.getPRE_CONF_DEVICE_INI(self.tizenVer), \
                Constants.PRE_CONF_HOST_INI % self.deviceId)
        if Constants.checkFileExists(\
                Constants.PRE_CONF_HOST_INI % self.deviceId) is False:
            LOGGER.error("The %s file does not exist. [ Preconfig Check]" \
                    % Constants.PRE_CONF_HOST_INI % self.deviceId)
            return False

        SdbManager.sdbPull(self.deviceId, \
                Constants.getPRE_CONF_DEVICE_JSON(self.tizenVer), \
                Constants.PRE_CONF_HOST_JSON % self.deviceId)
        if Constants.checkFileExists(\
                Constants.PRE_CONF_HOST_JSON % self.deviceId) is False:
            LOGGER.error("The %s file does not exist. [ Preconfig Check]" \
                    % Constants.PRE_CONF_HOST_JSON % self.deviceId)
            return False

        SdbManager.sdbPull(self.deviceId, \
                Constants.getPRE_CONF_DEVICE_XML(self.tizenVer), \
                Constants.PRE_CONF_HOST_XML % self.deviceId)
        if Constants.checkFileExists(\
                Constants.PRE_CONF_HOST_XML % self.deviceId) is False:
            LOGGER.error("The %s file does not exist. [ Preconfig Check]" \
                    % Constants.PRE_CONF_HOST_XML % self.deviceId)
            return False

        SdbManager.sdbPull(self.deviceId, \
                Constants.getPORT_CONF_DEVICE_JSON(self.tizenVer), \
                Constants.PORT_CONF_HOST_JSON % self.deviceId)
        if Constants.checkFileExists(\
                Constants.PORT_CONF_HOST_JSON % self.deviceId) is False:
            LOGGER.error("The %s file does not exist. [ Preconfig Check]" \
                    % Constants.PORT_CONF_HOST_JSON % self.deviceId)
            return False

        if Constants.checkFileExists(Constants.LOCAL_BUILD_INFO_PATH % \
                self.deviceId) is False:
            LOGGER.error("The %s file does not exist. [ Preconfig Check]" \
                    % Constants.LOCAL_BUILD_INFO_PATH % self.deviceId)
            return False

        if self.tizenVer and self.tizenVer.find("native") > -1:
            SdbManager.sdbPull(self.deviceId, \
                    Constants.getNAT_CONF_DEVICE_TXT(self.tizenVer), \
            Constants.NAT_CONF_HOST_TXT % self.deviceId)
            if Constants.checkFileExists(Constants.NAT_CONF_HOST_TXT \
                    % self.deviceId) is False:
                LOGGER.error("The %s file does not exist. [ Preconfig Check]" \
                        % Constants.LOCAL_BUILD_INFO_PATH % self.deviceId)
                return False

        LOGGER.info("Return from isPreconfigPassed, return value : True")
        return True
