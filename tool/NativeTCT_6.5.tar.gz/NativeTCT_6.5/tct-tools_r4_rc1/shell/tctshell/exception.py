
class DevNotFoundErr(Exception):
    def __init__(self, _devid):
        self.devid = _devid
    def __str__(self):
        return repr(self.devid)
