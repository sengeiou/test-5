import os
import time
import threading
from multiprocessing import Process, Queue, Manager

from .shellplanner import *
from .sdbmanager import SdbManager
from .result_summary import ResultSummary
from .logmanager import LOGGER


def wait_time(_time):
    for loop in range(_time):
        LOGGER.debug("Wait {} seconds......".format(_time-loop))
        time.sleep(1)


class AutoPlanExecutor(threading.Thread):

    def __init__(self, plan, threadCounter, isPreconSet, envManager, \
            run_timeout, devmgr):
        #Process.__init__(self)
        threading.Thread.__init__(self)
        self.suites = {}
        self.autop_executors = []
        self.all_dev_threads = []
        self.suite_q = Queue(maxsize=1)
        self.plan = plan
        self.devmgr = devmgr
        self.name = plan.getPlanName()
        self.tcCounter = threadCounter
        self.isPreconSet = isPreconSet
        self.notrun_count = 0
        self._orgSuites()
        self._prepareAutoPlan(self.isPreconSet)
        self.envManager = envManager
        self.finish_time = float(time.time()) + \
                ((int(run_timeout)) *  60)

    def run(self):
        self._startAutoPlan()
        LOGGER.debug("finished AutoPlanExecutor")

    def _orgSuites(self):
        if self.plan.getDeviceId() in self.suites:
            self.suites[self.plan.getDeviceId()] += self.plan.getSuites()[:]
        else:
            self.suites[self.plan.getDeviceId()] = self.plan.getSuites()[:]

    def _orgNotRunSuites(self, notRunSuites):
        suites = []
        LOGGER.debug("Finding Not Run suites")
        LOGGER.debug("Suites to find: %s" % str(notRunSuites))
        for suite in self.plan.getSuites():
            if suite.suiteName in notRunSuites:
                suites.append(suite)
        if None in self.suites:
            self.suites[None] += suites
        else:
            self.suites[None] = suites

    def _prepareAutoPlan(self, isPreconSet, notrun=None):
        runningDevs = self.devmgr.getSdbDeviceList()
        self.autop_executors = []
        for counter, dev in enumerate(runningDevs):
            self.plan.setDeviceId(dev.getDeviceId())
            self.suites[None].append('Finished')
            process_name = dev.getDeviceId()
            if notrun is not None:
                process_name = "%s_notRun%d" % (dev.getDeviceId(), notrun)
            autopExecutor = AutoPlanDevExecutor(self.plan, process_name, \
                    dev.getDeviceId(), counter + 1, self.suite_q, \
                    isPreconSet, self.devmgr)
            self.autop_executors.append(autopExecutor)
        self.all_dev_threads += self.autop_executors

    def _is_run_timeout(self):
        curr_time = float(time.time())

        if self.finish_time > curr_time:
            return False
        else:
            return True

    def _startAutoPlan(self):
        for worker in self.autop_executors:
            worker.start()

        while len(self.suites[None]) > 0:
            done_inhost = False
            wakeup_others = False
            suite = self.suites[None][0]
            if self._is_run_timeout():
                 LOGGER.error('tct-shell run/rerun timeout...')
                 while not self.suite_q.empty():
                     self.suites[None].insert(0, (self.suite_q.get(True)))
                 self._auto_test_inhost(self.suites[None])
                 self.suites[None] = []
                 break

            timeout = 0
            while self._no_worker_available():
                '''
                if self._exists_finished_worker():
                    wakeup_others = True
                    self._kill_all_workers()
                    LOGGER.debug("No need to reboot. Waking up other devices")
                    break
                '''
                #LOGGER.info("Wait for the connected devices to be reconnected [%s:%s]" % \
                #(str(timeout), str(Constants.NO_WORKERS_TIMEOUT)))
                #time.sleep(10)
                timeout += 10
                if timeout >= Constants.NO_WORKERS_TIMEOUT:
                    LOGGER.error("All devices are not available")
                    while not self.suite_q.empty():
                        self.suites[None].insert(0, (self.suite_q.get(True)))
                    self._auto_test_inhost(self.suites[None])
                    self.suites[None] = []
                    done_inhost = True
                    break

            if done_inhost or wakeup_others:
                break
            try:
                self.suite_q.put(suite, True, 20)
            except:
                continue
            self.suites[None].pop(0)

        '''
        for autopExecutor in self.autop_executors:
            SdbManager.exportDumpFiles(autopExecutor.deviceId, \
                    self.plan.getResultFolderPath())
            if autopExecutor.isRebooting():
                self.envManager.kill_usbMonitor(autopExecutor.deviceId)
                autopExecutor.killThread()
            autopExecutor.join()
        '''
        for autopExecutor in self.autop_executors:
            autopExecutor.join()
        '''
        for dev in self.devmgr.getSdbDeviceList():
            SdbManager.exportDumpFiles(dev.getDeviceId(), \
                    self.plan.getResultFolderPath())
        '''

        summary = ResultSummary([self.plan])
        '''
        notRunSuites = summary.checkResults()

        if len(notRunSuites) > 0:
            while not self.suite_q.empty():
                LOGGER.debug("Suite left in the queue. Clearing...")
                self.suite_q.get(True)
            LOGGER.debug("Starting Not Run suites")
            self._orgNotRunSuites(notRunSuites)
            LOGGER.debug("Not Run suites = %s" % str(self.suites[None]))
            self.notrun_count += 1
            self._prepareAutoPlan(self.isPreconSet, notrun=self.notrun_count)
            self._startAutoPlan()
        else:
        '''
        summary.genResults()
        summary.genSummary()
        self.plan.setFinished()

    def _auto_test_inhost(self, suites):
        self._kill_all_workers()
        self._kill_liteprocess()
        exeType = self.plan.getExecuteType()
        for suite in suites:
            if suite == 'Finished':
                continue
            if exeType.getCurrType() == ExecuteType.e_auto:
                self.autoworker = AutoPlan_AutoSuiteWorker(suite, None, \
                        self.plan)
                self.autoworker.auto_test_inhost()
            elif exeType.getCurrType() == ExecuteType.e_manual:
                continue
            else:
                self.autoworker = AutoPlan_AutoSuiteWorker(suite, None, \
                        self.plan)
                self.autoworker.auto_test_inhost()

    def _kill_liteprocess(self):
        cmd = "ps aux | grep 'python /opt/testkit/lite_web_csharp/testkit-lite'"
        result = SdbManager.hostCommandwithResult(cmd)
        if isinstance(result, (bytes, bytearray)):
            result = result.decode('utf-8')

        LOGGER.debug(result)
        grep_lines = result.split('\n')

        kill_packages = []
        for line in grep_lines:
            if line and len(line) > 1:
                proc_id = line.split()[1]
                SdbManager.hostCommand('kill -9 %s' % proc_id)

                res_url = line.split()[-1]
                if res_url and res_url.find('shell/result') > -1:
                    spt_pack = res_url.split('/')[-1].split('.')[0]
                    kill_packages.append(spt_pack)

        exeType = self.plan.getExecuteType()
        suites = self.plan.getSuites()

        for num in range(len(kill_packages)):
            pack_name = str(kill_packages.pop())

            for suite in suites:
                if suite.getSuiteName().find(pack_name):
                    if exeType.getCurrType() == ExecuteType.e_auto:
                        self.autowoker = AutoPlan_AutoSuiteWorker(suite, None, \
                                self.plan)
                        self.autowoker.auto_test_inhost()
                    elif exeType.getCurrType() == ExecuteType.e_manual:
                        continue
                    else:
                        self.autowoker = AutoPlan_AutoSuiteWorker(suite, None, \
                                self.plan)
                        self.autowoker.auto_test_inhost()
                    break

    def _no_worker_available(self):
        executor_size = len(self.autop_executors)
        curr_killed_executor = 0
        for autopExecutor in self.autop_executors:
            if autopExecutor.isKilled():
                curr_killed_executor += 1

        if executor_size == curr_killed_executor:
            return True

        return False

    def _exists_finished_worker(self):
        for autopExecutor in self.autop_executors:
            if autopExecutor.isKilled():
                return True
        return False

    def _kill_all_workers(self):
        for autopExecutor in self.autop_executors:
            autopExecutor.killThread()

    def _require_kill_worker(self):
        for autopExecutor in self.autop_executors:
            if not autopExecutor.isKilled():
                autopExecutor.killThread()

    def getSuites(self):
        return self.suites


class AutoPlanDevExecutor(Process):

    def __init__(self, plan, name, deviceId, threadCounter, suite_queue, \
            isPreconSet, devmgr):
        LOGGER.debug("Creating AutoPlanExecutor, with [device]: " + deviceId)
        Process.__init__(self)
        self.name = name
        self.deviceId = deviceId
        self.tcCounter = threadCounter
        self.threadLock = threading.Lock()
        self.suite_q = suite_queue
        self.plan = plan
        self.rebooting = Queue(1)
        self.finished = Queue(1)
        self.rebootLock = Queue()
        self.devmgr = devmgr

    def get_suite(self):
        try:
            suite = self.suite_q.get(True)
        except Queue.Empty:
            LOGGER.warning("AutoPlanDevExecutor.suite_queue empty exception")
            pass

        if suite == 'Finished':
            LOGGER.debug('suite obtained: Finished')

        return suite

    def killThread(self):
        if self.finished.empty():
            LOGGER.debug("Killing [%s]" % self.name)
            self.finished.put(1, block=False)
        else:
            LOGGER.debug("[%s] finished" % self.name)

    def isKilled(self):
        return not self.finished.empty()

    def isRebooting(self):
        return not self.rebooting.empty()

    def setRebooting(self, reboot):
        if reboot:
            self.rebooting.put(1, block=False)
        elif not self.rebooting.empty():
            self.rebooting.get()

    def run(self):
        LOGGER.debug("Starting AutoPlanDevExecutor|DevID:{},PID:{}".\
            format(self.deviceId, str(os.getpid())))
        suite = None
        is_reboot_timeout = False
        while True:
            if self.isKilled():
                LOGGER.debug("finished AutoPlanDevExecutor|DevID:{},PID:{}".\
                    format(self.deviceId, str(os.getpid())))
                break

            if not self.devmgr.isDeviceAvailable(self.deviceId) and \
                    not is_reboot_timeout:
                #reboot
                #LOGGER.error("Please reboot device : %s" % self.deviceId)
                #scheduling purpose: waiting for UsbMonitor to release lock.
                try:
                    self.rebootLock.get(block=True, timeout=60)
                    self.setRebooting(True)
                except:
                    is_reboot_timeout = True

                continue

            elif is_reboot_timeout:
                self.killThread()
                #LOGGER.error("%s is reboot timeout" % self.deviceId)
                break
            else:
                if self.isRebooting():
                    LOGGER.info("Rebooting complete device : %s" % \
                            self.deviceId)
                    SdbManager.recoveryDevice(self.plan.getTizenVersion(), \
                            self.deviceId)
                self.setRebooting(False)
                self.is_reboot_timeout = False

            '''
            if self.devIns.check_dump_monitor_que(self.deviceId):
                LOGGER.debug("Tracking dump device : %s" % self.deviceId)
                self.killThread()
                break
            '''

            suite = self.get_suite()
            if suite == 'Finished':
                self.killThread()
                break
            exeType = self.plan.getExecuteType()
            if exeType.getCurrType() == ExecuteType.e_auto:
                self.autoworker = AutoPlan_AutoSuiteWorker(suite, \
                        self.deviceId, self.plan)
                self.autoworker.auto_test()
            elif exeType.getCurrType() == ExecuteType.e_manual:
                self.manualworker = AutoPlan_ManualSuiteWorker(suite, \
                        self.deviceId, self.plan)
                self.manualworker.auto_test()
            else:
                self.autoworker = AutoPlan_AutoSuiteWorker(suite, \
                        self.deviceId, self.plan)
                self.autoworker.auto_test()
                self.manualworker = AutoPlan_ManualSuiteWorker(suite, \
                        self.deviceId, self.plan)
                self.manualworker.auto_test()
            try:
                dump_files = SdbManager.exportDumpFiles(self.deviceId, \
                    self.plan.getResultFolderPath() + "/dump/" + suite.getSuiteName())
                if dump_files:
                    SdbManager.deleteDumpFiles(self.deviceId, dump_files)
            except Exception as ex:
                LOGGER.error(str(ex))

        LOGGER.debug("finished AutoPlanDevExecutor")


class AutoPlan_AutoSuiteWorker:
    def __init__(self, suite, deviceId, plan):
        self.suite = suite
        self.deviceId = deviceId
        self.plan = plan
        self.remTmpDir = plan.getDevTctTmpPath()
        self.resultFolder = plan.getResultFolderPath()
        self.tizenVer = plan.getTizenVersion()
        self.isRerun = plan.isReRunning()
        self.stubPort = plan.getStubPort()

    def auto_test(self):
        suite = self.suite
        if suite.getAutoNum() is None or int(suite.getAutoNum()) == 0:
            suite.setNoAuto()
            LOGGER.warning('Suite : %s , AutoNum : 0' % (suite.getSuiteName()))
            return

        suiteName = suite.getSuiteName()
        suite.runPreTestScript(self.deviceId)

        LOGGER.info("Start to execute|suite:{},devid:{},pid:{}".\
            format(suiteName, self.deviceId, os.getpid()))
        LOGGER.debug("current suite Auto count : %s " % suite.getAutoNum())

        LOGGER.info('Checking if the suite ' + suiteName \
                + ' is installed already.')
        if suite.sdbCheckSuite(self.deviceId, suiteName):
            LOGGER.info('The suite ' + suiteName + ' is existed. uninstalling')
            LOGGER.info('Uninstalling the existed suite ' + suiteName)
            suite.unInstallSuite(self.deviceId, self.remTmpDir)

        LOGGER.info('Uploading the suite ' + suiteName)
        LOGGER.info('Installing the suite ' + suiteName)

        suite.installSuite(self.deviceId, self.remTmpDir)
        LOGGER.info('Executing the suite ' + suiteName + ' in testkit-lite.')
        suite.executePlanAuto(self.deviceId, self.resultFolder, \
                suite.getTestCase(), self.isRerun, self.stubPort)

        suite.runPostTestScript(self.deviceId)

        LOGGER.info('removing the suite pkg file of the suite ' + suiteName)
        LOGGER.info('Uninstalling the suite ' + suiteName)
        suite.unInstallSuite(self.deviceId, self.remTmpDir)

        LOGGER.info("Finished to execute|suite:{},devid:{},pid:{}".\
            format(suiteName, self.deviceId, os.getpid()))
        wait_time(10)

    def auto_test_inhost(self):
        suite = self.suite
        if suite.getAutoNum() is None or int(suite.getAutoNum()) == 0:
            suite.setNoAuto()
            LOGGER.warning('Suite : %s , AutoNum : 0' % (suite.getSuiteName()))
            return

        suiteName = suite.getSuiteName()
        LOGGER.info("Start to execute auto suite:%s" % suiteName)

        LOGGER.info('Uploading the suite ' + suiteName)
        LOGGER.info('Installing the suite ' + suiteName)
        suite.installSuite(self.deviceId, self.remTmpDir)
        LOGGER.info('Executing the suite ' + suiteName + ' in testkit-lite.')
        suite.executePlanAuto(self.deviceId, self.resultFolder, \
                suite.getTestCase(), self.isRerun, self.stubPort)

        LOGGER.info('removing the suite pkg file of the suite ' + suiteName)
        LOGGER.info('Uninstalling the suite ' + suiteName)
        suite.unInstallSuite(self.deviceId, self.remTmpDir)

        LOGGER.debug("current suite Auto count : %s " % suite.getAutoNum())
        LOGGER.info("Finished to execute auto suite:%s" % suiteName)


class AutoPlan_ManualSuiteWorker:
    def __init__(self, suite, deviceId, plan):
        self.suite = suite
        self.deviceId = deviceId
        self.plan = plan

    def auto_test(self):
        deviceId = self.deviceId
        remTmpDir = self.plan.getDevTctTmpPath()
        resultFolder = self.plan.getResultFolderPath()
        isRerun = self.plan.isReRunning()
        stubPort = self.plan.getStubPor()
        suite = self.suite

        if suite.getManualNum() is None or int(suite.getManualNum()) == 0:
            suite.setNoManual()
            LOGGER.warning('Suite : %s , ManualNum : 0' % \
                    (suite.getSuiteName()))
            return

        suiteName = suite.getSuiteName()
        LOGGER.debug("current suite Auto count : %s " % suite.getAutoNum())

        LOGGER.info('Checking if the suite ' + suiteName \
                + 'is installed already.')
        if suite.sdbCheckSuite(deviceId, suiteName):
            LOGGER.info('The suite ' + suiteName + ' is existed. uninstalling')
            LOGGER.info('Uninstalling the existed suite ' + suiteName)
            suite.unInstallSuite(deviceId, remTmpDir)

        LOGGER.info('Uploading the suite ' + suiteName)
        LOGGER.info('Installing the suite ' + suiteName)
        suite.installSuite(deviceId, remTmpDir)
        LOGGER.info('Executing the suite ' + suiteName + ' in testkit-lite.')
        suite.executePlanManual(deviceId, resultFolder, suite.getTestCase(), \
                isRerun, stubPort)

        LOGGER.info('removing the suite pkg file of the suite ' + suiteName)
        LOGGER.info('Uninstalling the suite ' + suiteName)
        suite.unInstallSuite(deviceId, remTmpDir)

        LOGGER.info("Finished to execute manual suite: [%s]" % suiteName)
