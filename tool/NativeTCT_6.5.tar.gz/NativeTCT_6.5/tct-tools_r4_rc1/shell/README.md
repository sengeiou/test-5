# TCT SHELL USAGE

## Options available:

#### --testplan
  + To run a plan based on xml file. You can find an example testplan file at /opt/tools/shell/plan/.<br/>
  Eg : ‘tct-shell –tizen-version tizen_native_6.0 –testplan /opt/tools/shell/plan/Native-full-wearable.xml’<br/>

#### --profile
  + To run all testcases in a particular profile.<br/>
  Eg : ‘tct-shell –tizen-version tizen_native_6.0 –profile mobile’<br/>

#### --test
  + Specify package/module to be executed.<br/>
  Eg : ‘tct-shell –tizen-version tizen_native_6.0 –test tct-dlog-native-itc’ <br/>
  This will ask user to select profile. To avoid that, use below command:<br/>
  Eg : ‘tct-shell –tizen-version tizen_native_6.0 –test mobile/tct-dlog-native-utc’<br/>
  
  + *UPDATE : --profile can be used along with –test to execute module of that particular profile.<br/>
  Eg : ‘tct-shell –tizen-version tizen_native_6.0 –profile mobile –test tct-dlog-native-itc’*<br/>
  The above command will run itc of dlog module for mobile profile.<br/>
  If –test is used without –profile, user input will be required to specify the profile.<br/>
  If –profile is used without –test, all modules of that profile will be executed.<br/>

#### --id
  + Run particular testcase in a package<br/>
  Eg : ‘tct-shell –tizen-version tizen_native_6.0 –test tct-dlog-native-utc --id utc_SystemFW_dlog_vprint_p’<br/>

#### --rerun-fail
  + Command to run tcs which are failed. The result directory needs to be specified.<br/>
  Eg : ‘tct-shell –tizen-version tizen_native_6.0 –rerun-fail /opt/tct/tizen_native_6.0/shell/result/temp_plan_name_2020-08-17_16”29:35.171777/’<br/>

#### --distribute
  + Use this option if you want to run TCs on multiple devices instead of one.<br/>

#### --tizen-version
  + Specify tizen version. This is a mandatory option.<br/>
#### --deviceid
  + Device id of device where execution needs to be done.<br/>
Eg : ‘tct-shell –tizen-version tizen_native_6.0 –test mobile/tct-dlog-native-utc –deviceid 0000c2a900007200’<br/>

#### --dbutedevid
  + Device ids of devices where execution needs to be done<br/>
Eg : ‘tct-shell –tizen-version tizen_native_6.0 –test mobile/tct-dlog-native-utc  --distribute –dbutedevid 0000c2a900007200 0000c6z00004800’<br/>
#### --disable
  + Disable the preconfigurations in TCT_preconditions.txt/preconfigure.json.<br/>
Eg : ‘tct-shell –tizen-version tizen_native_6.0 –test mobile/tct-dlog-native-utc –disable’<br/>
#### --output
  + Specify output directory<br/>
#### --skip-package
  + Packages/modules to be skipped. Mention many with space separated.<br/>
Eg : ‘tct-shell –tizen-version tizen_native_6.0 –profile mobile –skip-package tct-dlog-native-itc’<br/>
#### --skip-tc
  + TCs to be skipped. Mention many with space separated.<br/>
Eg : ‘tct-shell –tizen-version tizen_native_6.0 –test mobile/tct-dlog-native-utc –skip-tc utc_SystemFW_dlog_vprint_p’<br/>
#### --tc-timeout
  + Time after which TC execution will be stopped. Default is 60 sec.<br/>
Eg : ‘tct-shell –tizen-version tizen_native_6.0 –test mobile/tct-dlog-native-utc –tc-timeout 100’<br/>
#### --log
  + Log Level.(DEBUG/INFO/WARNING/ERROR/CRITICAL)<br/>
#### --pre-test
  + Run a script before installing testsuite in device.<br/>
Eg : ‘tct-shell –tizen-version tizen_native_6.0 –profile mobile –pre-test preinstall.sh’<br/>
#### --post-test
  + Run a script before uninstalling testsuite from device.<br/>
Eg : ‘tct-shell –tizen-version tizen_native_6.0 –profile mobile –post-test preuninstall.sh’<br/>
