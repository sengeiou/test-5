#!/usr/bin/python
#
# Copyright (C) 2012 Intel Corporation
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor,
# Boston, MA  02110-1301, USA.
#
# Authors:
#              Liu,chengtao <chengtaox.liu@intel.com>
""" The shell command executor module"""

import os
import sys
import time
import subprocess
from datetime import datetime

from .killall import killall
from .str2 import str2str


def shell_command(cmd, timeout=15):
    """shell communication for quick return in sync mode"""
    proc = subprocess.Popen(cmd,
                            shell=True,
                            bufsize=0,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            stdin=subprocess.PIPE)
    time_cnt = 0
    exit_code = None
    while time_cnt < timeout:
        exit_code = proc.poll()
        if not exit_code is None:
            break
        time_cnt += 0.2
        time.sleep(0.2)

    if exit_code is None:
        killall(proc.pid)
        exit_code = -1
        result = []
    else:
        result = proc.stdout.readlines() or proc.stderr.readlines()
    return [exit_code, result]


def shell_command_ext(cmd="",
                      timeout=None,
                      boutput=False,
                      stdout_file=None,
                      stderr_file=None):
    """shell executor, return [exitcode, stdout/stderr]
       timeout: None means unlimited timeout
       boutput: specify whether print output during the command running
    """
    cmd_open = subprocess.Popen(args=cmd,
                                shell=True,
                                bufsize=0,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE,
                                stdin=subprocess.PIPE)

    while True:
        exit_code = cmd_open.poll()
        if exit_code is not None:
            break
        if timeout is not None:
            timeout -= 0.1
            if timeout <= 0:
                try:
                    exit_code = "timeout"
                    cmd_open.terminate()
                    time.sleep(5)
                except OSError:
                    killall(cmd_open.pid)
                break
        time.sleep(0.1)

    stdout_log = str2str(cmd_open.stdout.read())
    stderr_log = str2str(cmd_open.stderr.read())
    if 'returncode=' in stdout_log:
        index = stdout_log.find('returncode=') + 11
        exit_code = str(stdout_log[index:]).strip('\r\n')
    stdout_log = '<![CDATA[' + stdout_log + ']]>'
    stderr_log = '<![CDATA[' + stderr_log + ']]>'

    return [exit_code, stdout_log, stderr_log]
