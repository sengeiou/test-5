//
// Copyright (c) 2014 Samsung Electronics Co., Ltd.
//
// Licensed under the Apache License, Version 2.0 (the License);
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
#ifndef _ASSERT_H_
#define _ASSERT_H_
#include <stdio.h>
#include <stdlib.h>

#define assert(exp) \
    if (!(exp)) { \
        fprintf(stderr, \
            "\\n[TCT][%s][Line : %d] Assert Fail; Following expression is not true: %s\\n", __FILE__, __LINE__, #exp); \
        return 1; \
    }

#define assert_eq(var, ref) \
    if (var != ref) { \
        fprintf(stderr, \
            "\\n[TCT][%s][Line : %d] Assert fail; Values (%s) and (%s) are not equal\\n", __FILE__, __LINE__, #var, #ref); \
        return 1; \
    }

#define assert_neq(var, ref) \
   if (var == ref) { \
        fprintf(stderr, \
            "\\n[TCT][%s][Line : %d] Assert fail; Values (%s) and (%s) are equal\\n", __FILE__, __LINE__, #var, #ref); \
        return 1; \
    }

#define assert_gt(var, ref) \
    if (var <= ref) { \
        fprintf(stderr, \
            "\\n[TCT][%s][Line : %d] Assert fail; Values (%s) is not greater than (%s)\\n", __FILE__, __LINE__, #var, #ref); \
        return 1; \
    }

#define assert_geq(var, ref) \
    if (var < ref) { \
        fprintf(stderr, \
            "\\n[TCT][%s][Line : %d] Assert fail; Values (%s) is not greater than or equal to (%s)\\n", __FILE__, __LINE__, #var, #ref); \
        return 1; \
    }

#define assert_lt(var, ref) \
    if (var >= ref) { \
        fprintf(stderr, \
            "\\n[TCT][%s][Line : %d] Assert fail; Values (%s) is not lower than (%s)\\n", __FILE__, __LINE__, #var, #ref); \
        return 1; \
    }

#define assert_leq(var, ref) \
    if (var > ref) { \
        fprintf(stderr, \
            "\\n[TCT][%s][Line : %d] Assert fail; Values (%s) is not lower than or equal to (%s)\\n", __FILE__, __LINE__, #var, #ref); \
        return 1; \
    }

#endif //  _ASSERT_H_
