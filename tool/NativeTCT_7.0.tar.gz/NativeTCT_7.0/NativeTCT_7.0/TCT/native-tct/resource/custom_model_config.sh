#!/bin/bash

TMP_FILE="/tmp/model-config.xml"
MODEL_FILE="/etc/config/model-config.xml"
HAL_MODEL_FILE="/hal/etc/config/model-config.xml"

PREFIX='<?xml version="1.0" encoding="UTF-8" standalone="no"?>\n<model-config version="6.5" model="TizenIOT">\n\t<platform>'
POSTFIX='\t</platform>\n\t<custom>\n\t</custom>\n</model-config>'

if [ ! -e $HAL_MODEL_FILE ]
then
	cp -f $MODEL_FILE $TMP_FILE
	exit 0
fi

echo -e $PREFIX > $TMP_FILE

while read line
do
	if [[ $line == *"tizen.org/"* ]]
	then
		echo -n ""
	else
		continue
	fi

	INFO=`echo $line | sed -e "s/^.\+key.\+name=\"\(.\+\)\".\+type=\"\(.\+\)\">\(.\+\)<.\+$/\1 \2 \3/"`
	FEATURE=`echo $INFO | awk '{print $1}'`
	if [[ $FEATURE == *"tizen.org/system/build"* ]]
	then
		continue
	fi
	TYPE=`echo $INFO | awk '{print $2}'`
	VAL=`echo $INFO | awk '{print $3}'`
	echo -n -e "\033[2KProcessing : $FEATURE\r"
	hal_line=`grep "\"$FEATURE\"" $HAL_MODEL_FILE`
	if [ $? == 0 ]
	then
		HAL_INFO=`echo $hal_line | sed -e "s/^.\+key.\+name=\"\(.\+\)\".\+type=\"\(.\+\)\">\(.\+\)<.\+$/\1 \2 \3/"`
		VALUE=`echo $HAL_INFO | awk '{print $3}'`
		HAL_EXIST="true"
	else
		HAL_EXIST="false"
	fi

	if [ $HAL_EXIST == "true" ]
	then
		if [ $TYPE == "bool" ]
		then
			if [ $VAL == "true" -a $VALUE == "true" ]
			then
				C_VAL="true"
			else
				C_VAL="false"
			fi
		else
			C_VAL=$VALUE
		fi
	else
		C_VAL=$VAL
	fi

	echo -e "\t\t<key name=\"$FEATURE\" type=\"$TYPE\">$C_VAL</key>" >> $TMP_FILE

done < $MODEL_FILE
echo ""

echo -e $POSTFIX >> $TMP_FILE

